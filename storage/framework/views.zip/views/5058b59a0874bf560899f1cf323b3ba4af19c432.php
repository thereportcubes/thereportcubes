<div class="clearfix">

        <footer class="main-footer">
            <div class="ab-footer-wapper " >
                <div class="ab-footer-main-bar-right" style="color:#f2f2f2; margin-bottom:10px;">
                    <div class="ab-footer-menus">
                        <div class="ab-footer-menus-col">
                            <a href="#"><img loading="lazy" width="150" height="42" src="<?php echo e(url('public/assets/images/logo-rcube-footer.png')); ?>" alt="Research and Markets"></a>
                            
                            <ul class="ab-footer-phone-list">
                                <li><a href="tel:+919876543210"><i class="fa fa-phone"></i>+91 9876543210
                                        </a>
                                </li>
                            
                                <li  style="display: list-item;"><a href="tel:+353-1-416-8900"><i class="fa fa-envelope"></i> info@rcube.com </a></li>
                                                        
                            </ul>
                        </div>
                        <div class="ab-footer-menus-col">
                            <div class="ab-footer-menus-col-title">Quick Links</div>
                            <ul class="footer_link">
                                <li><a href="<?php echo e(url('about-us')); ?>">About us</a></li>
                                <li><a href="#">Careers</a></li>
                                <li><a href="#">What we Do</a></li>
                                <li><a href="#">Register</a></li>
                                <li><a href="<?php echo e(url('login')); ?>">Login</a></li>
                            
                            </ul>
                        </div>
                        <div class="ab-footer-menus-col">
                            <div class="ab-footer-menus-col-title">Products & services </div>
                            <ul class="footer_link">
                                <li><a href="<?php echo e(url('report-store')); ?>">Reserch Reports</a></li>
                                <li><a href="<?php echo e(url('on-going-report')); ?>">Upcoming Reports</a></li>
                                <li class=""><a href="<?php echo e(url('press-release')); ?>"> Press Release</a></li>
                                <li class=""><a href="<?php echo e(url('infographics')); ?>"> Infographics</a></li>
                            </ul>
                        </div>
                        
                        <div class="ab-footer-menus-col">
                            <div class="ab-footer-menus-col-title">Contact Us</div>                        
                            <ul class="ab-footer-phone-list">
                                <li>
                                    <a href="#"><i class="fa fa-globe"></i>367 Hillcrest Lane,USA</a>
                                </li>
                                <li  style="display: list-item;">
                                    <div class="ab-footer-social">
                                        <a target="_blank" href="#"><i class="fa fa-facebook"></i><span class="ab-screen-reader-text">Facebook</span></a>
                                        <a target="_blank" href="#"><i class="fa fa-instagram"></i><span class="ab-screen-reader-text">Instagram</span></a>
                                        <a target="_blank" href="#"><i class="fa fa-linkedin-square"></i><span class="ab-screen-reader-text">LinkedIn</span></a>
                                        <a target="_blank" href="#"><i class="fa fa-twitter-square"></i><span class="ab-screen-reader-text">Twitter</span></a>
                                        
                                    </div>
                                </li>                    
                            </ul>        
                                
                        </div>
                    
                    </div>
                </div>
                
                <div class="col-sm-12">
                    <div class="ab-footer-badges col-sm-12"> 
                        <div class="ab-footer-copyright-text" style="width:50%"> Copyright © 2023-2024 R-Cube. All
                            Rights Reserved. 
                        </div>                   
                        <div class="ab-footer-badge--payments" style="text-align:right;width:50%; float:right">
                            <div class="ab-footer-badge--visa" title="VISA"><img loading="lazy" src="<?php echo e(asset('assets/images/payment-icon-visa.webp')); ?>" alt="Payment Icon Visa"></div>
                            <div class="ab-footer-badge--mastercard" title="MasterCard"><img loading="lazy" src="<?php echo e(asset('assets/images/master.png')); ?>" alt="Payment Icon Mastercard">
                            </div>
                            <div class="ab-footer-badge--amex" title="American Express"><img loading="lazy" src="<?php echo e(asset('assets/images/payment-icon-americanexpress.webp')); ?>" alt="Payment Icon Americanexpress"></div> 
                            <div class="ab-footer-badge--paypal" title="American Express"><img loading="lazy" src="<?php echo e(asset('assets/images/paypal.png')); ?>" alt="Payment Icon Americanexpress"></div>                      
                        </div>
                        
                    </div>                    
                </div>
           </div>
        </footer>
    </div>
    <div class="popup search-popup" role="alert">
        <div class="popup-container">

          <a href="#0" class="popup-close img-replace">Close</a>
          <div class="form-contanier" style="width: 90%;padding: 5px;">
            <form action="/a" style="display: flex;width: 100%;">
              <input type="text" placeholder="Search.." name="search">
              <button type="submit" style="width: 50px;padding: 10px;background: var(--primary-color);color: #fff;border: unset;"><i class="fa fa-search"></i></button>
            </form>
           </div>
        
        </div> 
      </div> 



    <script src="<?php echo e(url('public/assets/js/ab-script.js')); ?>"></script>

 
    <script>window.gtranslateSettings = {"default_language":"en","detect_browser_language":true,"languages":["en","fr","hi"],"wrapper_selector":".gtranslate_wrapper","flag_size":24,"alt_flags":{"en":"usa"}}</script>
    
        <script src="<?php echo e(url('public/assets/js/gtranslate.js')); ?>" defer></script>

</body>

</html>
<?php /**PATH /home/u171619165/domains/vishalghosh.com/public_html/stagingrcube/site/resources/views/layout/newfooter.blade.php ENDPATH**/ ?>
<?php echo '<?xml version="1.0" encoding="UTF-8"?>'; ?>

<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">
    
    <url>
        <loc><?php echo e(url('/careers')); ?></loc>
        <changefreq>daily</changefreq>
        <priority>0.85</priority>
    </url>

    <url>
        <loc><?php echo e(url('/terms-condition')); ?></loc>
        <changefreq>daily</changefreq>
        <priority>0.85</priority>
    </url>

    <url>
        <loc><?php echo e(url('/privacy-policy')); ?></loc>
        <changefreq>daily</changefreq>
        <priority>0.85</priority>
    </url>

    <url>
        <loc><?php echo e(url('/upcoming-reports')); ?></loc>
        <changefreq>daily</changefreq>
        <priority>0.85</priority>
    </url>

    <url>
        <loc><?php echo e(url('/export-import-data')); ?></loc>
        <changefreq>daily</changefreq>
        <priority>0.85</priority>
    </url>

    <url>
        <loc><?php echo e(url('/contact-us')); ?></loc>
        <changefreq>daily</changefreq>
        <priority>0.85</priority>
    </url>


</urlset><?php /**PATH /home/marknteladvisors/public_html/resources/views/xml/others.blade.php ENDPATH**/ ?>
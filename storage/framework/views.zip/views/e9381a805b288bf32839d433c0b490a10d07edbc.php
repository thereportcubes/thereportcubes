
<?php $__env->startSection('title','Upcoming Report'); ?>

<?php $__env->startSection('content'); ?>
<style>
   #more {display: none;}
</style>

<section class="mini-banner">
      <div class="container">
         <div class="row">
            <div class="col-md-12">
               <h3 class="mb-0 mini-banner-title">Market Research Reports</h3>
            </div>
         </div>
      </div>
   </section>
   <!-- mini banner end -->
   <section class="main-content mb-5 mt-5">
      <div class="container">
         <div class="row">
            <div class="col-md-9 sm-100">
               <div class="box-shadow">
                  
                  <div class="inside-border">

                  <div class="row  category-box">
                     <div class=" col-md-3">
                        <img src="<?php echo e(url('public/img/market_research_consulting.webp')); ?>" class="img-fluid with-border" alt="Market Research Report">
                     </div>
                     <div class="col-md-9">
                        <a class="fw-600 d-block blue pt-2" target="_blank"><h1 class="title_heading"><?php echo e($datas->title); ?></h1></a>
                        <p class="fs-14 mb-2">
                           <h2 class="title_descr">
                              <?php echo substr($datas->heading2,0,180); ?><span id="dots">...</span><span id="more"><?php echo trim(substr($datas->heading2,180,2000));  ?>
                              </span>

                              <a href="javascript:void()" onclick="myFunction()" id="myBtn2" class="read-more-small-btn"> Read more</a>
                           </h2>
                        </p>
                        <ul class="catefory-list ps-0 mb-0 pt-2">
                           <li>
                              <label><i class="fa fa-industry" aria-hidden="true"></i></label>
                              <span>
                              <?php echo e($datas->cat_name); ?></span>
                           </li>
                           <li>
                              <label> <i class="fa fa-calendar" aria-hidden="true"></i></label>
                              <span><?php echo e(Carbon\Carbon::parse($datas->report_post_date)->format('M Y')); ?></span>
                           </li>
                           <li>
                              <label>Pages</label>
                              <span><?php echo e($datas->no_of_page); ?></span>
                           </li>
                           <?php if($datas->report_code !=''): ?>
                           <li>
                              <label>Report Code</label>
                              <span><?php echo e($datas->report_code); ?></span>
                           </li>
                           <?php endif; ?>
                        </ul>
                     </div>
                  </div>

</div>

                  
               </div>
               
               <div class="box-shadow">
                  <ul class="nav nav-tabs tab-area when-scroll" id="myTab" role="tablist">
                     <li class="nav-item" role="presentation">
                        <button class="nav-link active" id="Overview-tab" data-bs-toggle="tab"
                           data-bs-target="#Overview" type="button" role="tab" aria-controls="Overview"
                           aria-selected="true">Overview</button>
                     </li>
                     <li class="nav-item" role="presentation">
                        <button class="nav-link" id="Content-tab" data-bs-toggle="tab" data-bs-target="#Content"
                           type="button" role="tab" aria-controls="Content" aria-selected="false">Table of Content</button>
                     </li>
                     <li class="nav-item" role="presentation">
                        <button class="nav-link" id="Segmentation-tab" data-bs-toggle="tab"
                           data-bs-target="#Segmentation" type="button" role="tab" aria-controls="Segmentation"
                           aria-selected="false">Segmentation</button>
                     </li>
                     <li class="nav-item" role="presentation">
                        <a href="<?php echo e(url('query/request-sample')); ?>/<?php echo e(request()->segment(2)); ?>"><button class="nav-link " id="Request-tab" data-bs-toggle="tab" data-bs-target="#Request"
                           type="button" role="tab" aria-controls="Request" aria-selected="false"><span class="blink-me">Download PDF Sample</span></button>
                        </a>
                     </li>
                  </ul>
                  <div class="tab-content" id="myTabContent">
                     <div class="tab-pane fade show active" id="Overview" role="tabpanel"
                        aria-labelledby="Overview-tab">
                        <div class="tabs-content">
                           <?php echo $datas->decription;  ?>
                           <br>
                           <?php if($infographic_image !=""): ?>
                            <?php
                                $res = "";
                                $exp_arr = explode('Market', $infographic_image->img_alt_tag); 
                                $res = $exp_arr[0]."";
                                
                            ?>
                            <?php 
                                if($res == ""){
                                   $exp_arr =  explode('Market', $datas->title); 
                                   $res = $exp_arr[0];
                                }
                            ?>
                           <a href="<?php echo e(url('/infographics')); ?>/<?php echo e(request()->segment(2)); ?>" target="_blank">
                              <img src="<?php echo e(url('/public')); ?>/<?php echo e($infographic_image->image); ?>" style="width:100%" class="img-responsive"  alt="<?php echo e($datas->title); ?>" /></a>
                           <br>
                           <?php endif; ?>
                           <br>
                           <?php echo $datas->description_last;  ?>
                        </div>

                        <!-- FAQ-!-->
                        <p class="fw-600 single-title">Frequently Asked Questions</p>
                        <div class="accordion" id="accordionExample">
                           <?php $faqs = json_decode($datas->faqs);  $size = count((array)$faqs->ques); ?>
                           <?php if($size>0): ?>
                           <?php for($i=0 ; $i<$size; $i++): ?>
                              <?php if($faqs->ques[$i] !=""): ?>
                              <div class="accordion-item">
                                 <h2 class="accordion-header" id="heading<?php echo $i; ?>">
                                    <button class="accordion-button <?php if($i != 0 ) {echo "collapsed";} ?>" type="button" data-bs-toggle="collapse"
                                       data-bs-target="#collapse<?php echo $i; ?>" aria-expanded="true" aria-controls="collapse<?php echo $i; ?>">
                                       Q. <?php echo e($faqs->ques[$i]); ?> 
                                    </button>
                                 </h2>
                                 <div id="collapse<?php echo $i; ?>" class="accordion-collapse collapse <?php if($i == 0 ) {echo "show";} ?>"
                                    aria-labelledby="heading<?php echo $i; ?>" data-bs-parent="#accordionExample">
                                    <div class="accordion-body">
                                    &nbsp;&nbsp;  A. <?php echo e($faqs->ans[$i]); ?> 
                                    </div>
                                 </div>
                              </div>
                              <?php endif; ?>
                           <?php endfor; ?>
                           <?php endif; ?>
                        </div>

                     </div>
                     <div class="tab-pane fade " id="Content" role="tabpanel" aria-labelledby="Content-tab">
                     <p><?php echo $datas->table_of_content;  ?> </p>
                     </div>
                     <div class="tab-pane fade" id="Segmentation" role="tabpanel" aria-labelledby="Segmentation-tab"><br>
                        <img src="<?php echo e(url('/public')); ?>/<?php echo e($datas->segmentaion); ?>" width="100%" alt="<?php echo e($datas->segmentation_alt_tag); ?>"/> 
                     </div>
                     <div class="tab-pane fade" id="Request" role="tabpanel" aria-labelledby="Request-tab">
                        
                     </div>
                  </div>
               </div>
            </div>
            <div class="col-md-3 sm-100 ">
               <div class="right-sidebar when-scroll">
                  <div class="box-shadow ">
                     <h6 class="fw-600 blue-title-bg">Place an order</h6>

                     <div class="d-flex justify-content-between orders fs-14 mb-3">
                     <div class="form-check">
                        <input class="form-check-input excel_data_pack" type="radio" value="<?php  echo ($datas->special_excel_data_pack !='') ? $datas->special_excel_data_pack.'-excel_data_pack' : $datas->excel_data_pack.'-excel_data_pack' ?>" id="flexCheckDefault" checked name="price_type" >
                        <label class="form-check-label" for="flexCheckDefault">
                           Excel Data Pack
                        </label>
                        <span class="tooltips"><i class="fa fa-info-circle"></i><span class="tooltipstext">  
                              Only market data will be provided in the excel spreadsheet.<span
                                 class="caret"></span></span></span>
                     </div>
                     <div>
                        <p class="mb-0">
                           <?php if($datas->special_excel_data_pack !='' ): ?>
                           <s> USD  <?php echo e($datas->excel_data_pack); ?> </s> <br> <?php echo e('USD ' .$datas->special_excel_data_pack); ?> 
                           
                           <?php else: ?> 
                           USD  <?php echo e($datas->excel_data_pack); ?>

                           <?php endif; ?>
                        </p>
                     </div>

                  </div>

                  <div class="d-flex justify-content-between orders fs-14 mb-3">
                     <div class="form-check">
                        <input class="form-check-input single_user_license" name="price_type" type="radio" value="<?php  echo ($datas->special_single_licence_price !='') ? $datas->special_single_licence_price.'-single_licence_price' : $datas->single_licence_price.'-single_licence_price' ?> " id="flexCheckDefault">
                        <label class="form-check-label" for="flexCheckDefault">
                           Single User License
                        </label>
                        <span class="tooltips"><i class="fa fa-info-circle"></i><span class="tooltipstext">  
                              The report will be delivered in PDF format without printing rights. It is advised for a
                              single user.<span class="caret"></span></span></span>
                     </div>
                     <div>
                        <p class="mb-0">
                           <?php if($datas->special_single_licence_price !='' ): ?>
                              <s> USD  <?php echo e($datas->single_licence_price); ?> </s> <br> <?php echo e('USD ' .$datas->special_single_licence_price); ?> 
                              
                              <?php else: ?> 
                              USD  <?php echo e($datas->single_licence_price); ?>

                           <?php endif; ?>   
                        </p>
                     </div>
                  </div>

                  <div class="d-flex justify-content-between orders fs-14 mb-3">
                     <div class="form-check">
                        <input class="form-check-input" type="radio" value="<?php echo ($datas->special_multi_user_price !='') ? $datas->special_multi_user_price.'-multi_user_price' : $datas->multi_user_price.'-multi_user_price' ?> " id="flexCheckDefault" name="price_type">
                        <label class="form-check-label" for="flexCheckDefault">
                           Multi User License
                        </label>
                        <span class="tooltips"><i class="fa fa-info-circle"></i><span class="tooltipstext">  
                              The report will be delivered in PDF format with printing rights. It is advised for up
                              to five users.<span class="caret"></span></span></span>
                     </div>
                     <div>
                        <p class="mb-0">
                           <?php if($datas->special_multi_user_price !='' ): ?>
                              <s> USD  <?php echo e($datas->multi_user_price); ?> </s> <br> <?php echo e('USD ' .$datas->special_multi_user_price); ?> 
                              
                              <?php else: ?> 
                              USD  <?php echo e($datas->multi_user_price); ?>

                           <?php endif; ?>
                        </p>
                     </div>
                  </div>


                  <div class="d-flex justify-content-between orders fs-14 mb-3">
                     <div class="form-check">
                        <input class="form-check-input" type="radio" value="<?php echo ($datas->special_custom_report_price !='') ? $datas->special_custom_report_price.'-custom_report_price' : $datas->custom_report_price.'-custom_report_price' ?> " id="flexCheckDefault" name="price_type">
                        <label class="form-check-label" for="flexCheckDefault">
                           Enterprise License
                        </label>
                        <span class="tooltips"><i class="fa fa-info-circle"></i><span class="tooltipstext">  
                              The report will be delivered in PDF format with printing rights and excel sheet. It is
                              advised for companies where multiple users would like to access the report from
                              multiple locations<span class="caret"></span></span></span>
                     </div>
                     <div>
                        <p class="mb-0">
                           <?php if($datas->special_custom_report_price !='' ): ?>
                              <s> USD  <?php echo e($datas->custom_report_price); ?> </s> <br> <?php echo e('USD ' .$datas->special_custom_report_price); ?> 
                              
                              <?php else: ?> 
                              USD  <?php echo e($datas->custom_report_price); ?>

                           <?php endif; ?>
                        </p>
                     </div>
                  </div>

                     <input type="hidden" name="idH" value="<?php echo e($datas->id); ?>" id="idH" />

                     <button type="button" class="btn btn-primary small-btn max-100" onclick="add_to_cart()">Buy Now</button>
                  </div>
                  <div class="btn-groups">
                     <a href="<?php echo e(url('query/request-sample')); ?>/<?php echo e(request()->segment(2)); ?>" class="btn btn-primary small-btn d-inline-block max-100 color-one"><i
                           class="fa fa-hand-pointer" aria-hidden="true"></i>
                        Request
                        Sample</a>
                     <a href="<?php echo e(url('query/talk-to-our-consultant')); ?>/<?php echo e(request()->segment(2)); ?>" class="btn btn-primary small-btn d-inline-block max-100 color-two"><i
                           class="fa fa-hand-pointer" aria-hidden="true"></i> Talk to our Consultant</a>
                     <a href="<?php echo e(url('query/request-customization')); ?>/<?php echo e(request()->segment(2)); ?>" class="btn btn-primary small-btn d-inline-block max-100 color-three"><i
                           class="fa fa-hand-pointer" aria-hidden="true"></i> Request Customization</a>
                  </div>
                  <div class="box-shadow">
                     <h6 class="fw-600  blue-title-bg">Related Reports</h6>

                     <ul class="mb-0 ps-0 related-report">
                        <?php $__currentLoopData = $related_reports; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rep): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                           <li class="list-unstyled fs-14 pb-2">
                              <a href="<?php echo e(url('research-library')); ?>/<?php echo e($rep->page_url); ?>"><i class="fa fa-handshake" aria-hidden="true"></i> <?php echo e($rep->title); ?> </a>
                           </li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                     </ul>
                  </div>
               </div>
            </div>
         </div>
      </div>
   </section>

   <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.7.1/jquery.min.js"></script>
   <script>
      function add_to_cart(){
      
      let report_type_price = $("input[name='price_type']:checked").val();
      
      if(report_type_price == "" || report_type_price === 'undefined'){
         alert('Please Select At-least One Licence Price');
         return false;
      }
      let id = $("#idH").val();
      
      $.ajax({
			url : '<?php echo e(route("add-to-cart-new")); ?>' ,
			type: 'get',
         data: {'id':id, report_type_price: report_type_price},
         dataType: "JSON",
success: function(response){
    if(response.status == true){
    window.location = "<?php echo e(url('/cart')); ?>";
 }else{
     alert("Already in Cart");
 }
 }
      }); 

   }
   </script>

<script>
function myFunction() {
  var dots = document.getElementById("dots");
  var moreText = document.getElementById("more");
  var btnText = document.getElementById("myBtn2");

  if (dots.style.display === "none") {
    dots.style.display = "inline";
    btnText.innerHTML = "Read more"; 
    moreText.style.display = "none";
  } else {
    dots.style.display = "none";
    btnText.innerHTML = "Read less"; 
    moreText.style.display = "inline";
  }
}
</script>

<?php $__env->stopSection(); ?>


<?php echo $__env->make('layout/header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/marknteladvisors/public_html/resources/views/research_report_details.blade.php ENDPATH**/ ?>
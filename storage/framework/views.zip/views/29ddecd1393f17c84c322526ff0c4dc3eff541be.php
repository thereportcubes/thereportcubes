
<?php $__env->startSection('title','Cart'); ?>
<?php $__env->startSection('content'); ?>
<section class="mini-banner">
   <div class="container">
      <div class="row">
         <div class="col-md-12">
            <h1 class="mb-0 mini-banner-title">Cart & Checkout</h1>
         </div>
      </div>
   </div>
</section>
<!-- cart section start -->
<section class="report-details mt-4 mb-4">
   <div class="container">
      <div class="row">
         <div class="col-md-12">
            <div class="wrap-cart">
               <div class="report-heading d-flex align-items-center justify-content-between ">
                  <p class="mb-0 white">Reports Details</p>
                  <p class="mb-0 white">Total Price
                  </p>
               </div>

               <div class="row cart-row">
                  <div class="col-md-12">
                     <div class="cart-border">
                        <div class="row">
                        
                        <?php $price = 0; ?>

                        <?php if(count((array) session('cart')) > 0 ): ?>
                        
                        <?php $total = 0 ?>
                       
                        <?php if(session('cart') ): ?>
                           <?php $__currentLoopData = session('cart'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $id => $details): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                              
                              <?php if(strpos($details['price'], ',') !== false): ?>
                                 <?php 
                                    $price = str_replace(',','',$details['price']);
                                 ?>
                                 
                              <?php else: ?>
                                 <?php $price = $details['price']; ?>


                              <?php endif; ?>
                              
                              <?php $price = intval($price);
                                 $total += $price * $details['quantity'] ?>
                           
                           
                              <div class="col-md-2 sm-100 mb-25">
                                 <div class="product-cart-image text">
                                    <img src="<?php echo e(asset('/images/global_industrial_automation_market_thumbnail.webp')); ?>" width="90" height="90" class="img-responsive img-fluid" alt="">
                                 </div>
                              </div>
                              <div class="col-md-10 sm-100">
                                 <div
                                    class="pro-title-price d-flex justify-content-between align-items-center mb-4 ">
                                    <div>
                                       <a href="<?php echo e(url('report-store')); ?>/<?php echo e($details['page_url']); ?>"><?php echo e($details['name']); ?></a>
                                    </div>
                                    <div>
                                       <p class="mb-0">USD <?php echo e($details['price']); ?></p>
                                    </div>
                                 </div>
                                 <div class="row report-card align-items-center ">
                                    <div class="col-md-7 sm-100 mb-25">
                                       <div class="d-flex justify-content-between report-card-inner mb-3">
                                          <div class="col-md-3">
                                             <p class="mb-0"> Report Code:</p>
                                          </div>
                                          <div class="col-md-9">
                                             <p class="mb-0"><?php echo e($details['report_code']); ?></p>
                                          </div>
                                       </div>
                                       <div class="d-flex justify-content-between report-card-inner">
                                          <div class="col-md-3">
                                             <p class="mb-0">License Type:</p>
                                          </div>
                                          <div class="col-md-9">
                                             <select class="form-select update-cart" aria-label="Default select example">
                                              
                                                <option value="<?php echo e($details['id']); ?>,single_licence_price" <?php if($details['report_type'] == 'single_licence_price'): ?> <?php echo e("selected"); ?> <?php endif; ?>>Single User License
                                                </option>
                                                <option value="<?php echo e($details['id']); ?>,multi_user_price" <?php if($details['report_type'] == 'multi_user_price'): ?> <?php echo e("selected"); ?> <?php endif; ?>>Multi User License
                                                </option>
                                                <option value="<?php echo e($details['id']); ?>,custom_report_price" <?php if($details['report_type'] == 'custom_report_price'): ?> <?php echo e("selected"); ?> <?php endif; ?>>
                                                   Enterprise License
                                                </option>
                                             </select>
                                          </div>
                                       </div>
                                    </div>
                                    <div class="col-md-5">
                                       <div class="card-close text-end">
                                          <a href="javascript:void()" class="remove-from-cart" onClick="remove_cart(<?php echo $details['id']; ?>)" ><i
                                             class="fa fa-trash" aria-hidden="true"></i></a>
                                       </div>
                                    </div>
                                 </div>
                              </div>
                              <div class="col-md-12">
                                 <hr>
                              </div>                         

                           <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  
                           <?php endif; ?>

                           <?php $t = 0; ?>

                           <div class="col-md-12">
                              <div class="buy_now d-flex align-items-center justify-content-between">
                                 <div>
                                    <p class="mb-0">Total Amount: USD <?php echo number_format($total) ?></p>
                                 </div>
                                 <div>
                                    <button class="btns btn-primary" onclick="$('#billing_company_name').focus()">Buy Now</button>
                                   
                                    <a href="<?php echo e(url('report-store')); ?>" class="btns btn-primary">Continue Shopping </a>
                                 </div>
                              </div>
                           </div>

                           <?php else: ?>
                              <div class="text-danger">
                                 Your Cart is empty.
                              </div>
                           <?php endif; ?>


                        </div>
                     </div>
                  </div>
                  
               </div>
            </div>
         </div>
      </div>
   </div>
</section>
<!-- cart section end -->
<!-- select payment option -->
<section class="pay-option mb-5">
   <div class="container">
      <div class="row">
         <div class="col-md-8 sm-100 mb-25">
            <div class="wrap-cart">
               <div class="report-heading">
                  <p class="mb-0 white">Select Payment Options</p>
               </div>
               <div class="row cart-row">
                  <div class="col-md-12">
                     <div class="cart-border">
                        <div class="row pb-4">
                           <div class="col-md-6">
                              <div class="login-box text-center">
                                 <h4>Continue as Guest</h4>
                                 <button class="btns btn-primary" onclick="$('#billing_company_name').focus()" >Buy Now</button>
                              </div>
                           </div>
                           <div class="col-md-6">
                              <div class="login-box text-center">
                                 <h4>Already have an Account</h4>
                                 <button class="btns btn-primary">Click Here to Sign In</button>
                              </div>
                           </div>
                        </div>
                        <form method="post" action="<?php echo e(url('save_cart_payment')); ?>" id="payForm">
                           <?php echo csrf_field(); ?>
                           <div class="row mb-4">
                              <div class="col-md-12">
                                 <div class="option-payments">
                                    
                                      <!--  <label class="radio-inline pe-2">
                                       <input type="radio" onchange="paymentType('CC Avanue')"
                                          name="payment_type"  value="CC Avanue"> Credit / Debit Card Payment
                                       </label> -->
                                       <label class="radio-inline pe-2">
                                       <input type="radio" onchange="paymentType('Wire Transfer')"
                                          name="payment_type" value="Wire Transfer" checked="">
                                       Bank Transfer
                                       </label>
                                      <!--  <label class="radio-inline">
                                       <input type="radio" onchange="paymentType('paypal')"
                                          name="payment_type" value="paypal" checked=""> Paypal
                                       </label> -->
                                   
                                 </div>
                              </div>
                           </div>
                           <div class="row">
                              <div class="col-md-12">
                                 <h5 class="mb-0">Enter your Billing Details</h5>
                                 <hr>
                              </div>
                           </div>                        
                           <div class="row">
                              <div class="col-md-12">
                                 
                             <div class="row" style="align-items: center;">
                              <div class="col-md-3">
                                <p style="font-size: 16px;">Full Name<span style="color:var(--primary-color)">*</span></p>
                            </div>
                          <div class="col-md-9">
                            <input class="ab-input" type="text" name="billing_name" id="billing_name" placeholder="Full Name" required>
                         </div>
                     </div>

                              </div>
                              <div class="col-md-12">
                                
                             <div class="row" style="align-items: center;">
                              <div class="col-md-3">
                                <p style="font-size: 16px;">Company Name<span style="color:var(--primary-color)">*</span></p>
                            </div>
                          <div class="col-md-9">
                            <input class="ab-input" type="text" name="billing_company_name" id="billing_company_name" placeholder="Company Name" required>
                         </div>
                        </div>

                              </div>
                              
                            
                              <div class="col-md-12">
                              
                                     <div class="row" style="align-items: center;">
                              <div class="col-md-3">
                                <p style="font-size: 16px;">Email Address<span style="color:var(--primary-color)">*</span></p>
                            </div>
                          <div class="col-md-9">
                            <input class="ab-input" type="text"  placeholder="Email Address " required name="billing_email">
                         </div>
                     </div>
                              </div>
                              <div class="col-md-12">
                              
                                         <div class="row" style="align-items: center;">
                              <div class="col-md-3">
                                <p style="font-size: 16px;">Contact Number<span style="color:var(--primary-color)">*</span></p>
                            </div>
                          <div class="col-md-9">
                            <input class="ab-input" type="text"   placeholder="Contact Number " name="billing_tel" required >
                         </div>
                     </div>
                              </div>
                              <div class="col-md-12">
                                 
                                   <div class="row" style="align-items: center;">
                              <div class="col-md-3">
                                <p style="font-size: 16px;">Billing Address<span style="color:var(--primary-color)">*</span></p>
                            </div>
                          <div class="col-md-9">
                            <input class="ab-input" type="text"   placeholder="Billing Address " name="billing_address" required>
                         </div>
                     </div>
                              </div>
                            
                             
                              </div>
                               <div class="col-md-12">
                                 
                              <div class="row" style="align-items: center;">
                                 <div class="col-md-3">
                                 </div>
                                
                          <div class="col-md-9">
                               <div class="col-12">
                            
                              <div class="g-recaptcha" data-sitekey="<?php echo e(config('services.recaptcha.key')); ?>"></div>
                           </div>
                           <div class="col-12 mb-2">
                             
                            <?php if($errors->has('g-recaptcha-response')): ?>
                                    <span class="help-block">
                                        <strong><?php echo e($errors->first('g-recaptcha-response')); ?></strong>
                                    </span>
                                <?php endif; ?>           
                           </div>
                         </div>
                     </div>
                              </div>
                            
                           
                              
                              <div class="col-md-12">
                                   <div class="row" style="align-items: center;">
                                 <div class="col-md-3">
                                 </div>
                                 <div class="col-md-9">
                                 <div class="mb-3">
                                    <div class="checkbox">
                                       <label><input type="checkbox" required="true"> By selecting the
                                       check box you agree to our<a target="_blank"
                                         href="<?php echo e(url('terms-conditions')); ?>">
                                       Terms and Conditions</a> &amp;<a target="_blank"
                                          href="<?php echo e(url('refund-policy')); ?>">
                                       Return Policy</a></label>
                                    </div>
                                 </div>
                              </div>
                              </div>
                           </div>
                            <center>  <div class="col-md-12">
                                 <button type="submit" class="btns btn-primary btn-payment submitbtn">Submit</button>
                              </div>
                           </center>
                           </div>
                        </form>
                     </div>
                  </div>
               </div>
            </div>
    
         <div class="col-md-4 sm-100">
            <div class="box-shadow p-0">

         
               <h6 class="fw-600 red-title-bg mb-0 text-center"><i class="fa fa-user fs-14" aria-hidden="true"></i> Need
                  Assistance?
               </h6>   <div class="p-3">
               <div class="mb-2">
                  <p class="mb-0 fs-14">
                     <i class="fa fa-envelope me-2 orrange" aria-hidden="true"></i> WRITE AN EMAIL
                  </p>
                  <a href="mailto:sales@thereportcube.com">sales@thereportcube.com</a>
               </div>
               <div>
                  <p class="mb-0 fs-14"><i class="fa fa-phone me-2 orrange" aria-hidden="true"></i>CALL US</p>
                  <a class="fs-14" href="tel:+91 9876543210">+91 9876543210</a>
               </div>

</div>
            </div>
            <div class="box-shadow p-0">

   
<h6 class="fw-600 red-title-bg text-center mb-0"><i class="fa fa-lock me-2 fs-14 "></i>100% Safe &amp; Secure
               </h6>
               <div class="p-3">
               <hr>
               <p class="fs-14">
                  Strongest encryption on the website to make your purchase safe and secure
               </p>
               <img src="<?php echo e(asset('img/paypal-logo.png')); ?>" class="img-fluid" alt="">
</div>



            </div>
         </div>
      </div>
   </div>
</section>

<!-- plugins -->
<script src="<?php echo e(asset('assets/js/vendors.js')); ?>"></script>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
<script src="http://code.jquery.com/ui/1.11.0/jquery-ui.js"></script>

    <!-- custom app -->
    <script src="<?php echo e(asset('assets/js/app.js')); ?>"></script>
	
	<script type="text/javascript">
	function reloadCaptha(){
	     let base_url = <?php echo json_encode(url('/')); ?>;
	  	$.ajax({
				type: 'GET',
				url: base_url + '/reload-captcha',
				success: function (data) {
					$(".captcha span").html(data.captcha);
				}
			});  
	}
	</script>
<script type="text/javascript">
 
function paymentType(type) {
    if (type == "paypal") {
        document.getElementById("payForm").action = '<?php echo e(url('paypal')); ?>';
    }else{
        document.getElementById("payForm").action = '<?php echo e(url('save_cart_payment')); ?>'; 
    }
}

    $(".update-cart").change(function (e) {
      
        e.preventDefault();
  
        var selectedVal = $(this).val();
       
        $.ajax({
            url: '<?php echo e(route('update.cart')); ?>',
            method: "post",
            data: {
               _token: '<?php echo e(csrf_token()); ?>',
               selectedVal : selectedVal
            },
            success: function (response) {
               window.location.reload();
            }
        });
    });
  
    function remove_cart(id){
        
        if(confirm("Are you sure want to remove?")) {
            $.ajax({
                url: '<?php echo e(route('remove.from.cart')); ?>',
                method: "DELETE",
                data: {
                    _token: '<?php echo e(csrf_token()); ?>', 
                    id: id
                },
                success: function (response) {
                    window.location.reload();
                }
            });
        }
    }
  
</script>



<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout/header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u171619165/domains/vishalghosh.com/public_html/stagingrcube/site/resources/views/cart.blade.php ENDPATH**/ ?>
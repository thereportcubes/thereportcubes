<div class="clearfix">

        <footer class="main-footer">
            <div class="ab-footer-wapper " >
                <div class="ab-footer-main-bar-right" style="color:#f2f2f2; margin-bottom:10px;">
                    <div class="ab-footer-menus">
                        <div class="ab-footer-menus-col">
                            <a href="#"><img loading="lazy" width="150" height="42" src="<?php echo e(asset('img/rcube-logo.png')); ?>" alt="Research and Markets"></a>
                            
                            <ul class="ab-footer-phone-list">
                                <li><a href="tel:+919876543210"><i class="fa fa-phone"></i>+91 9876543210
                                        </a>
                                </li>
                            
                                <li  style="display: list-item;"> <a href="mail:info@rcube.com"><i class="fa fa-envelope"></i> info@rcube.com </a></li>
                                                        
                            </ul>
                        </div>
                        <div class="ab-footer-menus-col">
                            <div class="ab-footer-menus-col-title">Quick Links</div>
                            <ul class="footer_link">
                                <li><a href="<?php echo e(url('about-us')); ?>">About us</a></li>
                                <!-- <li><a href="<?php echo e(url('contact-us')); ?>">Contact-us</a></li> -->
                                <li><a href="<?php echo e(url('/careers')); ?>">Careers</a></li>
                                
                                <li><a href="<?php echo e(url('signin')); ?>">Sign-in/Register</a></li>
                               
                            </ul>
                        </div>
                        <div class="ab-footer-menus-col">
                            <div class="ab-footer-menus-col-title">Products & services </div>
                            <ul class="footer_link">
                                <li><a href="<?php echo e(url('report-store')); ?>">Reports Store</a></li>
                                
                                <li class=""><a href="<?php echo e(url('press-release')); ?>"> Press Release</a></li>
                                <li class=""><a href="<?php echo e(url('infographics')); ?>"> Infographics</a></li>
                            </ul>
                        </div>
                        
                        <div class="ab-footer-menus-col">
                            <div class="ab-footer-menus-col-title">Contact Us</div>                        
                            <ul class="ab-footer-phone-list">
                                <li>
                                    <a href="#"><i class="fa fa-globe"></i>367 Hillcrest Lane,USA</a>
                                </li>
                                <li  style="display: list-item;">
                                    <div class="ab-footer-social">
                                        <a target="_blank" href="#"><i class="fa fa-facebook"></i><span class="ab-screen-reader-text">Facebook</span></a>
                                        <a target="_blank" href="#"><i class="fa fa-instagram"></i><span class="ab-screen-reader-text">Instagram</span></a>
                                        <a target="_blank" href="#"><i class="fa fa-linkedin-square"></i><span class="ab-screen-reader-text">LinkedIn</span></a>
                                        <a target="_blank" href="#"><i class="fa fa-twitter-square"></i><span class="ab-screen-reader-text">Twitter</span></a>
                                        
                                    </div>
                                </li>                    
                            </ul>        
                                
                        </div>
                    
                    </div>
                </div>
          <section class="terms-contationsection py-1">
   <div class="container">
      <div class="row">
         <div class="col-md-12">
            <div class="copyright-bar d-flex justify-content-between">
               <div>
                  <!-- <p class="mb-0 white">&#169; Copyright <?php echo date('Y');?> MarkNtel Advisors LLP - All Rights Reserved</p> -->
               </div>
               <div>
                  <ul class="footer_link mb-0 p-0">
                     <li class="d-inline-block ps-2"><a href="<?php echo e(url('/privacy-policy')); ?>" rel="noopener noreferrer" aria-label="Privacy Policy">Privacy Policy
                        </a>
                     </li>
                     <li class="d-inline-block ps-2">|</li>
                     <li class="d-inline-block ps-2">
                        <a href="<?php echo e(url('/terms-conditions')); ?>" rel="noopener noreferrer" aria-label="Terms and Conditions">Terms and Conditions</a>
                     </li>
                  </ul>
               </div>
            </div>
         </div>
      </div>
   </div>
</section>
                <div class="col-sm-12">
                    <div class="ab-footer-badges col-sm-12"> 
                        <div class="ab-footer-copyright-text" style="width:50%"> Copyright © 2023-2024 R-Cube. All
                            Rights Reserved. 
                        </div>                   
                        <div class="ab-footer-badge--payments" style="text-align:right;width:50%; float:right">
                            <div class="ab-footer-badge--visa" title="VISA"><img loading="lazy" src="<?php echo e(asset('assets/images/payment-icon-visa.webp')); ?>" alt="Payment Icon Visa"></div>
                            <div class="ab-footer-badge--mastercard" title="MasterCard"><img loading="lazy" src="<?php echo e(asset('assets/images/master.png')); ?>" alt="Payment Icon Mastercard">
                            </div>
                            <div class="ab-footer-badge--amex" title="American Express"><img loading="lazy" src="<?php echo e(asset('assets/images/payment-icon-americanexpress.webp')); ?>" alt="Payment Icon Americanexpress"></div> 
                            <div class="ab-footer-badge--paypal" title="American Express"><img loading="lazy" src="<?php echo e(asset('assets/images/paypal.png')); ?>" alt="Payment Icon Americanexpress"></div>                      
                        </div>
                        
                    </div>                    
                </div>
           </div>
        </footer>
    </div>
   
   
   
   
   
    
    <!-- ==================Cookies ======================!-->
    
    <section class="report-section">
       <div class="container">             
          <div id="cookie-banner" class="cookie-banner" style="display:none">
             <div class="row">  
                <div class="col-md-10">
                   <h4><strong>We use cookies to improve your experience</strong></h4>
                   <p>This website uses cookies to ensure you get the best experience on our website. To learn more, visit our <a href="<?php echo e(url('privacy-policy')); ?>" target="_blank" rel="noopener noreferrer" aria-label="Privacy Policy"> Privacy Policy </a>. 
                   <br> By continuing to use this site, or closing this box, you consent to our use of cookies. </p>                  
                </div>
                <div class="col-md-2 text-left">
                   <button onclick="acceptCookies()" class="btns btn-primary mt-4">Accept</button>
                </div>
             </div>         
          </div>
       </div>
    </session>
    
    <button onclick="topFunction()" id="myBtn" title="Go to top">
       
        <img src ="<?php echo e(url('public/img/1.png')); ?>" class="img-fluid lazy" data-src="<?php echo e(asset('img/angle-up.webp')); ?>" />
         
    </button>
    
    <!--<div class="whatsApp_now"><a target="_blank" href="https://wa.me/16288958081"><img src ="<?php echo e(url('public/img/1.png')); ?>" class="img-fluid lazt" data-src="<?php echo e(url('public/img/WhatsApp_icon.png')); ?>" /></a></div>-->
    
    <style>
    
    
   .cart_count {
       margin-top: -26px !important;
    display: block;
    position: relative;
    background: var(--secondary-color);
    top: -16px;
    right: -12px;
    width: 20px;
    height: 20px;
    font-size: 10px;
    text-align: center;
    color: #fff;
    border-radius: 50%;
    margin: 0;
    padding: 4px 0 0;
    font-weight: 700;
}
    .mini-banner {
    
    background-size: cover;
    background-repeat: no-repeat;
}
    .cookie-banner {
    z-index: 999999;
}


.hero_top .slick-prev {
	top: unset !important;
	right: unset !important;
	left: 48% !important;
	bottom: 10px !important;
	z-index: 999;
}

.hero_top .slick-next.slick-arrow {
	top: unset !important;
	right: 48% !important;
	bottom: 10px !important;
	z-index: 999999;
}

.hero_top .slick-slide {
	margin: 0px;
}
.whatsApp_now {
        position: fixed;
        bottom: 10px;
        right: 10px;
        max-width: 55px;
    }
    #myBtn {
        display: none;
        position: fixed;
        bottom: 90px;
        right: 35px;
        z-index: 99;
        font-size: 18px;
        border: none;
        outline: none;
        cursor: pointer;
        border-radius: 4px;
        max-width: 40px;
        background-color: transparent;
    }
    .icon-researchs {
    cursor: pointer;
}


    @media(max-width:768px){
        
        .cart_count {
   
     
    top: -14px !important;
  
}
        .main-content {
    margin-top: unset !important;
}
        .hero_top .slick-next.slick-arrow {
		 
		right: 45% !important;
		 
	}
	.hero_top .slick-prev {
		 
		right: unset !important;
		left: 45% !important;}
		 
        .pagination li {
    margin-bottom: 10px;}

.pagination {
    flex-wrap: wrap;
}
    }
    
    
       @media(max-width:450px){
    .tab-area .nav-link {
    font-size: 14px;
    padding-left: 4px;
    padding-right: 4px;
}}

</style>
 <script src="https://code.jquery.com/jquery-3.6.4.min.js"></script>
<script src="<?php echo e(asset('js/slick.js')); ?>"></script>


  <script>
    function setCookie(cname,cvalue,exdays) {
      const d = new Date();
      d.setTime(d.getTime() + (exdays*24*60*60*1000));
      let expires = "expires=" + d.toUTCString();
      document.cookie = cname + "=" + cvalue + ";" + expires + ";path=/";
    }
    
    function getCookie(cname) {
      let name = cname + "=";
      let decodedCookie = decodeURIComponent(document.cookie);
      let ca = decodedCookie.split(';');
      for(let i = 0; i < ca.length; i++) {
        let c = ca[i];
        while (c.charAt(0) == ' ') {
          c = c.substring(1);
        }
        if (c.indexOf(name) == 0) {
          return c.substring(name.length, c.length);
        }
      }
      return "";
    }
    
    function checkCookie() {
             
       let user = getCookie("PrivacyCookie");
       if (user != "") {
          document.getElementById('cookie-banner').style.display = 'none';
       } else {
          document.getElementById('cookie-banner').style.display = 'block';
      }
    }
    
    function acceptCookies() {
       document.getElementById('cookie-banner').style.display = 'none';
       setCookie('PrivacyCookie', 'accepted', 300); // Set to expire in 365 days
    }
    // Get the button
    let mybutton = document.getElementById("myBtn");
    // When the user scrolls down 20px from the top of the document, show the button
    window.onscroll = function() {scrollFunction()};
    function scrollFunction() {
      if (document.body.scrollTop > 20 || document.documentElement.scrollTop > 20) {
        mybutton.style.display = "block";
      } else {
        mybutton.style.display = "none";
      }
    }
    
    // When the user clicks on the button, scroll to the top of the document
    function topFunction() {
      document.body.scrollTop = 0;
      document.documentElement.scrollTop = 0;
    }
$(document).ready(function () {
    checkCookie();
            $('.lazy').lazy();

  $('.icon-researchs').click(function () {
      var accordionItem = $(this).parent('.research-accordion-item');
      var content_research = accordionItem.next('.content_research');
      if (accordionItem.hasClass('active')) {
          accordionItem.removeClass('active');
          content_research.slideUp();
          $(this).html('<i class="fa fa-plus" aria-hidden="true"></i>');
      } else {
          $('.research-accordion-item.active').removeClass('active').find('.icon-research').html('<i class="fa fa-plus" aria-hidden="true"></i>');
          $('.content_research').slideUp();
          accordionItem.addClass('active');
          content_research.slideDown();
          $(this).html('<i class="fa fa-minus"></i>');
      }
  });
  var input = document.querySelector("#phone3");
  if(input != null){
      window.intlTelInput(input, {
         separateDialCode: true,
         excludeCountries: ["il"],
         preferredCountries: ["us","ru", "jp", "pk", "no"],
         defaultCountry: "us",
         initialCountry: "US",
      });
  }
  var input2 = document.querySelector("#phone_number");
  if(input2 != null){
      window.intlTelInput(input2, {
         separateDialCode: true,
         excludeCountries: ["il"],
         preferredCountries: ["us","ru", "jp", "pk", "no"],
         defaultCountry: "us",
         initialCountry: "US",
      });
  }
   $('#search_123').on('keyup',function(){
      $value=$(this).val();
      if($value == ""){
         $("#search_result").css("display","none");
      }
      else{
         $.ajax({
            type : 'post',
            url : '<?php echo e(URL::to('report_search')); ?>',
            data:{'search':$value, _token: '<?php echo e(csrf_token()); ?>'},
               success:function(data){
               
               if(data != ""){
                  $("#search_result").css("display","block");
                  $("#search_result").html(data);
               }
               else{
                  $(".search_result_data").css("border","1px solid #fff");
               }
            }
         });
      }        
   });
   
   $(document).on('click', function (e) {
      if ($(e.target).closest("#search_result").length === 0) {
         $("#search_result").hide();
      }
   });

      $('.reg_btn').on('click', function(event) {
         
         event.preventDefault();
         let fname = $("#first_name").val();
         let lname = $("#last_name").val();
         let m0b_num = $("#phone3").val();
         let pass = $("#paasword").val();
         let email = $("#email").val();
         if(fname == "" || email == "" || m0b_num == "" || pass == ""){
            $("#reg_msg").css('display','block')
            $("#reg_msg").html('Sorry!! All Fields are required.');
         }
         else{
            $.ajax({
               headers: {
                  'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
               },
               url: '<?php echo e(url("/register")); ?>',
               type: 'post',
               data: {"fname":fname, "lname":lname, "mob":m0b_num, "pass":pass, "email":email},
               success: function(response) {
                  $("#reg_msg").css('display','block')
                  $("#reg_msg").html(response)
               },
               
            });
         }         
      });
    $(document).on("submit", "#handleAjax", function() {
     var e = this;
     $(this).find("[type='submit']").html("Login...");
     $.ajax({
        url: $(this).attr('action'),
        data: $(this).serialize(),
        type: "POST",
        dataType: 'json',
        success: function (data) {
           $(e).find("[type='submit']").html("Login");
           if (data.status) {
              window.location = data.redirect;
           }else{
              $(".alert").remove();
              $.each(data.errors, function (key, val) {
                    $("#errors-list").append("<div class='alert alert-danger'>" + val + "</div>");
              });
           }
        }
    });
     return false;
    });
   let base_url_reg = <?php echo json_encode(url('/')); ?>;
   $('#reload_register').click(function () {
      $.ajax({
         type: 'GET',
         url: base_url_reg + '/reload-captcha',
         success: function (data) {
            $(".captcha span").html(data.captcha);
         }
      });
   });
   let base_url = <?php echo json_encode(url('/')); ?>;
   $('#reload_login').click(function () {
      $.ajax({
         type: 'GET',
         url: base_url + '/reload-captcha',
         success: function (data) {
            $(".captcha span").html(data.captcha);
         }
      });
   });
});
// var Tawk_API=Tawk_API||{}, Tawk_LoadStart=new Date();
// (function(){
//     var s1=document.createElement("script"),s0=document.getElementsByTagName("script")[0];
//     s1.async=true;
// //s1.rel=preconnect;
//     s1.src='https://embed.tawk.to/5eabccf4203e206707f88c70/default';
//     s1.charset='UTF-8';
//     s1.setAttribute('crossorigin','*');
//     s0.parentNode.insertBefore(s1,s0);
// })();
//   $('.hero_top').slick({
//   infinite: true,
//   slidesToShow: 1,
//   slidesToScroll: 1,
//   autoplay:true,
//   dots: false,

//   speed: 300,
// });
  var base_path = "<?php echo e(url('/')); ?>/";
    var base_url = "<?php echo e(url('/')); ?>/";
      function googleTranslateElementInit() {
      new google.translate.TranslateElement({pageLanguage: 'en',includedLanguages: 'en,ar,es,fr,ja,pt,ru,zh-CN,zh-TW', layout: google.translate.TranslateElement.InlineLayout.SIMPLE}, 'google_translate_element');

      var $googleDiv = $("#google_translate_element .skiptranslate");
      var $googleDivChild = $("#google_translate_element .skiptranslate div");
      $googleDivChild.next().remove();

      $googleDiv.contents().filter(function(){
         return this.nodeType === 3 && $.trim(this.nodeValue) !== '';
      }).remove();

      }

function googleTranslateElementInit() {
    new google.translate.TranslateElement({pageLanguage: 'en'}, 'google_translate_element');
  }

    $(document).on('click', function (e) {
    if ($(e.target).closest("#search_result").length === 0) {
        $("#search_result").hide();
    }
    });
   </script>
   <script src="<?php echo e(asset('js/custom.js')); ?>"  async defer></script>
   <script src="<?php echo e(asset('js/bootstrap.bundle.min.js')); ?>" defer></script>
   <script src="https://cdnjs.cloudflare.com/ajax/libs/intl-tel-input/17.0.8/js/intlTelInput.min.js"  async defer></script>
<script src="https://www.google.com/recaptcha/api.js" async defer></script>
    <script type="text/javascript" src="//cdnjs.cloudflare.com/ajax/libs/jquery.lazy/1.7.9/jquery.lazy.min.js"></script>
    <script type="text/javascript" src="//cdnjs.cloudflare.com/ajax/libs/jquery.lazy/1.7.9/jquery.lazy.plugins.min.js" ></script>
    <script type="text/javascript" src="https://translate.google.com/translate_a/element.js?cb=googleTranslateElementInit"  async defer>
        
    </script> 
<!-- <script  async defer src="https://www.googletagmanager.com/gtag/js?id=G-MWFKERQNK1"></script> <script> window.dataLayer = window.dataLayer || []; function gtag(){dataLayer.push(arguments);} gtag('js', new Date()); gtag('config', 'G-MWFKERQNK1'); </script> -->

    <script>window.gtranslateSettings = {"default_language":"en","detect_browser_language":true,"languages":["en","fr","hi"],"wrapper_selector":".gtranslate_wrapper","flag_size":24,"alt_flags":{"en":"usa"}}</script>
    
        <script src="<?php echo e(asset('/js/gtranslate.js')); ?>" defer></script>
</script>
<script>
    // Initialize Bootstrap collapse
    $(document).ready(function() {
        $('.collapse').collapse(); // This line initializes all collapse elements
    });
</script>
</body>

</html><?php /**PATH /home/u171619165/domains/vishalghosh.com/public_html/stagingrcube/site/resources/views/layout/footer.blade.php ENDPATH**/ ?>
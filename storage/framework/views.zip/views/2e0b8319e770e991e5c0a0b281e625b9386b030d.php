<!DOCTYPE html>
<html lang="en">
<head>
      <meta charset="UTF-8">
      <meta http-equiv="X-UA-Compatible" content="IE=edge">
      <meta name="viewport" content="width=device-width, initial-scale=1.0">
      <meta name="robots" content="index, follow" />
      <meta name="yandex-verification" content="31b05a2a28d743b6" />
      <meta name="p:domain_verify" content="91cd8730d105faa5d55cd898de4e9af2"/>
      <meta name="norton-safeweb-site-verification" content="59vg4vs5poof0t659x47nc6uezxylo7bppa54vjnvn8sa56mquwo-puv39yggge5q31aoaarf82yxpgg9cpbj73128titm5072peiepftbeqzfhz6lh11s5jtxcd29ay" />
      <meta name="wot-verification" content="3141c2494bcd373559b7"/>
      <meta name="author" content="marknteladvisors">
      
    <script type="application/ld+json">
     {

      "@context": "https://schema.org",
      "@type": "Organization",
      "name": "MarkNtel Advisors",
      "alternateName": "markntel",
      "url": "https://www.marknteladvisors.com/",
      "logo": "<?php echo e(url('public/img/logo.webp')); ?>",

      "contactPoint": [{

         "@type": "ContactPoint",
         "telephone": "+91 120 4278433",
         "contactType": "customer service",
         "areaServed": "Global",
         "availableLanguage": "en"

      },{

         "@type": "ContactPoint",
         "telephone": "+91 120 4278433",
         "contactType": "customer service",
         "areaServed": "In",
         "availableLanguage": "en"
         },
      {

         "@type": "ContactPoint",
         "telephone": "+1 628 895 8081",
         "contactType": "customer service",
         "areaServed": "USA",
         "availableLanguage": "en"

      }],

      "email" : " sales@marknteladvisors.com",

      "address" : {

      "@type" : "PostalAddress",

      "streetAddress" : "Office No.106, H-160, Sector 63,",
      "addressLocality" : "Noida",
      "addressRegion" : "Noida",
      "addressCountry" : "IN",
      "postalCode" : "201301"

      },

      "sameAs": [

         "https://twitter.com/markntel",
         "https://linkedin.com/company/markntel-advisors",
         "https://www.youtube.com/c/MarkNtelAdvisorsLLP",
         "https://in.pinterest.com/marknteladvisors"

      ]

      }

   </script>

  <?php 
   $seo_data = "";
   $seo_slug_url = "";

   $seo_slug_url_type = request()->segment(1);
   
   $seo_slug_url = request()->segment(2);
 
   if($seo_slug_url_type == "infographics" &&  $seo_slug_url !=""){
      
      $parent_id =\DB::table('infographic')->where('slug',$seo_slug_url)->first();      
      
    //   $seo_data_count =\DB::table('seo_content')->where('parent_id',$parent_id->id)->where('page_type','infographics')->orderBy('id','DESC')->count();
    //   if($seo_data_count > 0){
    //       $seo_data =\DB::table('seo_content')->where('parent_id',$parent_id->id)->where('page_type','infographics')->orderBy('id','DESC')->first();
    //   }
if(!is_null($parent_id)){
   ?>
      <title><?php echo @$parent_id->seo_title ;?></title>
      <meta name="description" content="<?php echo @$parent_id->seo_description ; ?>" />
      <meta name="keywords" content="<?php echo @$parent_id->seo_keyword ; ?>">
      <link rel="canonical" href="<?php echo e(url()->current()); ?>" />

      <meta property="og:type" content="news" />
      <meta property="og:title" content="<?php echo @$parent_id->seo_title ;?>" />
      <meta property="og:image" content="<?php echo e(url('public/img/logo.webp')); ?>" />
      <meta property="og:description" content="<?php echo @$parent_id->seo_description ;?>"/>
      <meta property="og:url" content="<?php echo e(url()->current()); ?>">

      <meta name="twitter:card" content="<?php echo e(url('public/img/logo.webp')); ?>" />
      <meta name="twitter:site" content="marknteladvisors" />
      <meta name="twitter:title" content="<?php echo @$parent_id->seo_title ;?>" />
      <meta name="twitter:description" content="<?php echo @$parent_id->seo_description ;?>" />
      <base href="<?php echo e(url()->current()); ?>">

      <script type="application/ld+json">  
      {
      "@context": "https://schema.org",
      "@type": "BreadcrumbList",
         "itemListElement": [                                       
                              {
                                 "@type": "ListItem",
                                 "position": 1,
                                 "item": {
                                    "@type": "webpage",
                                    "@id": "<?php echo e(url('/')); ?>",
                                    "name": "Home"
                                 }
                              },
                              {
                                    "@type": "ListItem",
                                    "position": 2,
                                    "item": {
                                          "@type": "webpage",
                                          "@id": "<?php echo e(url('/infographics')); ?>",
                                          "name": "Infographics"
                                    }
                              },
                              {
                                    "@type": "ListItem",
                                    "position": 3,
                                    "item": {
                                          "@type": "webpage",
                                          "@id": "<?php echo e(url('/infographics')); ?>/<?php echo e(request()->segment(2)); ?>",
                                          "name": "<?php echo e($parent_id->title); ?>"
                                    }
                              }
                           ]
      }

   </script>

   <?php }}

   else if($seo_slug_url_type == "infographics" && $seo_slug_url ==""){ ?>
      
      <title>Market Research Reports Infographics - MarkNtel Advisor</title>
      <meta name="keywords" content="Market Research Infographics, Market Research Reports Infographics, Infographics">
      <meta name="description" content="MarkNtel Advisors anticipate market growth, analysis, demand and mention in the form of infographics for across sectors like Aerospace and Defense, Automotive, Building, Construction, Metals and Mining, Chemicals, Energy, healthcare, Food and Beverages etc." />
      <link rel="canonical" href="<?php echo e(url()->current()); ?>" />

      <meta property="og:type" content="news" />
      <meta property="og:title" content="Market Research Reports Infographics - MarkNtel Advisors" />
      <meta property="og:image" content="https://www.marknteladvisors.com/theme/image/logo.png" />
      <meta property="og:description" content="MarkNtel Advisors anticipate market growth, analysis, demand and mention in the form of infographics for across sectors like Aerospace and Defense, Automotive, Building, Construction, Metals and Mining, Chemicals, Energy, healthcare, Food and Beverages etc."/>
      <meta property="og:url" content="<?php echo e(url()->current()); ?>">

      <meta name="twitter:card" content="https://www.marknteladvisors.com/theme/image/logo.png" />
      <meta name="twitter:site" content="marknteladvisors" />
      <meta name="twitter:title" content="Market Research Reports Infographics - MarkNtel Advisors" />
      <meta name="twitter:description" content="MarkNtel Advisors anticipate market growth, analysis, demand and mention in the form of infographics for across sectors like Aerospace and Defense, Automotive, Building, Construction, Metals and Mining, Chemicals, Energy, healthcare, Food and Beverages etc." />
      <base href="<?php echo e(url()->current()); ?>">

      <script type="application/ld+json">  
      {
      "@context": "https://schema.org",
      "@type": "BreadcrumbList",
         "itemListElement": [                                       
                              {
                                 "@type": "ListItem",
                                 "position": 1,
                                 "item": {
                                    "@type": "webpage",
                                    "@id": "<?php echo e(url('/')); ?>",
                                    "name": "Home"
                                 }
                              },
                              {
                                    "@type": "ListItem",
                                    "position": 2,
                                    "item": {
                                          "@type": "webpage",
                                          "@id": "<?php echo e(url('/infographics')); ?>",
                                          "name": "Infographics"
                                    }
                              }
                           ]
      }

   </script>

   <?php } 

   else if($seo_slug_url_type == "press-release" && $seo_slug_url != ""){ 
$button_ref ='';
      $parent_id =\DB::table('press_release')->where('press_release_url',$seo_slug_url)->first(); 
      if(!is_null($parent_id)){
      $button_ref = $parent_id->button_refrence;
      if($button_ref !=""){
         $but_ref = explode('/',$button_ref);
         $report =\DB::table('reports')->where('page_url',$but_ref['4'])->first(); 
        // print_r($but_ref); die;
      }
      $seo_data =\DB::table('seo_content')->where('parent_id',$parent_id->id)->where('page_type','press_release')->orderBy('id','DESC')->first(); 
      } else {
          $seo_data =\DB::table('seo_content')->where('page_type','press_release')->orderBy('id','DESC')->first(); 
      }
      
   ?>
      <title><?php echo $seo_data->seo_title ;?></title>
      <meta name="description" content="<?php echo $seo_data->seo_description ;?>" />
      <meta name="keywords" content="<?php echo $seo_data->seo_key_words ;?>">
      <link rel="canonical" href="<?php echo e(url()->current()); ?>" />

      <meta property="og:type" content="news" />
      <meta property="og:title" content="<?php echo $seo_data->seo_title ;?>" />
      <meta property="og:image" content="https://www.marknteladvisors.com/theme/image/logo.png" />
      <meta property="og:description" content="<?php echo $seo_data->seo_description ;?>"/>
      <meta property="og:url" content="<?php echo e(url()->current()); ?>">

      <meta name="twitter:card" content="https://www.marknteladvisors.com/theme/image/logo.png" />
      <meta name="twitter:site" content="marknteladvisors" />
      <meta name="twitter:title" content="<?php echo $seo_data->seo_title ;?>" />
      <meta name="twitter:description" content="<?php echo $seo_data->seo_description ;?>" />
      <base href="<?php echo e(url()->current()); ?>">

      <script type="application/ld+json">  
      {
      "@context": "https://schema.org",
      "@type": "BreadcrumbList",
         "itemListElement": [                                       
               {
                  "@type": "ListItem",
                  "position": 1,
                  "item": {
                     "@type": "webpage",
                     "@id": "<?php echo e(url('/')); ?>",
                     "name": "Home"
                  }
               },
               {
                     "@type": "ListItem",
                     "position": 2,
                     "item": {
                           "@type": "webpage",
                           "@id": "<?php echo e(url('/press-release')); ?>",
                           "name": "Press Release"
                     }
               },
               {
                     "@type": "ListItem",
                     "position": 3,
                     "item": {
                           "@type": "webpage",
                           "@id": "<?php echo e(url('/press-release')); ?>/<?php echo e(request()->segment(2)); ?>",
                           "name": "<?php echo e(@$report->title); ?>"
                     }
               }
            ]
      }

   </script>

   <?php } 
   
    else if($seo_slug_url_type == "press-release" && $seo_slug_url == ""){ 
    $parent_id = \DB::table('seo_pages')->where('page_key','press_release')->first();
    $seo_content = \DB::table('seo_content')->where('parent_id',$parent_id->id)->where('page_type','press_release')->first();
   ?>
      <title><?php echo $seo_content->seo_title; ?></title>
      <meta name="description" content="<?php echo $seo_content->seo_description; ?>" />
      <meta name="keywords" content="<?php echo $seo_content->seo_key_words; ?>">
      <link rel="canonical" href="<?php echo e(url()->current()); ?>" />

      <meta property="og:type" content="news" />
      <meta property="og:title" content="<?php echo $seo_content->seo_title; ?>" />
      <meta property="og:image" content="https://www.marknteladvisors.com/theme/image/logo.png" />
      <meta property="og:description" content="<?php echo $seo_content->seo_description; ?>"/>
      <meta property="og:url" content="<?php echo e(url()->current()); ?>">

      <meta name="twitter:card" content="https://www.marknteladvisors.com/theme/image/logo.png" />
      <meta name="twitter:site" content="marknteladvisors" />
      <meta name="twitter:title" content="<?php echo $seo_content->seo_title; ?>" />
      <meta name="twitter:description" content="<?php echo $seo_content->seo_description; ?>" />
      <base href="<?php echo e(url()->current()); ?>">

      <script type="application/ld+json">  
      {
      "@context": "https://schema.org",
      "@type": "BreadcrumbList",
         "itemListElement": [                                       
               {
                  "@type": "ListItem",
                  "position": 1,
                  "item": {
                     "@type": "webpage",
                     "@id": "<?php echo e(url('/')); ?>",
                     "name": "Home"
                  }
               },
               {
                     "@type": "ListItem",
                     "position": 2,
                     "item": {
                           "@type": "webpage",
                           "@id": "<?php echo e(url('/press-release')); ?>",
                           "name": "Press Release"
                     }
               }
               
            ]
      }

   </script>

   <?php } 

   else if($seo_slug_url_type == "contact-us" && $seo_slug_url == ""){ 
      
      $seo_data =\DB::table('seo_content')->where('page_type','contact_us')->orderBy('id','DESC')->first(); 
   ?>         
   
      <title><?php echo $seo_data->seo_title ;?></title>
      <meta name="description" content="<?php echo $seo_data->seo_description ;?>" />
      <meta name="keywords" content="<?php echo $seo_data->seo_key_words ;?>">
      <link rel="canonical" href="<?php echo e(url()->current()); ?>" />

      <meta property="og:type" content="news" />
      <meta property="og:title" content="<?php echo $seo_data->seo_title ;?>" />
      <meta property="og:image" content="https://www.marknteladvisors.com/theme/image/logo.png" />
      <meta property="og:description" content="<?php echo $seo_data->seo_description ;?>"/>
      <meta property="og:url" content="<?php echo e(url()->current()); ?>">

      <meta name="twitter:card" content="https://www.marknteladvisors.com/theme/image/logo.png" />
      <meta name="twitter:site" content="marknteladvisors" />
      <meta name="twitter:title" content="<?php echo $seo_data->seo_title ;?>" />
      <meta name="twitter:description" content="<?php echo $seo_data->seo_description ;?>" />
      <base href="<?php echo e(url()->current()); ?>">

      <script type="application/ld+json">  
         {
         "@context": "https://schema.org",
         "@type": "BreadcrumbList",
            "itemListElement": [
                                             
                                 {
                                    "@type": "ListItem",
                                    "position": 1,
                                    "item": {
                                       "@type": "webpage",
                                       "@id": "<?php echo e(url('/')); ?>",
                                       "name": "Home"
                                    }
                                 },
                                 {
                                 "@type": "ListItem",
                                 "position": 2,
                                 "item": {
                                       "@type": "webpage",
                                       "@id": "<?php echo e(url('/contact-us')); ?>",
                                       "name": "Indexphp"
                                    }
                                 }
                     ]
         }
      </script>
   
   <?php } 
   
   else if($seo_slug_url_type == "" && $seo_slug_url == ""){ 
      $seo_data =\DB::table('seo_content')->where('page_type','home')->orderBy('id','DESC')->first(); 
   ?>
         
   
      <title><?php echo $seo_data->seo_title ;?></title>
      <meta name="description" content="<?php echo $seo_data->seo_description ;?>" />
      <meta name="keywords" content="<?php echo $seo_data->seo_key_words ;?>">
      <link rel="canonical" href="<?php echo e(url()->current()); ?>" />

      <meta property="og:type" content="news" />
      <meta property="og:title" content="<?php echo $seo_data->seo_title ;?>" />
      <meta property="og:image" content="<?php echo e(url('public/img/logo.webp')); ?>" />
      <meta property="og:description" content="<?php echo $seo_data->seo_description ;?>"/>
      <meta property="og:url" content="<?php echo e(url()->current()); ?>">

      <meta name="twitter:card" content="<?php echo e(url('public/img/logo.webp')); ?>" />
      <meta name="twitter:site" content="marknteladvisors" />
      <meta name="twitter:title" content="<?php echo $seo_data->seo_title ;?>" />
      <meta name="twitter:description" content="<?php echo $seo_data->seo_description ;?>" />
      <base href="<?php echo e(url()->current()); ?>">
   
   <script type="application/ld+json">

   {

   "@context": "https://schema.org/",
   "@type": "WebSite",
   "name": "MarkNtel Advisors",
   "url": "https://www.marknteladvisors.com/",

   "potentialAction": {

      "@type": "SearchAction",
      "target": "https://www.marknteladvisors.com/search?search={search_term_string}",
      "query-input": "required name=search_term_string"
      }

   }

   </script>

   
   
   <?php } else if($seo_slug_url_type == "about-us" && $seo_slug_url == ""){ 
      
      $seo_data =\DB::table('seo_content')->where('page_type','about_us')->orderBy('id','DESC')->first(); 
   ?>         
   
      <title><?php echo $seo_data->seo_title ;?></title>
      <meta name="description" content="<?php echo $seo_data->seo_description ;?>" />
      <meta name="keywords" content="<?php echo $seo_data->seo_key_words ;?>">
      <link rel="canonical" href="<?php echo e(url()->current()); ?>" />

      <meta property="og:type" content="news" />
      <meta property="og:title" content="<?php echo $seo_data->seo_title ;?>" />
      <meta property="og:image" content="https://www.marknteladvisors.com/theme/image/logo.png" />
      <meta property="og:description" content="<?php echo $seo_data->seo_description ;?>"/>
      <meta property="og:url" content="<?php echo e(url()->current()); ?>">

      <meta name="twitter:card" content="https://www.marknteladvisors.com/theme/image/logo.png" />
      <meta name="twitter:site" content="marknteladvisors" />
      <meta name="twitter:title" content="<?php echo $seo_data->seo_title ;?>" />
      <meta name="twitter:description" content="<?php echo $seo_data->seo_description ;?>" />
      <base href="<?php echo e(url()->current()); ?>" >
   
   <?php } else if($seo_slug_url_type == "careers" && $seo_slug_url == ""){ 
      
      $seo_data =\DB::table('seo_content')->where('page_type','careers')->orderBy('id','DESC')->first(); 
   ?>         
   
      <title><?php echo @$seo_data->seo_title ;?></title>
      <meta name="description" content="<?php echo @$seo_data->seo_description ;?>" />
      <meta name="keywords" content="<?php echo @$seo_data->seo_key_words ;?>">
      <link rel="canonical" href="<?php echo e(url()->current()); ?>" />

      <meta property="og:type" content="news" />
      <meta property="og:title" content="<?php echo @$seo_data->seo_title ;?>" />
      <meta property="og:image" content="https://www.marknteladvisors.com/theme/image/logo.png" />
      <meta property="og:description" content="<?php echo @$seo_data->seo_description ;?>"/>
      <meta property="og:url" content="<?php echo e(url()->current()); ?>">

      <meta name="twitter:card" content="https://www.marknteladvisors.com/theme/image/logo.png" />
      <meta name="twitter:site" content="marknteladvisors" />
      <meta name="twitter:title" content="<?php echo @$seo_data->seo_title ;?>" />
      <meta name="twitter:description" content="<?php echo @$seo_data->seo_description ;?>" />
      <base href="<?php echo e(url()->current()); ?>">
   
   <?php } else if($seo_slug_url_type == "export-import-data" && $seo_slug_url == ""){ 
      
      $seo_data =\DB::table('seo_content')->where('page_type','tire_exim')->orderBy('id','DESC')->first(); 
   ?>         
   
      <title><?php echo $seo_data->seo_title ;?></title>
      <meta name="description" content="<?php echo $seo_data->seo_description ;?>" />
      <meta name="keywords" content="<?php echo $seo_data->seo_key_words ;?>">
      <link rel="canonical" href="<?php echo e(url()->current()); ?>" />

      <meta property="og:type" content="news" />
      <meta property="og:title" content="<?php echo $seo_data->seo_title ;?>" />
      <meta property="og:image" content="https://www.marknteladvisors.com/theme/image/logo.png" />
      <meta property="og:description" content="<?php echo $seo_data->seo_description ;?>"/>
      <meta property="og:url" content="<?php echo e(url()->current()); ?>">

      <meta name="twitter:card" content="https://www.marknteladvisors.com/theme/image/logo.png" />
      <meta name="twitter:site" content="marknteladvisors" />
      <meta name="twitter:title" content="<?php echo $seo_data->seo_title ;?>" />
      <meta name="twitter:description" content="<?php echo $seo_data->seo_description ;?>" />
      <base href="<?php echo e(url()->current()); ?>" >
   
   <?php } else if($seo_slug_url_type == "upcoming-reports" && $seo_slug_url == ""){ 
      
      $seo_data =\DB::table('seo_content')->where('page_type','upcoming_reports')->orderBy('id','DESC')->first(); 
   ?>         
   
      <title><?php echo $seo_data->seo_title ;?></title>
      <meta name="description" content="<?php echo $seo_data->seo_description ;?>" />
      <meta name="keywords" content="<?php echo $seo_data->seo_key_words ;?>">
      <link rel="canonical" href="<?php echo e(url()->current()); ?>" />

      <meta property="og:type" content="news" />
      <meta property="og:title" content="<?php echo $seo_data->seo_title ;?>" />
      <meta property="og:image" content="https://www.marknteladvisors.com/theme/image/logo.png" />
      <meta property="og:description" content="<?php echo $seo_data->seo_description ;?>"/>
      <meta property="og:url" content="<?php echo e(url()->current()); ?>">

      <meta name="twitter:card" content="https://www.marknteladvisors.com/theme/image/logo.png" />
      <meta name="twitter:site" content="marknteladvisors" />
      <meta name="twitter:title" content="<?php echo $seo_data->seo_title ;?>" />
      <meta name="twitter:description" content="<?php echo $seo_data->seo_description ;?>" />
      <base href="<?php echo e(url()->current()); ?>" >

      <script type="application/ld+json">  
      {
      "@context": "https://schema.org",
      "@type": "BreadcrumbList",
         "itemListElement": [
                                          
            {
            "@type": "ListItem",
            "position": 1,
            "item": {
                  "@type": "webpage",
                  "@id": "<?php echo e(url('/')); ?>",
                  "name": "Home"
               }
            },
                     
            {
            "@type": "ListItem",
            "position": 2,
            "item": {
                  "@type": "webpage",
                  "@id": "<?php echo e(url('/upcoming-reports')); ?>",
                  "name": "Upcoming Reports"
               }
            }
                                       
         ]
      }

   </script>
   
    <?php } else if($seo_slug_url_type == "research-library" && $seo_slug_url != "" ){ 
       
       
        $report_slug_check = \DB::table('reports')->where('page_url',$seo_slug_url)->count();
        $report_slug_category_check = \DB::table('category')->where('category_url',$seo_slug_url)->count();
        $report_slug_subcategory_check = \DB::table('sub_category')->where('page_url',$seo_slug_url)->count();
        
        if($report_slug_check > 0) {
            $parent_id = \DB::table('reports')->where('page_url',$seo_slug_url)->first();
            $seo_data =\DB::table('seo_content')->where('parent_id',$parent_id->id)->where('page_type','report')->orderBy('id','DESC')->first();
            ?>
                <script type="application/ld+json">
            	{
            		"@context": "https://schema.org/",
            		"@type": "Dataset",
            		"name": "<?php echo e(@$parent_id->title); ?>",
            
               		"description": ["<?php echo @$seo_data->seo_description ;?>"],	
            		"url": "https://www.marknteladvisors.com/research-library/<?php echo e(@$parent_id->page_url); ?>",
            		"sameAs": "https://www.marknteladvisors.com/research-library/<?php echo e(@$parent_id->page_url); ?>",
            		"license": "https://www.marknteladvisors.com/privacy-policy",
            		"keywords": ["<?php echo @$seo_data->seo_key_words ;?>"],
            		"temporalCoverage": "2024-30",
            		"spatialCoverage": "Global",
            		"creator": {
            			"@type": "Organization",
            			"url": "https://www.marknteladvisors.com/",
            			"name": "MarkNtel Advisors",
            			"logo": {
            				"@type": "ImageObject",
            				"url": "https://www.marknteladvisors.com/public/img/logo.webp"
            			}
            		}
            	}
            </script>
            <?php 
        }
        else if($report_slug_category_check > 0){ 
            $parent_id = \DB::table('category')->where('category_url',$seo_slug_url)->first();
            $seo_data =\DB::table('seo_content')->where('parent_id',$parent_id->id)->where('page_type','category')->orderBy('id','DESC')->first();
        }
        else if($report_slug_subcategory_check > 0){
            $parent_id = \DB::table('sub_category')->where('page_url',$seo_slug_url)->first();
            $seo_data =\DB::table('seo_content')->where('parent_id',$parent_id->id)->where('page_type','sub_ctegory')->orderBy('id','DESC')->first();
        }
        
    ?>         
   
      <title><?php echo @$seo_data->seo_title ;?></title>
      <meta name="description" content="<?php echo @$seo_data->seo_description ;?>" />
      <meta name="keywords" content="<?php echo @$seo_data->seo_key_words ;?>">
      <link rel="canonical" href="<?php echo e(url()->current()); ?>" />

      <meta property="og:type" content="news" />
      <meta property="og:title" content="<?php echo @$seo_data->seo_title ;?>" />
      <meta property="og:image" content="https://www.marknteladvisors.com/theme/image/logo.png" />
      <meta property="og:description" content="<?php echo @$seo_data->seo_description ;?>"/>
      <meta property="og:url" content="<?php echo e(url()->current()); ?>">

      <meta name="twitter:card" content="https://www.marknteladvisors.com/theme/image/logo.png" />
      <meta name="twitter:site" content="marknteladvisors" />
      <meta name="twitter:title" content="<?php echo @$seo_data->seo_title ;?>" />
      <meta name="twitter:description" content="<?php echo @$seo_data->seo_description ;?>" />
      <base href="<?php echo e(url()->current()); ?>" >

      
    <script type="application/ld+json">  
              {
              "@context": "https://schema.org",
              "@type": "BreadcrumbList",
                 "itemListElement": [
                                                  
                    {
                    "@type": "ListItem",
                    "position": 1,
                    "item": {
                          "@type": "webpage",
                          "@id": "<?php echo e(url('/')); ?>",
                          "name": "Home"
                       }
                    },
                             
                    {
                    "@type": "ListItem",
                    "position": 2,
                    "item": {
                          "@type": "webpage",
                          "@id": "<?php echo e(url('/research-library')); ?>",
                          "name": "Research Library"
                       }
                    },
                             
                    {
                    "@type": "ListItem",
                    "position": 3,
                    "item": {
                          "@type": "webpage",
                          "@id": "<?php echo e(url('/research-library')); ?>/<?php echo e($seo_slug_url); ?>",
                          "name": "<?php echo e(@$seo_data->seo_title); ?>"
                       }
                    }
                                               
                 ]
              }
        
            </script>

    

   
    <?php if($report_slug_check > 0) { 
            
        $datas = \DB::table('reports')->where('page_url',$seo_slug_url)->first();
        $faqs = json_decode($datas->faqs);  
        $size = count((array)$faqs->ques);
        $m=1;
        if($size>0){
    ?>
    
        <script type="application/ld+json">
        {
            "@context": "https://schema.org",
            "@type": "FAQPage",
            "mainEntity": [
                <?php 
                    for($i=0 ; $i<$size; $i++) { 
                        if($faqs->ques[$i] !=""){ 
                    ?>
                    {
                        "@type": "Question",
                        "name": "Q. <?php echo e($faqs->ques[$i]); ?>",
                        "acceptedAnswer": {
                            "@type": "Answer",
                            "text": "A. <?php echo e($faqs->ans[$i]); ?>"
                        }
                    }<?php if($i<$size-1) { echo ","; } ?>
                <?php } } ?>
                
            ]
        }
        </script>
    <?php } } ?>
    
    <?php 
    if (strpos(@$parent_id->title, 'Global') !== false  && @$parent_id->report_post_date > '2020-12-31') { 
     
      $newprice = "";
      if($parent_id->single_licence_price){
         $newprice = str_replace(',','',$parent_id->single_licence_price);
      }
   
   ?>
   <script type="application/ld+json">  
      {
         "@context": "https://schema.org/",
         "@type": "Product",
         "name": "<?php echo e(@$parent_id->title); ?>",
         "image": [
         "<?php echo e(url('public/img/logo.webp')); ?>"
         ],
         "description": "<?php echo e(@$parent_id->schema_desc); ?>",
         "sku" : "<?php echo e(@$parent_id->report_code); ?>",
         "mpn": "<?php echo e(@$parent_id->report_code); ?>",
         "brand": 
         {
            "@type": "brand",
            "name": "MarkNtel Advisors"
         },
         "review": 
         {
            "@type": "Review",
            "reviewRating": 
            {
            "@type": "Rating",
            "ratingValue": "<?php echo e(@$parent_id->rating_value); ?>",
            "bestRating": "5"
            },
            "author": 
            {
            "@type": "Organization",
            "name": "MarkNtel Advisors"
            }
         },
         "aggregateRating": 
         {
            "@type": "AggregateRating",
            "ratingValue": "<?php echo e(@$parent_id->rating_value); ?>",
            "reviewCount": "<?php echo e(@$parent_id->reviewcount); ?>"
         },
         "offers": 
         {
            "@type": "Offer",
            "url": "<?php echo e(url('/research-library')); ?>/<?php echo e($seo_slug_url); ?>",
            "priceCurrency": "USD",
            "price": "<?php echo e(@$newprice); ?>",
            "priceValidUntil": "2024/01/31",
            "itemCondition": "https://schema.org/NewCondition",
            "availability": "https://schema.org/InStock",
            "seller": {
            "@type": "Organization",
            "name": "MarkNtel Advisors"
         }
      }
      }
   </script>

   <?php } 
   
   } else if($seo_slug_url_type == "research-library" && $seo_slug_url == ""){       
      $seo_data =\DB::table('seo_content')->where('page_type','research_library')->orderBy('id','DESC')->first(); 
   ?>         
   
      <title><?php echo $seo_data->seo_title ;?></title>
      <meta name="description" content="<?php echo $seo_data->seo_description ;?>" />
      <meta name="keywords" content="<?php echo $seo_data->seo_key_words ;?>">
      <link rel="canonical" href="<?php echo e(url()->current()); ?>" />

      <meta property="og:type" content="news" />
      <meta property="og:title" content="<?php echo $seo_data->seo_title ;?>" />
      <meta property="og:image" content="https://www.marknteladvisors.com/theme/image/logo.png" />
      <meta property="og:description" content="<?php echo $seo_data->seo_description ;?>"/>
      <meta property="og:url" content="<?php echo e(url()->current()); ?>">

      <meta name="twitter:card" content="https://www.marknteladvisors.com/theme/image/logo.png" />
      <meta name="twitter:site" content="marknteladvisors" />
      <meta name="twitter:title" content="<?php echo $seo_data->seo_title ;?>" />
      <meta name="twitter:description" content="<?php echo $seo_data->seo_description ;?>" />
      <base href="<?php echo e(url()->current()); ?>" >

      <script type="application/ld+json">  
      {
      "@context": "https://schema.org",
      "@type": "BreadcrumbList",
         "itemListElement": [
                                          
            {
            "@type": "ListItem",
            "position": 1,
            "item": {
                  "@type": "webpage",
                  "@id": "<?php echo e(url('/')); ?>",
                  "name": "Home"
               }
            },
                     
            {
            "@type": "ListItem",
            "position": 2,
            "item": {
                  "@type": "webpage",
                  "@id": "<?php echo e(url('/research-library')); ?>",
                  "name": "Research Library"
               }
            }                        
         ]
      }

   </script>
   
   <?php } else if($seo_slug_url_type == "query" && $seo_slug_url == "request-sample"){ 

      $seo_page_url_request = request()->segment(3);
      $parent_id =\DB::table('reports')->where('page_url',$seo_page_url_request)->first();      
      $seo_data =\DB::table('seo_content')->where('parent_id',$parent_id->id)->where('page_type','report')->orderBy('id','DESC')->first(); 
   
   ?>         
   
      <title><?php echo $seo_data->seo_title ;?></title>
      <meta name="description" content="<?php echo $seo_data->seo_description ;?>" />
      <meta name="keywords" content="<?php echo $seo_data->seo_key_words ;?>">
      <link rel="canonical" href="<?php echo e(url()->current()); ?>" />

      <meta property="og:type" content="news" />
      <meta property="og:title" content="<?php echo $seo_data->seo_title ;?>" />
      <meta property="og:image" content="https://www.marknteladvisors.com/theme/image/logo.png" />
      <meta property="og:description" content="<?php echo $seo_data->seo_description ;?>"/>
      <meta property="og:url" content="<?php echo e(url()->current()); ?>">

      <meta name="twitter:card" content="https://www.marknteladvisors.com/theme/image/logo.png" />
      <meta name="twitter:site" content="marknteladvisors" />
      <meta name="twitter:title" content="<?php echo $seo_data->seo_title ;?>" />
      <meta name="twitter:description" content="<?php echo $seo_data->seo_description ;?>" />
      <base href="<?php echo e(url()->current()); ?>" >

      <script type="application/ld+json">  
      {
      "@context": "https://schema.org",
      "@type": "BreadcrumbList",
         "itemListElement": [
                                          
            {
            "@type": "ListItem",
            "position": 1,
            "item": {
                  "@type": "webpage",
                  "@id": "<?php echo e(url('/')); ?>",
                  "name": "Home"
               }
            },
                     
            {
            "@type": "ListItem",
            "position": 2,
            "item": {
                  "@type": "webpage",
                  "@id": "<?php echo e(url('/research-library')); ?>",
                  "name": "Research Library"
               }
            }                        
         ]
      }

   </script>
   
   <?php } else if($seo_slug_url_type == "blogs" && $seo_slug_url == ""){ 

      $seo_data =\DB::table('seo_content')->where('page_type','blog')->orderBy('id','DESC')->first(); 
      if(!is_null($seo_data)){

   ?>         

   <title><?php echo $seo_data->seo_title ;?></title>
   <meta name="description" content="<?php echo $seo_data->seo_description ;?>" />
   <meta name="keywords" content="<?php echo $seo_data->seo_key_words ;?>">
   <link rel="canonical" href="<?php echo e(url()->current()); ?>" />

   <meta property="og:type" content="news" />
   <meta property="og:title" content="<?php echo $seo_data->seo_title ;?>" />
   <meta property="og:image" content="https://www.marknteladvisors.com/theme/image/logo.png" />
   <meta property="og:description" content="<?php echo $seo_data->seo_description ;?>"/>
   <meta property="og:url" content="<?php echo e(url()->current()); ?>">

   <meta name="twitter:card" content="https://www.marknteladvisors.com/theme/image/logo.png" />
   <meta name="twitter:site" content="marknteladvisors" />
   <meta name="twitter:title" content="<?php echo $seo_data->seo_title ;?>" />
   <meta name="twitter:description" content="<?php echo $seo_data->seo_description ;?>" />
   <base href="<?php echo e(url()->current()); ?>" >

   
<script type="application/ld+json">  
{
  "@context": "https://schema.org",
  "@type": "BreadcrumbList",
    "itemListElement": [
                                    
                   {
                            "@type": "ListItem",
                            "position": 1,
                            "item": {
                                "@type": "webpage",
                                "@id": "<?php echo e(url('/')); ?>",
                                "name": "Home"
                            }
                          },
                                         {
                                "@type": "ListItem",
                                "position": 2,
                                "item": {
                                    "@type": "webpage",
                                    "@id": "<?php echo e(url('/blogs')); ?>",
                                    "name": "Blogs"
                                }
                              }
              ]
}

</script>

   <?php } }  else if($seo_slug_url_type == "blogs" && $seo_slug_url != ""){ 

   $seo_data =\DB::table('blog')->where('slug',$seo_slug_url)->orderBy('id','DESC')->first(); 
if(!is_null($seo_data)){
?>         

<title><?php echo $seo_data->seo_title ;?></title>
<meta name="description" content="<?php echo $seo_data->seo_description ;?>" />
<meta name="keywords" content="<?php echo $seo_data->seo_keyword ;?>">
<link rel="canonical" href="<?php echo e(url()->current()); ?>" />

<meta property="og:type" content="news" />
<meta property="og:title" content="<?php echo $seo_data->seo_title ;?>" />
<meta property="og:image" content="https://www.marknteladvisors.com/theme/image/logo.png" />
<meta property="og:description" content="<?php echo $seo_data->seo_description ;?>"/>
<meta property="og:url" content="<?php echo e(url()->current()); ?>">

<meta name="twitter:card" content="https://www.marknteladvisors.com/theme/image/logo.png" />
<meta name="twitter:site" content="marknteladvisors" />
<meta name="twitter:title" content="<?php echo $seo_data->seo_title ;?>" />
<meta name="twitter:description" content="<?php echo $seo_data->seo_description ;?>" />
<base href="<?php echo e(url()->current()); ?>" >


<script type="application/ld+json">  
{
"@context": "https://schema.org",
"@type": "BreadcrumbList",
"itemListElement": [
                              
             {
                      "@type": "ListItem",
                      "position": 1,
                      "item": {
                          "@type": "webpage",
                          "@id": "<?php echo e(url('/')); ?>",
                          "name": "Home"
                      }
                    },
                                   {
                          "@type": "ListItem",
                          "position": 2,
                          "item": {
                              "@type": "webpage",
                              "@id": "<?php echo e(url('/blogs')); ?>",
                              "name": "Blogs"
                          }
                        },
                        {
                     "@type": "ListItem",
                     "position": 3,
                     "item": {
                           "@type": "webpage",
                           "@id": "<?php echo e(url('/blogs/')); ?>/<?php echo e($seo_data->slug); ?>",
                           "name": "<?php echo $seo_data->seo_title ;?>"
                     }
               }
        ]
}

</script>

<?php }}  else if($seo_slug_url_type == "privacy-policy" && $seo_slug_url == ""){ 

$seo_data =\DB::table('seo_content')->where('page_type','privacy_policy')->orderBy('id','DESC')->first(); 

?>         

<title><?php echo $seo_data->seo_title ;?></title>
<meta name="description" content="<?php echo $seo_data->seo_description ;?>" />
<meta name="keywords" content="<?php echo $seo_data->seo_key_words ;?>">
<link rel="canonical" href="<?php echo e(url()->current()); ?>" />

<meta property="og:type" content="news" />
<meta property="og:title" content="<?php echo $seo_data->seo_title ;?>" />
<meta property="og:image" content="https://www.marknteladvisors.com/theme/image/logo.png" />
<meta property="og:description" content="<?php echo $seo_data->seo_description ;?>"/>
<meta property="og:url" content="<?php echo e(url()->current()); ?>">

<meta name="twitter:card" content="https://www.marknteladvisors.com/theme/image/logo.png" />
<meta name="twitter:site" content="marknteladvisors" />
<meta name="twitter:title" content="<?php echo $seo_data->seo_title ;?>" />
<meta name="twitter:description" content="<?php echo $seo_data->seo_description ;?>" />
<base href="<?php echo e(url()->current()); ?>" >


<script type="application/ld+json">  
{
"@context": "https://schema.org",
"@type": "BreadcrumbList",
"itemListElement": [
                           
          {
                   "@type": "ListItem",
                   "position": 1,
                   "item": {
                       "@type": "webpage",
                       "@id": "<?php echo e(url('/')); ?>",
                       "name": "Home"
                   }
                 },
                                {
                       "@type": "ListItem",
                       "position": 2,
                       "item": {
                           "@type": "webpage",
                           "@id": "<?php echo e(url('/privacy-policy')); ?>",
                           "name": "Privacy Policy"
                       }
                     }
     ]
}

</script>

<?php } else if($seo_slug_url_type == "terms-conditions" && $seo_slug_url == ""){ 

$seo_data =\DB::table('seo_content')->where('page_type','terms_condition')->orderBy('id','DESC')->first(); 

?>         

<title><?php echo $seo_data->seo_title ;?></title>
<meta name="description" content="<?php echo $seo_data->seo_description ;?>" />
<meta name="keywords" content="<?php echo $seo_data->seo_key_words ;?>">
<link rel="canonical" href="<?php echo e(url()->current()); ?>" />

<meta property="og:type" content="news" />
<meta property="og:title" content="<?php echo $seo_data->seo_title ;?>" />
<meta property="og:image" content="https://www.marknteladvisors.com/theme/image/logo.png" />
<meta property="og:description" content="<?php echo $seo_data->seo_description ;?>"/>
<meta property="og:url" content="<?php echo e(url()->current()); ?>">

<meta name="twitter:card" content="https://www.marknteladvisors.com/theme/image/logo.png" />
<meta name="twitter:site" content="marknteladvisors" />
<meta name="twitter:title" content="<?php echo $seo_data->seo_title ;?>" />
<meta name="twitter:description" content="<?php echo $seo_data->seo_description ;?>" />
<base href="<?php echo e(url()->current()); ?>" >


<script type="application/ld+json">  
{
"@context": "https://schema.org",
"@type": "BreadcrumbList",
"itemListElement": [
                           
          {
                   "@type": "ListItem",
                   "position": 1,
                   "item": {
                       "@type": "webpage",
                       "@id": "<?php echo e(url('/')); ?>",
                       "name": "Home"
                   }
                 },
                                {
                       "@type": "ListItem",
                       "position": 2,
                       "item": {
                           "@type": "webpage",
                           "@id": "<?php echo e(url('/terms-condition')); ?>",
                           "name": "Terms Condition"
                       }
                     }
     ]
}

</script>

<?php  } else if($seo_slug_url_type == "services" && $seo_slug_url == ""){ 

$seo_data =\DB::table('seo_content')->where('page_type','services')->orderBy('id','DESC')->first(); 

?>         

<title><?php echo $seo_data->seo_title ;?></title>
<meta name="description" content="<?php echo $seo_data->seo_description ;?>" />
<meta name="keywords" content="<?php echo $seo_data->seo_key_words ;?>">
<link rel="canonical" href="<?php echo e(url()->current()); ?>" />

<meta property="og:type" content="news" />
<meta property="og:title" content="<?php echo $seo_data->seo_title ;?>" />
<meta property="og:image" content="https://www.marknteladvisors.com/theme/image/logo.png" />
<meta property="og:description" content="<?php echo $seo_data->seo_description ;?>"/>
<meta property="og:url" content="<?php echo e(url()->current()); ?>">

<meta name="twitter:card" content="https://www.marknteladvisors.com/theme/image/logo.png" />
<meta name="twitter:site" content="marknteladvisors" />
<meta name="twitter:title" content="<?php echo $seo_data->seo_title ;?>" />
<meta name="twitter:description" content="<?php echo $seo_data->seo_description ;?>" />
<base href="<?php echo e(url()->current()); ?>" >


<script type="application/ld+json">  
{
"@context": "https://schema.org",
"@type": "BreadcrumbList",
"itemListElement": [
                           
          {
                   "@type": "ListItem",
                   "position": 1,
                   "item": {
                       "@type": "webpage",
                       "@id": "<?php echo e(url('/')); ?>",
                       "name": "Home"
                   }
                 },
                                {
                       "@type": "ListItem",
                       "position": 2,
                       "item": {
                           "@type": "webpage",
                           "@id": "<?php echo e(url('/services')); ?>",
                           "name": "Services"
                       }
                     }
     ]
}

</script>

<?php } ?>


   
   
   <!--~~~~~~~~~~~~~FontAwesome CDN Link~~~~~~~~~~~~-->
   <link rel="stylesheet" media="all" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.2.1/css/all.min.css"
      integrity="sha512-MV7K8+y+gLIBoVD59lQIYicR65iaqukzvf/nwasF0nqhPay5w/9lJmVM2hMDcnK1OnMGCdVK+iQrJ7lzPJQd1w=="
      crossorigin="anonymous" referrerpolicy="no-referrer" />

   <link rel="stylesheet" media="all" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css" />

   <link rel="stylesheet" media="all" href="<?php echo e(url('public/css/bootstrap.min.css')); ?>">
   <link rel="stylesheet" media="all" href="<?php echo e(url('public/css/style.css')); ?>">
   <link rel="stylesheet" media="all" href="<?php echo e(url('public/css/slick-theme.css')); ?>">
   <link rel="stylesheet" media="all" href="<?php echo e(url('public/css/slick.css')); ?>">
   <link rel="stylesheet" media="all" href="<?php echo e(url('public/css/customstyle.css')); ?>">
   <link rel="icon" href="<?php echo e(url('public/img/favicon_new.ico')); ?>"/>
   
   <style type="text/css">
      .goog-te-gadget img {
         display:none;
      }
      #google_translate_element .goog-te-gadget-simple .goog-te-menu-value span:first-child{
         display: none;
      }
      #google_translate_element .goog-te-gadget-simple .goog-te-menu-value:before{
         content: 'Select Language'
      }
      
    .cookie-banner {
        position: fixed;
        bottom: 0;
        left: 0;
        width: 100%;
        background-color: #f1f1f1;
        padding: 10px;
        text-align: center;
    }

   </style>
   <style>
      .goog-te-combo{
         background-color: #ccc5c5;
      }
      .goog-te-gadget-simple{
         background-color: #ccc5c5;
         border-left: 1px solid #ccc5c5;
         border-top: 1px solid #ccc5c5;
         border-bottom: 1px solid #ccc5c5;
         border-right: 1px solid #ccc5c5;
      }
   </style>


   <link rel="stylesheet" href="https://cdn.tutorialjinni.com/intl-tel-input/17.0.8/css/intlTelInput.css"/>
   
   <style>
      .iti--separate-dial-code{
         width:100%!important;
      }
   </style>

  

</head>

<body >
   
   <!-- top bar section -->
   <section class="navbar-area ">
      <div class="login-sign-in">
         <div class="container">
            <div class="row">
               <div class="col-md-12">
                  <ul class="top-right-login text-end mb-0">
                     <li class="list-unstyled d-inline-block ps-2 fs-13 black"data-bs-toggle="modal" data-bs-target="#exampleModals" style="cursor:pointer">
                           Sign In
                        </a>
                     </li>
                     <li class="list-unstyled d-inline-block ps-2 fs-13 black" data-bs-toggle="modal" data-bs-target="#exampleModalsRegister" style="cursor:pointer">
                           Register
                        </a>
                     </li>
                     
                     <li class="list-unstyled d-inline-block ps-2 fs-13 black">
                        <div id="google_translate_element" style="color:#fff"></div>
                     </li>
                  </ul>
               </div>
            </div>
         </div>
      </div>


      <!-- Register Model -->
    <!-- Modal -->
    <div class="modal fade" id="exampleModalsRegister" tabindex="-1" aria-labelledby="exampleModalsRegisterLabel"
        aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalsRegisterLabel">User Registeration</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <div class="row">
                        <div class="alert-success col-md-12 mb-2" id="reg_msg" style="display:none;padding:10px;border-radius: 5px;">      
                        </div>
                        
                        <div class="col-md-6 mb-3">
                            <p class="mb-0">First Name:</p>
                            <input type="text" name="first_name" id="first_name" class="form-control" required>
                        </div>
                        <div class="col-md-6 mb-3">
                            <p class="mb-0">Last name:</p>
                            <input type="text" name="last_name" id="last_name" class="form-control" required>
                        </div>
                        <div class="col-md-6 mb-3">
                            <p class="mb-0">Email:</p>
                            <input type="email" name="email" id="email" class="form-control" required>
                        </div>
                        <div class="col-md-6 mb-3">
                            <p class="mb-0">Phone:</p>
                            <input type="text" name="phone_number" id="phone3" class="form-control" required>
                            
                        </div>
                        <div class="col-md-6 mb-3">
                            <p class="mb-0"> Password:</p>
                            <input type="password" name="paasword" id="paasword" class="form-control" required>
                        </div>
                        <div class="col-md-6 mb-3">
                            <p class="mb-0">Retype Password:</p>
                            <input type="password" class="form-control" required>
                        </div>
                        <!-- <div class="col-md-12 mb-3">
                           <p class="mb-2 fs-14">Captcha:</p>
                           <div class="g-recaptcha" data-sitekey="6Ldncs8oAAAAAJZ7C_pvRTzTqa1RwZKNW0jfJ-Y2" data-callback="verifyRecaptchaCallback" data-expired-callback="expiredRecaptchaCallback"></div>
                           <input class="form-control d-none" data-recaptcha="true"  data-error="Please complete the Captcha">
                           <div class="help-block with-errors"></div>
                        </div> -->
                           <div class="col-12 mb-4">
                              <!--<div class="captcha">
                                 <button type="button" class="btn btn-info" class="reload" id="reload_register">
                                       &#x21bb;
                                 </button>&nbsp;&nbsp;
                                 <span><?php echo captcha_img(); ?></span>														  
                              </div>-->
                              <div class="g-recaptcha" data-sitekey="<?php echo e(config('services.recaptcha.key')); ?>"></div>
                           </div>
                           <div class="col-12">
                              <!--<input type="text" name="captcha" id="captcha_2" class="form-control" placeholder="Enter Captcha" required />   -->
                              <?php if($errors->has('g-recaptcha-response')): ?>
                                    <span class="help-block">
                                        <strong><?php echo e($errors->first('g-recaptcha-response')); ?></strong>
                                    </span>
                                <?php endif; ?> 
                           </div>
                        </div>
                </div>
                <div class="modal-footer">
                    <div class="col-md-12">
                        <button type="button" name="reg_btn" class="btn btn-primary reg_btn">Submit</button>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- Register Model End -->
    <!-- Login Model -->
    <div class="modal fade" id="exampleModals" tabindex="-1" aria-labelledby="exampleModalsLabel" aria-hidden="true">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>" />
        <div class="modal-dialog">
            <div class="modal-content">
               <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalsLabel">Login</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                <form action="<?php echo e(url('sign')); ?>" method="POST" id="handleAjax">
                     <?php echo csrf_field(); ?>

                     <div id="errors-list"></div>

                     <div class="col-md-12 mb-3">
                        <p class="mb-0">Email</p>
                        <input type="text" name="email" id="email_address" class="form-control" required autofocus>
                     </div>
                     
                     <div class="col-md-12 mb-3">
                        <p class="mb-0">Password</p>
                        <input type="password" name="password" id="password" class="form-control" required>
                     </div>
                     <!-- <div class="col-md-12 mb-3">
                        <p class="mb-2 fs-14">Captcha:</p>
                        <div class="g-recaptcha" data-sitekey="6Ldncs8oAAAAAJZ7C_pvRTzTqa1RwZKNW0jfJ-Y2" data-callback="verifyRecaptchaCallback" data-expired-callback="expiredRecaptchaCallback"></div>
                        <input class="form-control d-none" data-recaptcha="true"  data-error="Please complete the Captcha">
                        <div class="help-block with-errors"></div>
                     </div> -->
                     <div class="col-12 mb-4">
                        <!--<div class="captcha">
                           <button type="button" class="btn btn-info" class="reload" id="reload_login">
                                 &#x21bb;
                           </button>&nbsp;&nbsp;
                           <span><?php echo captcha_img(); ?></span>														  
                        </div>-->
                        <div class="g-recaptcha" data-sitekey="<?php echo e(config('services.recaptcha.key')); ?>"></div>
                     </div>
                     <div class="col-12 mb-4">
                        <!--<input type="text" name="captcha" id="captcha" class="form-control" placeholder="Enter Captcha" required />   -->
                        <?php if($errors->has('g-recaptcha-response')): ?>
                            <span class="help-block">
                                <strong><?php echo e($errors->first('g-recaptcha-response')); ?></strong>
                            </span>
                        <?php endif; ?> 
                     </div>                       

                     <div class="col-md-12">
                        <button type="submit" name="login_btn" class="btn btn-primary login_btn">Login</button>
                     </div>

                  </form>
                </div>
               
            </div>
        </div>
    </div>

    <!-- Login Model End -->


      <div class="logo-search-icons">
         <div class="container">
            <div class="row align-items-center ">
               <div class="col-md-3  hide-on-mobile">
                  <a class="navbar-brand d-inline-block hide-on-mobile" href="<?php echo e(url('/')); ?>" rel="noopener noreferrer"  aria-label="logo">
                      <img data-src="<?php echo e(url('public/img/logo.webp')); ?>" src="<?php echo e(url('public/img/1.png')); ?>" class="img-fluid lazy" alt="Markntel Advisors- Market Research Company" width="160" height="50" /></a>
               </div>

               <div class="col-md-6">
                  <form action="<?php echo e(url('search/search-result')); ?>" method="get">
                     <div class="searc_bar">
                        <div class="search_bar_box">
                           <input type="text" placeholder="Search Report..." class="form-control" id="search_123" name="search_form" autocomplete="off">
                        </div>
                        <div class="search_bar_btn">
                           <button type="submit" class="search_now" aria-label="Sort"><i class="fa fa-search"></i></button>
                        </div>                     
                     </div>
                  </form>
                  <div id="search_result" class="search_result_data" style="display:none"></div>
               </div>

               <div class="col-md-3">
                     
                  <ul class="top-right-login text-end mb-0 ps-0">
                     <li class="list-unstyled d-inline-block ps-3  blue">
                        <a class="blue" href="mailto:sales@marknteladvisors.com" rel="noopener noreferrer"  aria-label="email"><i
                              class="fs-20 fa fa-envelope"></i>
                        </a>
                     </li>
                     <li class="list-unstyled d-inline-block ps-3  blue">
                        <a class="blue" href="tel:+16288958081" rel="noopener noreferrer"  aria-label="phone"><i
                              class="fs-20 fa fa-phone"></i>
                        </a>
                     </li>
                     <li class="list-unstyled d-inline-block ps-3  blue cart_counter"><a class="blue" href="<?php echo e('/cart'); ?>" rel="noopener noreferrer"  aria-label="cart"><i
                              class="fs-20 fa fa-shopping-cart"></i>
                        </a>

                        <?php if(count((array) session('cart')) > 0 ): ?>
               
                        <div class="cart_count" data-toggle="dropdown" id="navbarDropdown" role="button"
                        data-bs-toggle="dropdown" ><?php echo e(count((array) session('cart'))); ?></div>
                        <div class="dropdown-menu" style="width:220px;">               
                           <?php if(session('cart')): ?>
                              <?php $__currentLoopData = session('cart'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $id => $details): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                 <div class="row cart-detail" style="width:210px; padding:0 5px;">
                                    <div class="col-lg-2 col-sm-2 col-2 cart-detail-img">
                                          <img src ="<?php echo e(url('public/img/1.png')); ?>" data-src="<?php echo e(url('public/img/market_research_consulting.webp')); ?>" width="30" height="30" class="lazy" />
                                    </div>
                                    <div class="col-lg-10 col-sm-10 col-10 cart-detail-product">
                                          <p style="font-size:11px;"><?php echo e($details['name']); ?> <br>
                                          <span class="price text-primary fw-600" style="font-size:11px;"> USD <?php echo e($details['price']); ?></span> <span class="count fw-600" style="font-size:11px;"> Qty: <?php echo e($details['quantity']); ?></span>
                                       </p>
                                    </div>
                                 </div>
                              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                           <?php endif; ?>

                           <div class="row total-header-section" style="min-width:210px; padding:0 5px;">
                              <div class="col-lg-6 col-sm-6 col-6">
                                 <!-- <i class="fa fa-shopping-cart" aria-hidden="true"></i> <span class="badge badge-pill badge-danger text-danger"><?php echo e(count((array) session('cart'))); ?></span> -->
                              </div>
                              <?php $total = 0 ?>
                              <?php $__currentLoopData = (array) session('cart'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $id => $details): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                 <?php if(strpos($details['price'], ',') !== false): ?>
                                    <?php 
                                       $price = str_replace(',','',$details['price']);
                                    ?>
                                    
                                 <?php else: ?>
                                    <?php $price = $details['price']; ?>
                                 <?php endif; ?>
                                 
                                 <?php $total += $price * $details['quantity'] ?>
                                 
                              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                              <div class="col-lg-12 col-sm-12 col-12 total-section text-right">
                                 <p class="fw-600">Total: <span class="text-primary"><?php echo "USD ".number_format($total) ?></span></p>
                              </div>
                           </div>

                           <div class="row">
                              <div class="col-lg-12 col-sm-12 col-12 text-center checkout">
                                 <a href="<?php echo e(url('cart')); ?>" class="btn btn-warning btn-sm" rel="noopener noreferrer"  aria-label="View"View>View</a>
                              </div>
                           </div>
                        </div>
                     <?php endif; ?>
                     </li>
                     
                     <!--Cart Script !-->
                     
                     
                     
                     <!-- END Cart Script !-->
                  </ul>
               </div>
            </div>
         </div>
      </div>
      <nav class="navbar navbar-expand-lg navbar-light white-bg pt-1 pb-1 fixed-nav">
         <div class="container">
            <a class="navbar-brand hide-on-desktop" href="<?php echo e(url('/')); ?>" rel="noopener noreferrer"  aria-label="logo">
                <img  src ="<?php echo e(url('public/img/1.png')); ?>" data-src="<?php echo e(url('public/img/logo.webp')); ?>" class="img-fluid lazy" alt="Markntel Advisors- Market Research Company" width="160" height="50" /></a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNavDropdown"
               aria-controls="navbarNavDropdown" aria-expanded="false" aria-label="Toggle navigation">
               <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse justify-content-end" id="navbarNavDropdown">
               <ul class="navbar-nav">
                  <li class="nav-item dropdown">
                     <a class="nav-link dropdown-toggle <?php echo e(request()->is('research-report') ? 'active' : ''); ?> " rel="noopener noreferrer" href="<?php echo e(url('research-library')); ?>" id="navbarDropdown" role="button"
                         aria-expanded="false"  aria-label="Research Report">
                        Research Reports
                     </a>
                     <?php $category =\DB::table('category')->orderBy('cat_name','ASC')->get(); ?>
                     <ul class="dropdown-content" aria-labelledby="navbarDropdown">
                        <?php if(count($category) >0): ?>
                           <?php $__currentLoopData = $category; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                              <li><a class="dropdown-item" href="<?php echo e(url('research-library')); ?>/<?php echo e($data->category_url); ?>" rel="noopener noreferrer"  aria-label="Cart Name"><?php echo e($data->cat_name); ?></a></li>
                           <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php endif; ?>
                     </ul>
                  </li>
                  <li class="nav-item">
                     <a class="nav-link <?php echo e(request()->is('upcoming-report') ? 'active' : ''); ?>" aria-current="page" href="<?php echo e(url('upcoming-reports')); ?>" rel="noopener noreferrer"  aria-label="Upcoming">Upcoming Reports</a>
                  </li>
                  <li class="nav-item">
                     <a class="nav-link <?php echo e(request()->is('export-import-data') ? 'active' : ''); ?>" href="<?php echo e(url('export-import-data')); ?>" rel="noopener noreferrer"  aria-label="export"> Export-import Data </a>
                  </li>

                  <li class="nav-item">
                     <a class="nav-link <?php echo e(request()->is('press-release') ? 'active' : ''); ?>" href="<?php echo e(url('press-release')); ?>" rel="noopener noreferrer"  aria-label="press release">Press Release</a>
                  </li>
                  <li class="nav-item">
                     <a class="nav-link <?php echo e(request()->is('infographics') ? 'active' : ''); ?>" href="<?php echo e(url('infographics')); ?>" rel="noopener noreferrer"  aria-label="Infographics">Infographics</a>
                  </li>
                  <li class="nav-item">
                     <a class="nav-link <?php echo e(request()->is('contact-us') ? 'active' : ''); ?>" href="<?php echo e(url('contact-us')); ?>">Contact Us</a>
                  </li>
               </ul>


            </div>
         </div>
      </nav>
   </section>


<?php echo $__env->yieldContent('content'); ?>


<?php echo $__env->make('layout/footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/marknteladvisors/public_html/resources/views/layout/header.blade.php ENDPATH**/ ?>
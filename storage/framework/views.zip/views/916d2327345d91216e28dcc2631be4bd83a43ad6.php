
<?php $__env->startSection('title','Service List'); ?>
<?php $__env->startSection('content'); ?>

<section class="main-content mb-5 mt-5">
   <div class="container">
      <div class="row">
         <div class="col-md-12 mb-25">
            <h4 class="fw-800 mb-4">Services</h4>
         </div>
      </div>
      <div class="row">
      <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
         <div class="col-md-4 col-sm-4">
            <div class="box-shadow">
               <div class="pb-2">
               <?php if($data->services_image != ""): ?>
                                <img src="<?php echo e(asset('public/uploads/')); ?>/<?php echo e($data->services_image); ?>" alt="team images" width="100%" style="height:270px">
                            

                            <?php else: ?>
                                <img src="<?php echo e(asset('public/uploads/1693917308.PNG')); ?>" alt="team images" width="100%" style="height:270px">
                            <?php endif; ?>
               </div>
               <div class="info-content">
                  <h6><b><?php echo e($data->service_name); ?></b></h6>
                  <p class="fs-15">
                    <?php echo e($data->services_desc); ?>

                  </p>
                  <a href="<?php echo e(url('contact_us')); ?>">
                  <button type="submit" id="button2" class="btn btn-primary" >Enquiry Now</button>
                  </a>
                  <!-- <a href="<?php echo e(url('contact_us')); ?>" class="open-button">Enquire Now</a> -->
               </div>
            </div>
         </div>
         <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </div>
      
   </div>
</section>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout/header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\markntel_advisor\resources\views/service_list.blade.php ENDPATH**/ ?>
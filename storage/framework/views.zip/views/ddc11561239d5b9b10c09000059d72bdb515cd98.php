
<?php $__env->startSection('title','Upcoming Report'); ?>

<?php $__env->startSection('content'); ?>

<section class="mini-banner">
   <div class="container">
      <div class="row">
         <div class="col-md-12">
            <h1 class="mb-0 mini-banner-title">Upcoming Reports</h1>
         </div>
      </div>
   </div>
</section>

<section class="main-content gray-bg-light pt-5 pb-5">
      <div class="container">
         <div class="row">
            <div class="col-md-12 sm-100">
            <?php if(count($datas) > 0): ?>
               <?php $__currentLoopData = $datas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
               <div class="box-shadow white-bg">      
                  <div class="row align-items-center mb-3 category-box">
                     <div class="col-md-2">
                        <img src="<?php echo e(url('public/img/market_research_consulting.webp')); ?>" class="img-fluid" alt="Market Research Report">
                     </div>
                     <div class="col-md-10">
                        <a href="<?php echo e(url('research-library')); ?>/<?php echo e(($data->page_url)); ?>" class="fw-600 d-block blue mb-2" target="_blank"><?php echo e($data->title); ?></a>
                        <p class="fs-14 mb-2"><?php echo ($data->heading2 !="") ? preg_replace('/\\s\\S*$/', '', substr($data->heading2, 0, 250))  : ''; ?> <span
                              class="read-more">
                              <a href="<?php echo e(url('research-library')); ?>/<?php echo e(($data->page_url)); ?>" class="read-more-small-btn" target="_blank">Read
                                 more</a>
                           </span></p>
                     </div>
                  </div>

                  <div class="row">
                     <div class="col-md-12">
                        <ul class="catefory-list ps-0 mb-0">
                           <li>
                              <label><i class="fa fa-industry" aria-hidden="true"></i></label>
                              <span>
                                 <?php echo e($data->cat_name); ?></span>
                           </li>
                           <li>
                              <label> <i class="fa fa-calendar" aria-hidden="true"></i></label>
                              <span><?php echo e(Carbon\Carbon::parse($data->report_post_date)->format('M Y')); ?> </span>
                           </li>
                           <li>
                              <label>Pages</label>
                              <span><?php echo e($data->no_of_page); ?></span>
                           </li>
                           <li>
                              <label>USD</label>
                              <span><?php echo e($data->single_licence_price); ?></span>
                           </li>
                           <!-- <li class="last">
                              <div class="add-carts">                                 
                                 <a class="cart-btn" href="#" onclick="priceModal('1539')"><i class="fa fa-cart-plus"
                                       aria-hidden="true"></i> Add Cart</a>
                              </div>
                           </li> -->
                        </ul>
                     </div>
                  </div>
               </div>
             <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
         <?php endif; ?>
         <div class="row">
         <div class="col-md-12">
            <nav aria-label="Page navigation example">
               <?php echo e($datas->links('custom_pagination')); ?>

            </nav>
         </div>
      </div>

      </div>
   </section>



<?php $__env->stopSection(); ?>


<?php echo $__env->make('layout/header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\markintal_site\resources\views/upcoming_report.blade.php ENDPATH**/ ?>
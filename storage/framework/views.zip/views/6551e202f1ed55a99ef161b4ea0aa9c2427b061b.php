
<?php $__env->startSection('title', 'Market Advisor'); ?>
<?php $__env->startSection('content'); ?>
    <section class="pay-option mb-5">
        <div class="container">
            <div class="row">
                <div class="col-md-12 sm-100 mb-25">
                    <div class="wrap-cart">
                        <div class="report-heading">
                            <p class="mb-0 white">User Login / Registeration</p>
                        </div>
                        <div class="row cart-row" style="height:200px;">
                            <div class="col-md-12">
                                Please check your email & verify email. After email verify you can login in the system.
                            </div>
                        </div>
                    </div>
                </div>
               
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout/header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /mnt/home2/vvsajqnq/public_html/resources/views/thanks.blade.php ENDPATH**/ ?>
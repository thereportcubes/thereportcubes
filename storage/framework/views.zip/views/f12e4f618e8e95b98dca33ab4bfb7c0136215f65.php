
<?php $__env->startSection('title','Upcoming Report'); ?>

<?php $__env->startSection('content'); ?>

<section class="mini-banner">
   <div class="container">
      <div class="row">
         <div class="col-md-12">
            <h1 class="mb-0 mini-banner-title">Infographics</h1>
         </div>
      </div>
   </div>
</section>

<section class="main-content mb-5 mt-5">
   <div class="container">
      
      <h6 class="fw-600 blue-title-bg mb-2">Infographics</h6><br>
      <div class="row infographics">
      
      <?php if(count($infographic) > 0): ?>
         <?php $__currentLoopData = $infographic; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

         <div class="col-md-3">
            <div class="info-box box-shadow">
               <a href="<?php echo e(url('infographics')); ?>/<?php echo e($p->report_link); ?>" class="black" target="_blank">
                  <div class="info-img pb-2">
                     <!-- <img src="https://www.marknteladvisors.com/<?php echo e($p->image); ?>" class="img-fluid" alt=""> -->
                     <img src="<?php echo e(url('/public')); ?>/<?php echo e($p->image); ?>" class="img-fluid" alt="<?php echo e($p->img_alt_tag); ?>">
                  </div>
                  <div class="info-content" style="min-height:100px;">
                     <p class="fs-15 mb-2"><?php echo e($p->title); ?>

                     </p>

                     <p class="mb-0">
                        <label> <i class="fa fa-calendar orrange pe-2" aria-hidden="true"></i></label>
                        <span> <?php echo e(Carbon\Carbon::parse($p->created_at)->format('M Y')); ?> </span>
                     </p>

                  </div>
               </a>
            </div>
         </div>
         
         <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      <?php endif; ?>

      </div>

      <div class="row">
         <div class="col-md-12">
            <nav aria-label="Page navigation example">
               <?php echo e($infographic->links('custom_pagination')); ?>

            </nav>
         </div>
      </div>
   </div>
</section>

<?php $__env->stopSection(); ?>


<?php echo $__env->make('layout/header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/marknteladvisors/public_html/resources/views/infographics.blade.php ENDPATH**/ ?>
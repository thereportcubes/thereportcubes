
<?php $__env->startSection('title','Career'); ?>
<?php $__env->startSection('content'); ?>
<section class="main-content">
   <div class="container">
      <div class="row box-shadow mt-5 mb-5">
         <div class="col-md-6">
            <h4 class="fw-800 mb-4">Current Openings</h4>
            <div class="discrip-s discrip-snew">
               <div class="pressview">
                  <h4 class="blk-title">Content Writer</h4>
                  <div class="openig-report">
                     <label
                        ><i class="fa fa-diamond" style="color: red;"></i>
                     <b>Reports to:</b></label
                        >
                     <span>Team Lead- Content Writing </span><br>
                     <label
                        ><i class="fa fa-diamond" style="color: red;"></i>
                     <b>Experience:</b></label
                        >
                     <span>0-2 Years</span><br>
                     <label
                        ><i class="fa fa-diamond" style="color: red;"></i>
                     <b>Location:</b></label
                        >
                     <span>Noida, Sector 63</span>
                  </div>
                  <div class="roles mt-2">
                     <p><strong>Job description:</strong></p>
                     <p>
                        We are in the quest for an exceptional candidate with
                        experience and passion to fill a Content Writer position.
                        The role will primarily include researching and writing
                        creative content for the clients.
                     </p>
                     <p>
                        <strong
                           >Job Responsibilities &amp; Accountabilities:</strong
                           >
                     </p>
                     <p>
                        Research industry-related topics (combining online sources,
                        interviews, and studies) Proofread and edit content before
                        publication Curating Content for Social Media Platforms
                        Collating the sources where the content is distributed
                        Ensure the timely and successful delivery of solutions
                        according to the client's needs and objectives Willing to
                        work collaboratively as a part of the content team
                     </p>
                     <p>
                        <strong>Required Skills &amp; Personal Attributes</strong>:
                     </p>
                     <p>
                        Bachelor's Degree in Mass Communication or English
                        preferable 0-2 years of relevant work experience Strong
                        communication and interpersonal skills, displaying the
                        ability to connect and build relationships with clients and
                        peer
                     </p>
                  </div>
               </div>
               <div class="pressview">
                  <h4 class="blk-title">
                     Business Development Executive / Senior Business Development
                     Executive
                  </h4>
                  <div class="openig-report">
                     <label
                        ><i class="fa fa-diamond" style="color: red;"></i>
                     <b>Reports to:</b></label
                        >
                     <span>Sales head</span><br>
                     <label
                        ><i class="fa fa-diamond" style="color: red;"></i>
                     <b>Experience:</b></label
                        >
                     <span>1-3 Years</span><br>
                     <label
                        ><i class="fa fa-diamond" style="color: red;"></i>
                     <b>Location:</b></label
                        >
                     <span>Noida, Sector 63</span>
                  </div>
                  <div class="roles mt-2">
                     <p>
                        <strong>Skill Required:</strong> Inbound, Outbound, Lead
                        Generation, Account Mapping, Cold Call, Sales Process,
                        Negotiation
                     </p>
                     <p><strong>Job Description </strong></p>
                     <ul>
                        <li>
                           Well aware of the sale cycle from lead creation to deal
                           closure
                        </li>
                        <li>
                           Addressing prospect/client’s queries via cold call, email,
                           and web meetings
                        </li>
                        <li>
                           Responsible for client creation through lead generation,
                           account mapping, outbound and inbound activities
                        </li>
                        <li>
                           Sales of the syndicated and customized research reports
                           and consulting projects
                        </li>
                        <li>
                           Understand the customer’s requirement, negotiation of the
                           deals and working with the industry analysts to deliver
                           the required data to the clients
                        </li>
                        <li>
                           Should have very good communication skills, verbal as well
                           as written and coupled with excellent presentation skills
                        </li>
                        <li>
                           Should have Experience in working across different
                           Geographies – North America, Europe MEA and APAC
                        </li>
                     </ul>
                     <p><strong>Desired Candidate Profile</strong>:</p>
                     <ul>
                        <li>MBA or PGDM (Preferably)</li>
                        <li>Should have research project sales experience</li>
                     </ul>
                  </div>
               </div>
            </div>
         </div>
         <div class="col-md-6 shadow mb-2 px-4 py-4 h-100">
         <?php if(session()->has('success')): ?>
            <div class="alert-success" style="padding:18px;border-radius: 5px;">
               <strong>Success!</strong> <?php echo e(session()->get('success')); ?>

            </div>
            <br>
            <?php endif; ?>
            <?php if(session()->has('error')): ?>
            <div class="alert-danger" style="padding:18px;border-radius: 5px;">
               <strong>Warning!</strong> <?php echo e(session()->get('error')); ?>

            </div>
            <br>
            <?php endif; ?>
         <form action="<?php echo e(route('save_career2')); ?>" method="post">
         <?php echo csrf_field(); ?>
            <h4 class="fw-800 mb-4">Application Form</h4>  
               <div class="col-sm-12 mb-3">
                  <label for="name" class="mb-2">Name:</label>
                  <input type="text" name="name" class="form-control" placeholder="Enter Name" required/>
               </div>
               <div class="col-sm-12 mb-3">
                  <label for="email" class="mb-2">Email address:</label>
                  <input type="text" name="email" class="form-control" placeholder="" />
               </div>
               <div class="col-sm-12 mb-3">
                  <label for="phone" class="mb-2">Phone:</label><br>
                  <input
                     name="phone"
                     type="text"
                     name="phone"
                     id="phone"
                     class="form-control"
                     />
               </div>
               <div class="col-sm-12 mb-3">
                  <label for="position" class="mb-2"
                     >Position Applying For:</label
                     >
                  <select
                     class="form-select form-control"
                     name="position_apply_for"
                     required=""
                     style="width: 100%"
                     >
                     <option>Position Applying For</option>
                     <option>Content Writer</option>
                     <option>
                        Business Development Executive / Senior Business Development
                        Executive
                     </option>
                     <option>Research Analyst/ Sr. Research Analyst</option>
                  </select>
               </div>
               <div class="col-sm-12 mb-3">
                  <label for="experience" class="mb-2">Experience:</label>
                  <input type="text" name="experiance" class="form-control" placeholder="" />
               </div>
               <div class="col-sm-12 mb-3">
                  <label for="location" class="mb-2">Current Location:</label>
                  <input type="text" name="location" class="form-control" placeholder="" />
               </div>
               <div class="col-sm-12 mb-3">
                  <label for="ctc" class="mb-2">CTC:</label>
                  <input type="text" name="ctc" class="form-control" placeholder="" />
               </div>
               <div class="col-sm-12 mb-3">
                  <label for="notice" class="mb-2">Notice Period:</label>
                  <input type="text" name="notice_period" class="form-control" placeholder="" />
               </div>
               <div class="col-sm-12 mb-3">
                  <label for="message" class="mb-2">Message:</label>
                  <textarea
                     name="message"
                     id=""
                     cols="30"
                     rows="4"
                     class="form-control"
                     placeholder=""
                     ></textarea>
               </div>
               <button type="submit" id="button2" class="btn btn-primary" >Apply</button>
               </div>
              
                  </div>
            </form>     
      </div>
   </div>
</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout/header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\markntel_advisor\resources\views/career.blade.php ENDPATH**/ ?>
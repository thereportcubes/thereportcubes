
<?php $__env->startSection('title','Add Press Release'); ?>
<?php $__env->startSection('content'); ?>
<!-- begin app-main -->
<div class="app-main" id="main">
   <!-- begin container-fluid -->
   <div class="container-fluid">
      <!-- begin row -->
      <div class="row">
         <div class="col-md-12 m-b-30">
            <!-- begin page title -->
            <div class="d-block d-sm-flex flex-nowrap align-items-center">
               <!-- <div class="page-title mb-2 mb-sm-0">
                  <h1>MemberShip</h1>
                  </div> -->
               <div class="ml-auto d-flex align-items-center">
                  <nav>
                     <ol class="breadcrumb p-0 m-b-0">
                        <li class="breadcrumb-item">
                           <a href="<?php echo e(url('admin/dashboard')); ?>"><i class="ti ti-home"></i></a>
                        </li>
                        <li class="breadcrumb-item">
                           Press Release
                        </li>
                        <li class="breadcrumb-item active text-primary" aria-current="page"> Add New Press Release</li>
                     </ol>
                  </nav>
               </div>
            </div>
            <!-- end page title -->
         </div>
      </div>
      <!-- end row -->
      <!-- begin row -->
      <div class="row">
         <div class="col-xl-12">
            <div class="card card-statistics">
               <div class="card-header">
                  <div class="card-heading">
                     <div class="row">
                        <div class="col-md-10">
                           <h4 class="card-title">Add New Press Release</h4>
                        </div>
                        <div class="col-md-2">&nbsp;</div>
                     </div>
                  </div>
               </div>
               <div class="card-body">
                  <?php if(session()->has('success')): ?>
                  <div class="alert-success" style="padding:18px;border-radius: 5px;">
                     <strong>Success!</strong> <?php echo e(session()->get('success')); ?>

                  </div>
                  <br>
                  <?php endif; ?>
                  <?php if(session()->has('error')): ?>
                  <div class="alert-danger" style="padding:18px;border-radius: 5px;">
                     <strong>Warning!</strong> <?php echo e(session()->get('error')); ?>

                  </div>
                  <br>
                  <?php endif; ?>
                  <form action="<?php echo e(route('admin/save_press_release')); ?>" method="post" enctype="multipart/form-data">
                     <?php echo csrf_field(); ?>
                     <div class="form-row">
                        <div class="form-group col-md-12">
                           <label for="title">Heading *</label>
                           <input type="text" name="heading" value="" placeholder="Title" class="form-control" required="required"  id="title">
                        </div>
                        <div class="form-group col-md-6">
                           <label for="title">Post Date *</label>
                           <input type="date" name="post_date" value="" class="form-control" required="required"  id="post_date">
                        </div>
                        <div class="form-group col-md-6">
                           <label for="page">Image</label>
                           <img class = "custom_inner" src = "">
                           <input type="file" name="image" class="form-control">
                           <input type="hidden" name="hidden_report_image" id = "hidden_report_imag" value = "">
                        </div>
                        <div class="form-group col-md-6">
                           <label for="description">Description</label>
                           <textarea class="form-control" class="form-control" name="description">
                           </textarea>
                        </div>
                        <div class="form-group col-md-6">
                           <label for="description">Description2</label>
                           <textarea class="form-control" class="form-control" name="description2">
                           </textarea>
                        </div>
                        <div class="form-group col-md-6">
                           <label for="title">Press Release Url *</label>
                           <input type="text" name="press_release_url" value="" placeholder="press release url" class="form-control" id="press_release_url">
                        </div>
                        <div class="form-group col-md-6">
                           <label for="title"> Report Url *</label>
                           <input type="text" name="report_url" value="" placeholder="report-url" class="form-control" required="required"  id="title">
                        </div>
                        <div class="form-group col-md-6">
                           <label for="page">Seo Title</label>
                           <input type="text" name="seo_title"  placeholder=" seo title" class="form-control" id="seo_title" value = "">
                           <input type="hidden" name="page_type" class="form-control" id="page_type" value = "press_release">
                        </div>
                        <div class="form-group col-md-6">
                           <label for="page">Seo Description</label>
                           <textarea class="form-control" name="seo_description" placeholder=" seo descriptions" rows = "4" cols="50"></textarea>
                        </div>
                        <div class="form-group col-md-6">
                           <label for="page">Seo Key Words</label>
                           <textarea class="form-control" name="seo_keyword" placeholder=" seo keywords" rows = "4" cols="50"></textarea>
                        </div>
                        <div class="form-group col-md-12 text-center">
                           <label></label>
                           <button type="submit" name = "update_press_release" class="btn btn-warning">Submit <i class="glyphicon glyphicon-send"></i></button>
                        </div>
                        <div class="form-group col-md-6 text-center">
                        </div>
                     </div>
                  </form>
               </div>
            </div>
         </div>
      </div>
      <!-- end row -->
   </div>
   <!-- end container-fluid -->
</div>
<!-- end app-main -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin/header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\markntel_advisor\resources\views/admin/add_press.blade.php ENDPATH**/ ?>

<?php $__env->startSection('title','Upcoming Report'); ?>
<?php $__env->startSection('content'); ?>
<!-- mini banner section -->
<section class="mini-banner">
   <div class="container">
      <div class="row">
         <div class="col-md-12">
            <h1 class="mb-0 mini-banner-title">Press Release</h1>
         </div>
      </div>
   </div>
</section>
<!-- mini banner end -->
<section class="main-content mb-5 mt-5">
   <div class="container">
      <div class="row">
         <div class="col-md-9 sm-100">
            <div class="box-shadow">
               <h6 class="fw-600 blue-title-bg">Press Release</h6>
               <div class="box-content p-1">
                  <div class="press-releas">
                     <a href="" class="fw-600 d-block blue">Global Drone Inspection and Monitoring Market Research
                     Report: Forecast (2023-2028)</a>
                     <p class="fs-14 mb-2">The use of unmanned aerial vehicles, also called drones, equipped with
                        sensors, cameras, and other advanced technologies to inspect &amp; monitor numerous assets,
                        areas, and structures is referred to as drone Inspection and Monitoring... <span
                           class="read-more">
                        <a href="" class="read-more-small-btn">Read
                        more</a>
                        </span>
                     </p>
                  </div>
                  <div class="press-releas">
                     <a href="" class="fw-600 d-block blue">Global Drone Inspection and Monitoring Market Research
                     Report: Forecast (2023-2028)</a>
                     <p class="fs-14 mb-2">The use of unmanned aerial vehicles, also called drones, equipped with
                        sensors, cameras, and other advanced technologies to inspect &amp; monitor numerous assets,
                        areas, and structures is referred to as drone Inspection and Monitoring... <span
                           class="read-more">
                        <a href="" class="read-more-small-btn">Read
                        more</a>
                        </span>
                     </p>
                  </div>
                  <div>
                     <nav aria-label="Page navigation example">
                        <ul class="pagination mb-0">
                           <li class="page-item"><a class="page-link" href="#">Previous</a></li>
                           <li class="page-item"><a class="page-link" href="#">1</a></li>
                           <li class="page-item"><a class="page-link" href="#">2</a></li>
                           <li class="page-item"><a class="page-link" href="#">3</a></li>
                           <li class="page-item"><a class="page-link" href="#">Next</a></li>
                        </ul>
                     </nav>
                  </div>
               </div>
            </div>
         </div>
         <div class="col-md-3 sm-100">
            <div class="box-shadow">
               <h6 class="fw-600 blue-title-bg"><i class="fa fa-user fs-14" aria-hidden="true"></i> Need Assistance?
               </h6>
               <div class="mb-2">
                  <p class="mb-0 fs-14">
                     <i class="fa fa-envelope me-2 orrange" aria-hidden="true"></i> WRITE AN EMAIL
                  </p>
                  <a href="mailto:sales@marknteladvisors.com">sales@marknteladvisors.com</a>
               </div>
               <div>
                  <p class="mb-0 fs-14"><i class="fa fa-phone me-2 orrange" aria-hidden="true"></i>CALL US</p>
                  <a class="fs-14" href="tel:+1 628 895 8081, +91 120 4278433">+1 628 895 8081, +91 120 4278433</a>
               </div>
            </div>
            <div class="box-shadow">
               <h6 class="fw-600 blue-title-bg"><i class="fa fa-lock me-2 fs-14 "></i>100% Safe & Secure</h6>
               <hr>
               <p class="fs-14">
                  Strongest encryption on the website to make your purchase safe and secure
               </p>
            </div>
         </div>
      </div>
   </div>
</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout/header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\markntel_advisor\resources\views/press_release.blade.php ENDPATH**/ ?>
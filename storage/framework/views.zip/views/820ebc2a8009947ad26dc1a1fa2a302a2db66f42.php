
<?php $__env->startSection('title','Upcoming Report'); ?>
<?php $__env->startSection('content'); ?>

<section class="mini-banner">
   <div class="container">
      <div class="row">
         <div class="col-md-12">
            <h1 class="mb-0 mini-banner-title">Contact Us </h1>
         </div>
      </div>
   </div>
</section>

	  <section class="ab-about-hero ab-section" style=" padding: 10px 0px !important;">
      <div class="ab-wrapper">
         <div class="ab-row ab-row-gap-huge">
            <div class="ab-col col-md-8 " style="text-align: left;">
               <h2 class="ab-title">Send a Message </h2>
                <?php if(count($errors) > 0): ?>
                      <div class = "alert alert-danger">
                        <ul>
                         <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><?php echo e($error); ?></li>
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                      </ul>
                  </div>
                   <?php endif; ?>
               <form action="<?php echo e(route('save_contact')); ?>" class="ab-contact-form"  method="post" novalidate="novalidate">
                     <?php echo csrf_field(); ?>
                  <div class="row" style="align-items: center;">
                     <div class="col-md-3">
                        <p style="font-size: 16px;">Full Name<span style="color:var(--primary-color)">*</span></p>
                     </div>
                     <div class="col-md-9">
                        <input class="ab-input" type="text" name="name" value="<?php echo e(old('name')); ?>" placeholder="Enter your name" required>
                         
                     </div>
                  </div>
                  <div class="row" style="align-items: center;">
                     <div class="col-md-3">
                        <p style="font-size: 16px;">Company Name<span style="color:var(--primary-color)">*</span></p>
                     </div>
                     <div class="col-md-9">
                        <input class="ab-input" type="text" name="comp_name" value="<?php echo e(old('comp_name')); ?>" placeholder="Enter your company name" required>
                     </div>
                  </div>
                  
                  <div class="row" style="align-items: center;">
                     <div class="col-md-3">
                        <p style="font-size: 16px;">Business Email<span style="color:var(--primary-color)">*</span></p>
                     </div>
                     <div class="col-md-9">
                        <input class="ab-input" type="email" name="business_email" value="<?php echo e(old('business_email')); ?>" placeholder="Enter your business email" required>
                     </div>
                  </div>
                  <div class="row" style="align-items: center;">
                     <div class="col-md-3">
                        <p style="font-size: 16px;">Country<span style="color:var(--primary-color)">*</span></p>
                     </div>
                     <div class="col-md-9">
                        <input class="ab-input"  name="country_name" type="tel"  value="<?php echo e(old('country_name')); ?>" placeholder="Enter Your Country" required>
                     </div>
                  </div>
                  <div class="row" style="align-items: center;">
                     <div class="col-md-3">
                        <p style="font-size: 16px;">Phone<span style="color:var(--primary-color)">*</span></p>
                     </div>
                     <div class="col-md-9">
                        <input class="ab-input"  name="phone" type="tel"  value="<?php echo e(old('phone')); ?>"  maxlength="13" placeholder="Enter Your Phone Number" required>
                     </div>
                  </div>

                  <!-- <div class="row" style="align-items: center;">
                     <div class="col-md-3">
                        <p style="font-size: 16px;">Recapcha<span style="color:var(--primary-color)">*</span></p>
                     </div>
                     <div class="col-md-9">
                        <div class="g-recaptcha" data-sitekey="<?php echo e(env('RECAPTCHAV3_SECRET')); ?>"></div>
                        <?php if($errors->has('g-recaptcha-response')): ?>
                           <span class="text-danger"><?php echo e($errors->first('g-recaptcha-response')); ?></span>
                        <?php endif; ?>
                     </div>
                  </div> -->
                    <div class="row" style="align-items: center;">
                     <div class="col-md-3">
                        <p style="font-size: 16px;">Message<span style="color:var(--primary-color)">*</span></p>
                     </div>
                     <div class="col-md-9">
                        <textarea class="ab-input"  name="message" cols="10" rows="1" placeholder="Type Your Message" required><?php echo e(old('message')); ?></textarea> 
                     </div>
                  </div>
                   <div class="row" style="align-items: center;">
                     <div class="col-md-3">
                       
                     </div>
                     <div class="col-md-9">
                       <div class="col-12">
                              <!--<div class="captcha">
                                 <button type="button" class="btn btn-info" class="reload" id="reload">
                                       &#x21bb;
                                 </button>&nbsp;&nbsp;
                                 <span><?php echo captcha_img(); ?></span>                                           
                              </div>-->
                              <div class="g-recaptcha" data-sitekey="<?php echo e(config('services.recaptcha.key')); ?>">
                           </div>
                           <div class="col-12 mt-2">
                              <!--<label class="form-label" for="form3Example4">Captcha*</label>
                              <input type="text" name="captcha" id="captcha" class="form-control" placeholder="Enter Captcha" required maxlength="5" />              
                           </div>
                           <?php if($errors->has('captcha')): ?>
                              <span class="text-danger">
                                    <strong><?php echo e($errors->first('captcha')); ?></strong>
                              </span>
                           <?php endif; ?> -->
                           <?php if($errors->has('g-recaptcha-response')): ?>
                                    <span class="help-block">
                                        <strong><?php echo e($errors->first('g-recaptcha-response')); ?></strong>
                                    </span>
                                <?php endif; ?>
                                </div>
                             </div>
                     </div>
                

                
                  <div class="row" style="align-items: center;">
                     <div class="col-md-3">
                     </div>
                     <div class="col-md-9">
                        <input type="checkbox" name="checkboxPolicy"class="styled">
                        <span style="font-size: 16px;">I have read and accept the <span style="color:var(--primary-color)">Privacy Policy *</span></span>
                     </div>
                  </div>
                  <div class="row" style="align-items: center;">
                     <div class="col-md-3">
                     </div>
                     <div class="col-md-9">
                        <button id="submitEnqiry"  class="ab-button ab-button-primary ab-button-large " type="submit">Send</button>
                     </div>
                  </div>
               </form>
            </div>
               </div>
            <div class="ab-col col-md-4 " style="text-align: left;">
               
               <div class="offic-div">
                  <p class="aside-title ab-mini-heading" style="color:#000; margin-top: 30px;">HEAD OFFICES</p>
                  <h3 class="office-tilte">
                     Rcube Headquarter Madrid
                  </h3>
                  <p class="address-p">C/ Campezo nº1 Parque Empresarial Las Mercedes 28022 Madrid Madrid Spain</p>
                  <p class="office-number"><a href="tel:+91876543210">Tel : <span>+91876543210</span> </a></p>
                  <p class="office-email"><a href="mailto:indo@rcube.com">Email : <span>info@rcube.com</span> </a></p>
                  <p class="office-loctaion"><a href="#">Location using Google Maps </a></p>
               </div>
               <div class="offic-div">
                  <h3 class="office-tilte">
                     Rcube Headquarter Barcelona
                  </h3>
                  <p class="address-p">C/ Campezo nº1 Parque Empresarial Las Mercedes 28022 Madrid Madrid Spain</p>
                  <p class="office-number"><a href="tel:+91876543210">Tel : <span>+91876543210</span> </a></p>
                  <p class="office-email"><a href="mailto:indo@rcube.com">Email : <span>info@rcube.com</span> </a></p>
                  <p class="office-loctaion"><a href="#">Location using Google Maps </a></p>
               </div>
               
            </div>
         </div>
      </div>
   </section>
	<script type="text/javascript">
		$('#reload').click(function () {
			$.ajax({
				type: 'GET',
				url: 'reload-captcha',
				success: function (data) {
					$(".captcha span").html(data.captcha);
				}
			});
		});
	</script>
	
<script src="<?php echo e(url('public/js/intlTelInput.min.js')); ?>"></script>
<script>
   var input = document.querySelector("#phone");
   input.setAttribute('placeholder', ' ');
   const countryNameElement = document.querySelector("#country-name");
   const iti = window.intlTelInput(input, {
      utilsScript: "https://cdnjs.cloudflare.com/ajax/libs/intl-tel-input/17.0.8/js/utils.js",
      separateDialCode: true,
      initialCountry: "US",
   });
   
 
   function updateCountryName() {
      const selectedCountryData = iti.getSelectedCountryData();
      //const selectedCountryName = selectedCountryData.name;
      const selectedCountryName = selectedCountryData.name.replace(/\s*\([^)]*\)/, '');
      countryNameElement.value = selectedCountryName;
      
   }

   input.addEventListener("countrychange", updateCountryName);   

</script>
<script src="https://www.google.com/recaptcha/api.js" async defer></script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout/header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u171619165/domains/vishalghosh.com/public_html/stagingrcube/site/resources/views/contact_us.blade.php ENDPATH**/ ?>
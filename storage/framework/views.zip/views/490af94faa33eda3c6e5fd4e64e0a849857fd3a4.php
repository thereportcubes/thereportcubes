
<?php $__env->startSection('title','Market Advisor'); ?>
<?php $__env->startSection('content'); ?>
<!-- banner slider start -->


<section class="hero_top mb-5" style="height:400px">
    <?php $__currentLoopData = $data_banner; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div>
       
        <div class="banner-with-text">
            <div class="banner-image">
                <?php 
                    $img = $data->banner_image;
                    $banner_desc = $data->banner_desc;
                ?>
                 <?php if (app('mobile-detect')->isMobile() && !app('mobile-detect')->isTablet()) : ?>
                    <?php 
                    $img = $data->banner_mobile_image;
                    $banner_desc = substr($data->banner_desc, 0, 50);
                ?>
                <?php endif; ?>
                <img src ="<?php echo e(asset('img/1.png')); ?>" loading="lazy" data-src="<?php echo e(asset('/uploads/banner')); ?>/<?php echo e($img); ?>" class="img-fluid lazy" alt="image-carousel">
            </div>
            <div class="pull-up-text">
                <div class="banner-content">
                   <h3 class="white-color"><?php echo e($data->banner_title); ?><span class="bright-span"></span></h3>
                   <h2 class="banner-title mb-4">
                   <?php echo e($banner_desc); ?></p>
                   <div class="read-more" data-aos="fade-up" data-aos-duration="1500">
                      <a href="<?php echo e($data->redirect_url); ?>" class="btn btn-primary banner-btn" tabindex="-1" rel="noopener noreferrer" target="_blank" aria-label="<?php echo e($data->banner_title); ?>">View More</a>
                   </div>
                </div>
            </div>
        </div>
      
    </div>
     <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</section>
<!-- about us section gose here -->
<section class="about-us">
   <div class="container">
      <div class="row">
         <div class="col-md-12 text-center">
            <h3 class="global-title">
               Industries Served
            </h3>
            </P> As a global market research company, with a notable presence in key markets such as USA, Europe, Southeast Asia, UK, GCC, Asia, and more.<br> We take pride in our ability to cover diverse industry through our comprehensive range of market research services.</P> 
         </div>
      </div>
      <div class="row flip-boxes">
         <div class="col-md-3">
            <div class="flip-container">
               <div class="flip-box">
                  <div class="flip-box-front">
                     <div>
                        <div class="w-100">
                           <img src ="<?php echo e(asset('img/1.png')); ?>" data-src="<?php echo e(url('img/aerospace8-min.webp')); ?>" loading="lazy" class="img-fluid served-icons lazy" alt="Aerospace" width="40" height="40" />
                        </div>
                        <div class="w-100">
                           <h4 class="industries-title">Aerospace & Defense</h4>
                        </div>
                     </div>
                  </div>
                  <div class="flip-box-back">
                      <a href="<?php echo e(url('research-library/aerospace-defense')); ?>" target="_blank" rel="noopener noreferrer">
                     <ul class="back-list">
                        <li style="list-style-type:none;"><h4 class="back-heading">Aerospace &amp; Defense</h4></li>
                        <li>Space Exploration</li>
                        <li>Aircraft Equipment &amp; Components</li>
                        <li>Armed Vehicles &amp; Ammunition</li>
                        <li>Avionics &amp; Electrical System</li>
                        <li>Security &amp; Surveillance</li>
                        <li>Unmanned Aerial Vehicles</li>
                     </ul>
                     </a>
                  </div>
               </div>
            </div>
         </div>
         <div class="col-md-3">
            <div class="flip-container">
               <div class="flip-box">
                  <div class="flip-box-front">
                     <div>
                        <div class="w-100">
                           <img loading="lazy" src ="<?php echo e(asset('img/1.png')); ?>"  data-src="<?php echo e(url('img/automobile4-min.webp')); ?>" class="img-fluid served-icons lazy" alt="Automotive"  width="60" height="40" />
                        </div>
                        <div class="w-100">
                           <h4 class="industries-title">Automotive</h4>
                        </div>
                     </div>
                  </div>
                  <div class="flip-box-back">
                      <a href="<?php echo e(url('research-library/automotive')); ?>" target="_blank" rel="noopener noreferrer">
                     <ul class="back-list">
                        <li  style="list-style-type:none;"><h4 class="back-heading">Automotive</h4></li>
                        <li>Automobiles</li>
                        <li>Autonomous &amp; Electric Vehicles</li>
                        <li>Driving Support &amp; Security</li>
                        <li>Automotive Components &amp; Materials</li>
                        <li>Automotive Electronics &amp; Electrical Equipment's</li>
                     </ul>
                     </a>
                  </div>
               </div>
            </div>
         </div>
         <div class="col-md-3">
            <div class="flip-container">
               <div class="flip-box">
                  <div class="flip-box-front">
                     <div>
                        <div class="w-100">
                           <img src ="<?php echo e(asset('img/1.png')); ?>" data-src="<?php echo e(url('img/buildingconst3-min.webp')); ?>" class="img-fluid served-icons lazy" alt="Buildings, Construction, Metals & Mining"  width="40" height="40" />
                        </div>
                        <div class="w-100">
                           <h4 class="industries-title">Buildings, Construction, Metals & Mining</h4>
                        </div>
                     </div>
                  </div>
                  <div class="flip-box-back">
                      <a href="<?php echo e(url('research-library/buildings-construction-metals-mining')); ?>" target="_blank" rel="noopener noreferrer">
                     <ul class="back-list">
                        <li  style="list-style-type:none;"><h4 class="back-heading">Buildings, Construction, Metals &amp; Mining</h4></li>
                        <li>Building Management</li>
                        <li>Construction Material</li>
                        <li>Construction Technology</li>
                        <li>Construction Equipment</li>
                     </ul>
                     </a>
                  </div>
               </div>
            </div>
         </div>
         <div class="col-md-3">
            <div class="flip-container">
               <div class="flip-box">
                  <div class="flip-box-front">
                     <div>
                        <div class="w-100">
                           <img src ="<?php echo e(asset('/img/1.png')); ?>" data-src="<?php echo e(asset('img/chemicals3-min.webp')); ?>" class="img-fluid served-icons lazy" alt="Chemicals"  width="40" height="40" />
                        </div>
                        <div class="w-100">
                           <h4 class="industries-title">Chemicals </h4>
                        </div>
                     </div>
                  </div>
                  <div class="flip-box-back">
                      <a href="<?php echo e(url('research-library/chemicals')); ?>" target="_blank" rel="noopener noreferrer">
                     <ul class="back-list">
                        <li  style="list-style-type:none;"><h4 class="back-heading">Chemicals</h4></li>
                        <li>Polymers</li>
                        <li>Coatings, Adhesives &amp; Pigments</li>
                        <li>Specialty Chemicals &amp; Other Chemicals</li>
                     </ul>
                     </a>
                  </div>
               </div>
            </div>
         </div>
         <div class="col-md-3">
            <div class="flip-container">
               <div class="flip-box">
                  <div class="flip-box-front">
                     <div>
                        <div class="w-100">
                           <img src ="<?php echo e(asset('img/1.png')); ?>" data-src="<?php echo e(asset('img/energy3-min.webp')); ?>" class="img-fluid served-icons lazy" alt="Energy"  width="40" height="40" />
                        </div>
                        <div class="w-100">
                           <h4 class="industries-title">Energy </h4>
                        </div>
                     </div>
                  </div>
                  <div class="flip-box-back">
                      <a href="<?php echo e(url('research-library/energy')); ?>" target="_blank" rel="noopener noreferrer">
                     <ul class="back-list">
                        <li  style="list-style-type:none;"><h4 class="back-heading">Energy</h4></li>
                        <li>Industrial Equipment</li>
                        <li>Green Economy</li>
                        <li>Oil &amp; Gas and Petrochemicals</li>
                        <li>Power Storage</li>
                        <li>Power Generation, Transmission &amp; Distribution</li>
                     </ul>
                     </a>
                  </div>
               </div>
            </div>
         </div>
         <div class="col-md-3">
            <div class="flip-container">
               <div class="flip-box">
                  <div class="flip-box-front">
                     <div>
                        <div class="w-100">
                           <img src ="<?php echo e(asset('img/1.png')); ?>" data-src="<?php echo e(url('asset/img/environmental3-min.webp')); ?>" class="img-fluid served-icons lazy" alt="Environment"  width="40" height="40" />
                        </div>
                        <div class="w-100">
                           <h4 class="industries-title">Environment </h4>
                        </div>
                     </div>
                  </div>
                  <div class="flip-box-back">
                       <a href="<?php echo e(url('research-library/environment')); ?>" target="_blank" rel="noopener noreferrer">
                     <ul class="back-list">
                        <li  style="list-style-type:none;"><h4 class="back-heading">Environment</h4></li>
                        <li>Agriculture</li>
                        <li>HVAC</li>
                        <li>Air Technology</li>
                        <li>Water Technologies</li>
                     </ul>
                     </a>
                  </div>
               </div>
            </div>
         </div>
         <div class="col-md-3">
            <div class="flip-container">
               <div class="flip-box">
                  <div class="flip-box-front">
                     <div>
                        <div class="w-100">
                           <img src ="<?php echo e(asset('img/1.png')); ?>" data-src="<?php echo e(asset('/img/fastmoving3-min.webp')); ?>" class="img-fluid served-icons lazy" alt="FMCG"  width="40" height="40" />
                        </div>
                        <div class="w-100">
                           <h4 class="industries-title">FMCG </h4>
                        </div>
                     </div>
                  </div>
                  <div class="flip-box-back">
                      <a href="<?php echo e(url('research-library/fmcg')); ?>" target="_blank" rel="noopener noreferrer">
                     <ul class="back-list">
                        <li  style="list-style-type:none;"><h4 class="back-heading">FMCG</h4></li>
                        <li>Consumer Goods and Retail</li>
                        <li>Clothing &amp; Personal Care</li>
                        <li>Consumer Electronics</li>
                     </ul>
                     </a>
                  </div>
               </div>
            </div>
         </div>
         <div class="col-md-3">
            <div class="flip-container">
               <div class="flip-box">
                  <div class="flip-box-front">
                     <div>
                        <div class="w-100">
                           <img src ="<?php echo e(asset('img/1.png')); ?>" data-src="<?php echo e(asset('img/fintech3-min.webp')); ?>" class="img-fluid served-icons lazy" alt="FinTech"  width="40" height="40" />
                        </div>
                        <div class="w-100">
                           <h4 class="industries-title">FinTech </h4>
                        </div>
                     </div>
                  </div>
                  <div class="flip-box-back">
                      <a href="<?php echo e(url('research-library/fintech')); ?>" target="_blank" rel="noopener noreferrer">
                     <ul class="back-list">
                        <li  style="list-style-type:none;"><h4 class="back-heading">FinTech</h4></li>
                        <li>Omnichannel</li>
                        <li>Digital Banking</li>
                        <li>Core Banking</li>
                     </ul>
                     </a>
                  </div>
               </div>
            </div>
         </div>
         <div class="col-md-3">
            <div class="flip-container">
               <div class="flip-box">
                  <div class="flip-box-front">
                     <div>
                        <div class="w-100">
                           <img src ="<?php echo e(asset('img/1.png')); ?>" data-src="<?php echo e(asset('img/food3-min.webp')); ?>" class="img-fluid served-icons lazy" alt="Food & Beverages"  width="40" height="40" />
                        </div>
                        <div class="w-100">
                           <h4 class="industries-title">Food & Beverages </h4>
                        </div>
                     </div>
                  </div>
                  <div class="flip-box-back">
                      <a href="<?php echo e(url('research-library/food-beverages')); ?>" target="_blank" rel="noopener noreferrer">
                     <ul class="back-list">
                        <li  style="list-style-type:none;"><h4 class="back-heading">Food &amp; Beverages</h4></li>
                        <li>Food Supplements &amp; Additives</li>
                        <li>Food Logistics, Warehousing &amp; Storage</li>
                        <li>Food Testing &amp; Packaging</li>
                        <li>Packaged &amp; Processed Food /Beverages</li>
                        <li>Food Ingredients</li>
                     </ul>
                     </a>
                  </div>
               </div>
            </div>
         </div>
         <div class="col-md-3">
            <div class="flip-container">
               <div class="flip-box">
                  <div class="flip-box-front">
                     <div>
                        <div class="w-100">
                           <img src ="<?php echo e(asset('img/1.png')); ?>" data-src="<?php echo e(url('asset/img/health3-min.webp')); ?>" class="img-fluid served-icons lazy" alt="Healthcare"  width="40" height="40" />
                        </div>
                        <div class="w-100">
                           <h4 class="industries-title">Healthcare </h4>
                        </div>
                     </div>
                  </div>
                  <div class="flip-box-back">
                      <a href="<?php echo e(url('research-library/healthcare')); ?>" target="_blank" rel="noopener noreferrer">
                     <ul class="back-list">
                        <li  style="list-style-type:none;"><h4 class="back-heading">Healthcare</h4></li>
                        <li>Life Sciences &amp; pharmaceuticals</li>
                        <li>Healthcare IT</li>
                        <li>Robotics &amp; Medical Imaging</li>
                        <li>Medical Services</li>
                        <li>Medical Devices &amp; Test Equipment</li>
                     </ul>
                     </a>
                  </div>
               </div>
            </div>
         </div>
         <div class="col-md-3">
            <div class="flip-container">
               <div class="flip-box">
                  <div class="flip-box-front">
                     <div>
                        <div class="w-100">
                           <img src ="<?php echo e(asset('img/1.png')); ?>" data-src="<?php echo e(url('asset/img/it-telcome2-min.webp')); ?>" class="img-fluid served-icons lazy" alt="ICT & Electronics"  width="40" height="40" />
                        </div>
                        <div class="w-100">
                           <h4 class="industries-title">ICT & Electronics </h4>
                        </div>
                     </div>
                  </div>
                  <div class="flip-box-back">
                      <a href="<?php echo e(url('research-library/ict-electronics')); ?>" target="_blank" rel="noopener noreferrer">
                     <ul class="back-list">
                        <li  style="list-style-type:none;"><h4 class="back-heading">ICT &amp; Electronics</h4></li>
                        <li>Electronic Equipment &amp; Services</li>
                        <li>Software &amp; Services</li>
                        <li>IT Security</li>
                        <li>IoT &amp; Digital Solutions</li>
                        <li>Data Centers &amp; Networking</li>
                        <li>Artificial Intelligence &amp; Robotics</li>
                        <li>Analytics</li>
                     </ul>
                     </a>
                  </div>
               </div>
            </div>
         </div>
         <div class="col-md-3">
            <div class="flip-container">
               <div class="flip-box">
                  <div class="flip-box-front">
                     <div>
                        <div class="w-100">
                           <img src ="<?php echo e(asset('img/1.png')); ?>" data-src="<?php echo e(asset('img/tire12-min.webp')); ?>" class="img-fluid served-icons lazy" alt="Tire"  width="40" height="40" />
                        </div>
                        <div class="w-100">
                           <h4 class="industries-title">Tire </h4>
                        </div>
                     </div>
                  </div>
                  <div class="flip-box-back">
                      <a href="<?php echo e(url('research-library/tires')); ?>" target="_blank" rel="noopener noreferrer">
                     <ul class="back-list">
                        <li  style="list-style-type:none;"><h4 class="back-heading">Tire</h4></li>
                        <li>Off the Road Vehicle Tire</li>
                        <li>Performance Tire</li>
                        <li>Comprehensive Tire Reports</li>
                     </ul>
                     </a>
                  </div>
               </div>
            </div>
         </div>
      </div>
   </div>
</section>
<!-- about us section end here -->
<!-- secent upcomming report section -->
<section class="upcomming-report bottom-space">
   <div class="container">
      <div class="row">
         <div class="col-md-12 text-center">
            <h3 class="global-title text-center">
               RECENT & UPCOMING REPORTS
            </h3>
            </P> Markntel Advisors stands at the forefront of market research, delivering a comprehensive selection of research reports that span various industries. <br> Our global reach extends to over 80 countries, providing valuable insights and analysis to clients across the globe.
            </P>
         </div>
      </div>
      <div class="row report-box-main">
         <?php $__currentLoopData = $report_data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $datas): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php if (app('mobile-detect')->isMobile() && !app('mobile-detect')->isTablet()) : ?>
                <?php if($key==3): ?>
                <?php 
                   break;
                   ?> 
                 <?php endif; ?>
            <?php endif; ?>
         <?php 
            $exp_arr = explode('Market', $datas->title);
            $res = $exp_arr[0]." Market ...";
         ?> 
         <div class="col-md-3">
            
            <a href="<?php echo e(url('research-library')); ?>/<?php echo e($datas->page_url); ?>" class="black" target="_blank" rel="noopener noreferrer">
               <div class="report-box">
                  <div class="report-image">
                     <img src ="<?php echo e(asset('img/1.png')); ?>" data-src="<?php echo e(asset('img/market_research_consulting.webp')); ?>" class="img-fluid lazy" alt="Market Research Report" width="271" height="140">
                  </div>
                  <div class="report-content">
                     <h4 class="report-title mb-2"><?php echo e($res); ?></h4>
                     <div class="report-date-page d-flex align-items-center justify-content-between ">
                        <p><i class="fa fa-calendar" aria-hidden="true"></i><span> <?php echo e(Carbon\Carbon::parse($datas->report_post_date)->format('M Y')); ?></span></p>
                        <p><?php echo e("Pages ".$datas->no_of_page); ?></p>
                     </div>
                     
                  </div>
               </div>
            </a>
            
         </div>
         <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </div>
      <div class="row pt-4">
         <div class="col-md-12 text-center">
            <a href="<?php echo e(url('research-library')); ?>" class="btn btn-primary banner-btn" tabindex="-1" target="_blank" rel="noopener noreferrer">View More</a>
         </div>
      </div>
   </div>
</section>
<!-- blog section start -->
<section class="blog-notes bottom-space">
   <div class="container">
      <div class="row">
         <div class="col-md-6">
            <div class="blog-box">
               <h4 class="blog-main-titl">Market Research - Press Release</h4>
               
               <?php $__currentLoopData = $press_release; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $press): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
               <div class="release-listing">
                  <h5 class="mb-0 blog_titles"><?php echo e($press->heading); ?>

</h5>
                  <a href="<?php echo e(url('press-release')); ?>/<?php echo e($press->press_release_url); ?>" class="read-more-blog blue" target="_blank"  rel="noopener noreferrer" aria-label="<?php echo e($press->heading); ?>">View More....</a>
                  <p class="fs-12 mb-0">Published Date : <?php echo e(Carbon\Carbon::parse($press->report_post_date)->format('M Y')); ?></p>
               </div>
               <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
               <a href="<?php echo e(url('press-release')); ?>" class="btn btn-primary" target="_blank" rel="noopener noreferrer">View More</a>
            </div>
         </div>
         <div class="col-md-6 ">
            <div class="blog-box">
               <h4 class="blog-main-titl">Market Research Blogs</h4>
               <?php $__currentLoopData = $blogs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $blog): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
               <div class="release-listing">
                  <h5 class="mb-0 blog_titles"><?php echo e($blog->title); ?></h5>
                  <a href="<?php echo e(url('/blogs')); ?>/<?php echo e($blog->slug); ?>" class="read-more-blog blue" target="_blank" rel="noopener noreferrer" aria-label="<?php echo e($blog->title); ?>">View More....</a>
                  <p class="fs-12 mb-0">Published Date : <?php echo e(Carbon\Carbon::parse($blog->created_at)->format('M Y')); ?></p>
               </div>
               <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                
               <a href="<?php echo e(url('/blogs')); ?>" class="btn btn-primary" target="_blank" rel="noopener noreferrer">View More</a>
            </div>
         </div>
      </div>
   </div>
</section>
<!-- blog section end -->
<!-- our serices  -->
<section class="our-services bottom-space">
   <div class="container">
      <div class="row">
         <div class="col-md-12 text-center">
            
            <h1 class="global-title">
              Services offered by one of the leading market research company - Markntel Advisors
            </h1>
            </P>We specialize in delivering comprehensive and strategic insights that empower businesses to thrive in dynamic and competitive landscapes. With a global perspective and a commitment to excellence, we offer actionable intelligence that enables companies to make informed decisions.</P> 
            </P>
         </div>
      </div>
      <div class="row service-main">

         <?php $__currentLoopData = $services; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $service): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
         <div class="col-md-3">
            <div class="service-box">
               <div class="">
                  <img src ="<?php echo e(asset('img/1.png')); ?>" data-src="<?php echo e(asset('')); ?>/<?php echo e($service->services_image); ?>" class="img-fluid w-100 lazy" alt="<?php echo e($service->service_name); ?>" width="286" height="150" />
               </div>
               <div class="p-3 service-content-box">
                  <h4 class="mb-1 fw-800"><?php echo e($service->service_name); ?></h4>
                  <p class="fs-15 mb-2"><?php echo strip_tags(substr($service->services_desc, '0','100')).' ...' ; ?></p>
                  <a href="<?php echo e(url('/services')); ?>" class="fw-600" tabindex="0" rel="noopener noreferrer">For more <i class="fa fa-arrow-right fs-14"></i></a>
               </div>
            </div>
         </div>
         <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

      </div>
   </div>
</section>
<!-- our serices  end -->
<section class="fast-fact mb-5">
   <div class="container">
      <div class="row">
         <div class="col-md-12 text-center">
            <h2 class="global-title">
               What makes Markntel Advisors a reliable market research partner
            </h2>
         </div>
      </div>
      <div class="row clients-counter">
         <div class="col-md-3">
            <div class="text-center">
               <img src ="<?php echo e(asset('img/1.png')); ?>" data-src="<?php echo e(asset('img/client.svg')); ?>" class="mb-2 lazy" alt="" width="45" height="55" />
               <h3 class="fw-600 mb-0"><span id="counter1">1000</span><span>+</span></h3>
               <p class="mb-0">Clients</p>
            </div>
         </div>
         <div class="col-md-3">
            <div class="text-center">
               <img src ="<?php echo e(asset('img/1.png')); ?>" data-src="<?php echo e(asset('img/countriess.svg')); ?>" class="mb-2 lazy" alt="" width="45" height="55" />
               <h3 class="fw-600 mb-0"><span id="counter2"></span><span>+</span></h3>
               <p class="mb-0">Countries Covered</p>
            </div>
         </div>
         <div class="col-md-3">
            <div class="text-center">
               <img src ="<?php echo e(asset('img/1.png')); ?>" data-src="<?php echo e(asset('img/customized reports (1).svg')); ?>" class="mb-2 lazy" alt="" width="45" height="55" />
               <h3 class="fw-600 mb-0"><span id="counter3"></span><span>+</span></h3>
               <p class="mb-0">Customized Reports
               </p>
            </div>
         </div>
         <div class="col-md-3">
            <div class="text-center">
               <img src ="<?php echo e(asset('img/1.png')); ?>" data-src="<?php echo e(asset('img/customized reports (1).svg')); ?>" class="mb-2 lazy" alt="" width="45" height="55" />
               <h3 class="fw-600 mb-0"><span id="counter4"></span><span>+</span></h3>
               <p class="mb-0">Emerging Technologies</p>
            </div>
         </div>
      </div>
   </div>
</section>
<!-- what our client say -->
<section class="client-say bottom-space">
   <div class="container">
      <div class="row">
         <div class="col-md-12 text-center">
            <h4 class="global-title ">
               WHAT OUR CLIENTS SAY ABOUT US
            </h4>
         </div>
      </div>
      <div class="row main-clients">
         <?php $__currentLoopData = $testimonials; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $test): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
         <div class="col-md-4">
            <div class="client-say-box">
               <?php echo $test->description ?>
               <p class="mb-0 client-name">
                  <?php echo e($test->client_name); ?>

                  <?php echo e($test->client_country); ?>

               </p>
            </div>
         </div>
         <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
         
      </div>
   </div>
</section>
<!-- what our client say end -->
<!-- latest report or blog section start -->
<section class="report-section pb-5 ">
   <div class="container">
      <div class="row">
         <div class="col-md-12 text-center">
            <h4 class="global-title ">
               FEW OF OUR CLIENTS
            </h4>
         </div>
      </div>
      <div class="row">
         <div class="col-md-12">
            <div class="client_logo">
               <div>
                  <img src="<?php echo e(asset('img/2000px-Veolia-Logo_svg_.webp')); ?>" class="img-fluid client-logo lazy" alt="Veolia" width="214" height="111">
               </div>
               <div>
                  <img src="<?php echo e(asset('img/Amcor-logo-1024.webp')); ?>" class="img-fluid client-logo lazy" alt="Amcor" width="214" height="111">
               </div>
               <div>
                  <img src="<?php echo e(asset('img/Carrier-Logo.webp')); ?>" class="img-fluid client-logo lazy" alt="Carrier" width="214" height="111">
               </div>
               <div>
                  <img src="<?php echo e(asset('img/inmarsat-logo-color1.webp')); ?>" class="img-fluid client-logo lazy" alt="inmarsat" width="214" height="111">
               </div>
               <div>
                  <img src="<?php echo e(asset('img/L3-Harris-logo-2019.webp')); ?>" class="img-fluid client-logo lazy" alt="L3-Harris" width="214" height="111">
               </div>
               <div>
                  <img src="<?php echo e(asset('img/Michelin-Embleme.webp')); ?>" class="img-fluid client-logo lazy" alt="Michelin" width="214" height="111">
               </div>
               <div>
                  <img src="<?php echo e(asset('img/oc-oerlikon-corporation-ag-pfaffikon.webp')); ?>" class="img-fluid client-logo lazy" alt="Oerlikon" width="214" height="111">
               </div>
               <div>
                  <img src="<?php echo e(asset('img/polycom-logo-R-h-cmyk-2000px.webp')); ?>" class="img-fluid client-logo lazy" alt="polycom" width="214" height="111">
               </div>
            </div>
         </div>
      </div>
   </div>
</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout/newheader', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\markintal_site\resources\views/home.blade.php ENDPATH**/ ?>
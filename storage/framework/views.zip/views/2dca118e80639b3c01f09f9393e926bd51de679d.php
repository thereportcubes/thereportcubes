<?php echo $__env->yieldContent('title'); ?>
<?php $__env->startSection('content'); ?>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
<link rel="stylesheet" href="https://www.marknteladvisors.com/theme/css/intlTelInput.css">
<style>
   .intl-tel-input .flag-dropdown{
      margin-top: 10px!important;
   }
       
</style>
<main>
   <section id="content-infos-pages">
      <section class="ab-title-section ab-bg-dark-red ab-color-white ab-section">
         <div class="ab-title-section-bg" style="background-image: url(/rcube/assent/images/banner.jpg);">
            <div class="ab-section-divider">
               <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 100 100" preserveAspectRatio="none">
                  <polygon points="0,0 100,0 0,100"></polygon>
               </svg>
            </div>
         </div>
         <div class="ab-wrapper">
            <div class="ab-title-section-text">
               <h1 class="ab-large-title">Contact Us </h1>
              
            </div>
         </div>
      </section>
      <div class="banner-triangle"></div>
   </section>
   <section class="ab-about-hero ab-section" style=" padding: 40px 0px;">
      <div class="ab-wrapper">
         <div class="ab-row ab-row-gap-huge">
            <div class="ab-col col-md-8 " style="text-align: left;">
               <h2 class="ab-title">Send a Message </h2>
               <form action="" class="ab-contact-form"  method="post" novalidate="novalidate">
                  
                  <div class="row" style="align-items: center;">
                     <div class="col-md-3">
                        <p style="font-size: 16px;">Full Name<span style="color:var(--primary-color)">*</span></p>
                     </div>
                     <div class="col-md-9">
                        <input class="ab-input" type="text" placeholder="Enter your name" required>
                     </div>
                  </div>
                  <div class="row" style="align-items: center;">
                     <div class="col-md-3">
                        <p style="font-size: 16px;">Company Name<span style="color:var(--primary-color)">*</span></p>
                     </div>
                     <div class="col-md-9">
                        <input class="ab-input" type="text" placeholder="Enter your company name">
                     </div>
                  </div>
                  
                  <div class="row" style="align-items: center;">
                     <div class="col-md-3">
                        <p style="font-size: 16px;">Business Email<span style="color:var(--primary-color)">*</span></p>
                     </div>
                     <div class="col-md-9">
                        <input class="ab-input" type="email" placeholder="Enter your business email">
                     </div>
                  </div>
                  <div class="row" style="align-items: center;">
                     <div class="col-md-3">
                        <p style="font-size: 16px;">Phone<span style="color:var(--primary-color)">*</span></p>
                     </div>
                     <div class="col-md-9">
                        <input class="ab-input mobivali" type="tel" maxlength="13" style="height:49px;">
                     </div>
                  </div>

                  <div class="row" style="align-items: center;">
                     <div class="col-md-3">
                        <p style="font-size: 16px;">Recapcha<span style="color:var(--primary-color)">*</span></p>
                     </div>
                     <div class="col-md-9">
                        <div class="g-recaptcha" data-sitekey="<?php echo e(env('RECAPTCHAV3_SECRET')); ?>"></div>
                        <?php if($errors->has('g-recaptcha-response')): ?>
                           <span class="text-danger"><?php echo e($errors->first('g-recaptcha-response')); ?></span>
                        <?php endif; ?>
                     </div>
                  </div>
                 
                  <div class="row" style="align-items: center;">
                     <div class="col-md-3">
                        <p style="font-size: 16px;">Message<span style="color:var(--primary-color)">*</span></p>
                     </div>
                     <div class="col-md-9">
                        <textarea class="ab-input" cols="10" rows="1"></textarea> 
                     </div>
                  </div>
                  <div class="row" style="align-items: center;">
                     <div class="col-md-3">
                     </div>
                     <div class="col-md-9">
                        <input type="checkbox" name="checkboxPolicy"class="styled">
                        <span style="font-size: 16px;">I have read and accept the <span style="color:var(--primary-color)">Privacy Policy *</span></span>
                     </div>
                  </div>
                  <div class="row" style="align-items: center;">
                     <div class="col-md-3">
                     </div>
                     <div class="col-md-9">
                        <button id="submitEnqiry"  class="ab-button ab-button-primary ab-button-large " type="submit">Send</button>
                     </div>
                  </div>
               </form>
            </div>
            <div class="ab-col col-md-4 " style="text-align: left;">
               
               <div class="offic-div">
                  <p class="aside-title ab-mini-heading" style="color:#000; margin-top: 30px;">HEAD OFFICES</p>
                  <h3 class="office-tilte">
                     Rcube Headquarter Madrid
                  </h3>
                  <p class="address-p">C/ Campezo nº1 Parque Empresarial Las Mercedes 28022 Madrid Madrid Spain</p>
                  <p class="office-number"><a href="tel:+91876543210">Tel : <span>+91876543210</span> </a></p>
                  <p class="office-email"><a href="mailto:indo@rcube.com">Email : <span>info@rcube.com</span> </a></p>
                  <p class="office-loctaion"><a href="#">Location using Google Maps </a></p>
               </div>
               <div class="offic-div">
                  <h3 class="office-tilte">
                     Rcube Headquarter Barcelona
                  </h3>
                  <p class="address-p">C/ Campezo nº1 Parque Empresarial Las Mercedes 28022 Madrid Madrid Spain</p>
                  <p class="office-number"><a href="tel:+91876543210">Tel : <span>+91876543210</span> </a></p>
                  <p class="office-email"><a href="mailto:indo@rcube.com">Email : <span>info@rcube.com</span> </a></p>
                  <p class="office-loctaion"><a href="#">Location using Google Maps </a></p>
               </div>
               
            </div>
         </div>
      </div>
   </section>
</main>
<script src="https://www.marknteladvisors.com/theme/js/intlTelInput.js"></script>
<script>
      $(".mobivali").intlTelInput();
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.newheader', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\markintal_site\resources\views/contact1.blade.php ENDPATH**/ ?>
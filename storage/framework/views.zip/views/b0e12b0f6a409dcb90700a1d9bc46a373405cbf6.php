<!DOCTYPE html>
<html lang="en">

<head>
   <meta charset="UTF-8">
   <meta http-equiv="X-UA-Compatible" content="IE=edge">
   <meta name="viewport" content="width=device-width, initial-scale=1.0">
<meta name="robots" content="noindex, nofollow" />
  
   <meta name="author" content="Report cube">
   <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>" />
   
<script type="application/ld+json"> 

     { 

 

      "@context": "https://schema.org", 

      "@type": "Organization", 

      "name": "The Report Cube", 

      "alternateName": "thereportcube", 

      "url": "https://www.thereportcube.com/", 

      "logo": "https://thereportcube.com/public/assets/images/rcube-logo.png", 

 

      "contactPoint": [{ 

 

         "@type": "ContactPoint", 

         "telephone": "+971 564468112", 

         "contactType": "customer service", 

         "areaServed": "GCC", 

         "availableLanguage": "en" 

 

      }], 

 

      "email" : "sales@thereportcube.com", 

 

      "address" : { 

 

      "@type" : "PostalAddress", 

 

      "streetAddress" : "C/Burjuman Business Tower - Dubai - United Arab Emirates,", 

      "addressLocality" : "Dubai", 

      "addressRegion" : "GCC", 

      "addressCountry" : "UAE", 

        "postalCode" : "121828" 

      } 

     } 

  

   </script> 
   <?php
   $seo_data = "";
   $seo_slug_url = "";
   $seo_slug_url_type = request()->segment(1);
   $seo_slug_url = request()->segment(2);
   if ($seo_slug_url_type == "infographics" &&  $seo_slug_url != "") {
      $parent_id = \DB::table('infographic')->where('slug', $seo_slug_url)->first();
      if (!is_null($parent_id)) {
   ?>
         <title><?php echo @$parent_id->seo_title; ?></title>
         <meta name="description" content="<?php echo @$parent_id->seo_description; ?>" />
         <meta name="keywords" content="<?php echo @$parent_id->seo_keyword; ?>">
         <link rel="canonical" href="<?php echo e(url()->current()); ?>" />
         <meta property="og:type" content="news" />
         <meta property="og:title" content="<?php echo @$parent_id->seo_title; ?>" />
         <meta property="og:image" content="<?php echo e(asset('img/rcube-logo.png')); ?>" />
         <meta property="og:description" content="<?php echo @$parent_id->seo_description; ?>" />
         <meta property="og:url" content="<?php echo e(url()->current()); ?>">
         <meta name="twitter:card" content="<?php echo e(asset('img/rcube-logo.png')); ?>" />
         <meta name="twitter:site" content="Report Cube" />
         <meta name="twitter:title" content="<?php echo @$parent_id->seo_title; ?>" />
         <meta name="twitter:description" content="<?php echo @$parent_id->seo_description; ?>" />
         <base href="<?php echo e(url()->current()); ?>">
         <script type="application/ld+json">
            {
               "@context": "https://schema.org",
               "@type": "BreadcrumbList",
               "itemListElement": [{
                     "@type": "ListItem",
                     "position": 1,
                     "item": {
                        "@type": "webpage",
                        "@id": "<?php echo e(url('/')); ?>",
                        "name": "Home"
                     }
                  },
                  {
                     "@type": "ListItem",
                     "position": 2,
                     "item": {
                        "@type": "webpage",
                        "@id": "<?php echo e(url('/infographics')); ?>",
                        "name": "Infographics"
                     }
                  },
                  {
                     "@type": "ListItem",
                     "position": 3,
                     "item": {
                        "@type": "webpage",
                        "@id": "<?php echo e(url('/infographics')); ?>/<?php echo e(request()->segment(2)); ?>",
                        "name": "<?php echo e($parent_id->title); ?>"
                     }
                  }
               ]
            }
         </script>
      <?php }
   } else if ($seo_slug_url_type == "infographics" && $seo_slug_url == "") { ?>
      <title>R cube - Market Research Reports</title>
      <meta name="keywords" content="Market Research Infographics, Market Research Reports Infographics, Infographics">
      <meta name="description" content="The Report Cube anticipate market growth, analysis, demand and mention in the form of infographics for across sectors like Aerospace and Defense, Automotive, Building, Construction, Metals and Mining, Chemicals, Energy, healthcare, Food and Beverages etc." />
      <link rel="canonical" href="<?php echo e(url()->current()); ?>" />
      <meta property="og:type" content="news" />
      <meta property="og:title" content="Market Research Reports Infographics - The Report Cube" />
      <meta property="og:image" content="<?php echo e(asset('img/rcube-logo.png')); ?>" />
      <meta property="og:description" content="The Report Cubes anticipate market growth, analysis, demand and mention in the form of infographics for across sectors like Aerospace and Defense, Automotive, Building, Construction, Metals and Mining, Chemicals, Energy, healthcare, Food and Beverages etc." />
      <meta property="og:url" content="<?php echo e(url()->current()); ?>">

      <meta name="twitter:card" content="<?php echo e(asset('img/rcube-logo.png')); ?>" />
      <meta name="twitter:site" content="The Report Cube" />
      <meta name="twitter:title" content="Market Research Reports Infographics - The Report Cube" />
      <meta name="twitter:description" content="The Report Cube anticipate market growth, analysis, demand and mention in the form of infographics for across sectors like Aerospace and Defense, Automotive, Building, Construction, Metals and Mining, Chemicals, Energy, healthcare, Food and Beverages etc." />
      <base href="<?php echo e(url()->current()); ?>">

      <script type="application/ld+json">
         {
            "@context": "https://schema.org",
            "@type": "BreadcrumbList",
            "itemListElement": [{
                  "@type": "ListItem",
                  "position": 1,
                  "item": {
                     "@type": "webpage",
                     "@id": "<?php echo e(url('/')); ?>",
                     "name": "Home"
                  }
               },
               {
                  "@type": "ListItem",
                  "position": 2,
                  "item": {
                     "@type": "webpage",
                     "@id": "<?php echo e(url('/infographics')); ?>",
                     "name": "Infographics"
                  }
               }
            ]
         }
      </script>

   <?php } else if ($seo_slug_url_type == "press-release" && $seo_slug_url != "") {
      $button_ref = '';
      $parent_id = \DB::table('press_release')->where('press_release_url', $seo_slug_url)->first();
      if (!is_null($parent_id)) {
         $button_ref = $parent_id->button_refrence;
         if ($button_ref != "") {
            $but_ref = explode('/', $button_ref);
            $report = \DB::table('reports')->where('page_url', $but_ref['4'])->first();
         }
         $seo_data = \DB::table('seo_content')->where('parent_id', $parent_id->id)->where('page_type', 'press_release')->orderBy('id', 'DESC')->first();
      } else {
         $seo_data = \DB::table('seo_content')->where('page_type', 'press_release')->orderBy('id', 'DESC')->first();
      }

   ?>
      <title><?php echo $seo_data->seo_title; ?></title>
      <meta name="description" content="<?php echo $seo_data->seo_description; ?>" />
      <meta name="keywords" content="<?php echo $seo_data->seo_key_words; ?>">
      <link rel="canonical" href="<?php echo e(url()->current()); ?>" />

      <meta property="og:type" content="news" />
      <meta property="og:title" content="<?php echo $seo_data->seo_title; ?>" />
      <meta property="og:image" content="<?php echo e(asset('img/rcube-logo.png')); ?>" />
      <meta property="og:description" content="<?php echo $seo_data->seo_description; ?>" />
      <meta property="og:url" content="<?php echo e(url()->current()); ?>">

      <meta name="twitter:card" content="<?php echo e(asset('img/rcube-logo.png')); ?>" />
      <meta name="twitter:site" content="The Report Cube" />
      <meta name="twitter:title" content="<?php echo $seo_data->seo_title; ?>" />
      <meta name="twitter:description" content="<?php echo $seo_data->seo_description; ?>" />
      <base href="<?php echo e(url()->current()); ?>">

      <script type="application/ld+json">
         {
            "@context": "https://schema.org",
            "@type": "BreadcrumbList",
            "itemListElement": [{
                  "@type": "ListItem",
                  "position": 1,
                  "item": {
                     "@type": "webpage",
                     "@id": "<?php echo e(url('/')); ?>",
                     "name": "Home"
                  }
               },
               {
                  "@type": "ListItem",
                  "position": 2,
                  "item": {
                     "@type": "webpage",
                     "@id": "<?php echo e(url('/press-release')); ?>",
                     "name": "Press Release"
                  }
               },
               {
                  "@type": "ListItem",
                  "position": 3,
                  "item": {
                     "@type": "webpage",
                     "@id": "<?php echo e(url('/press-release')); ?>/<?php echo e(request()->segment(2)); ?>",
                     "name": "<?php echo e(@$report->title); ?>"
                  }
               }
            ]
         }
      </script>

   <?php } else if ($seo_slug_url_type == "press-release" && $seo_slug_url == "") {
      $parent_id = \DB::table('seo_pages')->where('page_key', 'press_release')->first();
      $seo_content = \DB::table('seo_content')->where('parent_id', $parent_id->id)->where('page_type', 'press_release')->first();
   ?>
      <title><?php echo $seo_content->seo_title; ?></title>
      <meta name="description" content="<?php echo $seo_content->seo_description; ?>" />
      <meta name="keywords" content="<?php echo $seo_content->seo_key_words; ?>">
      <link rel="canonical" href="<?php echo e(url()->current()); ?>" />

      <meta property="og:type" content="news" />
      <meta property="og:title" content="<?php echo $seo_content->seo_title; ?>" />
      <meta property="og:image" content="<?php echo e(asset('img/rcube-logo.png')); ?>" />
      <meta property="og:description" content="<?php echo $seo_content->seo_description; ?>" />
      <meta property="og:url" content="<?php echo e(url()->current()); ?>">

      <meta name="twitter:card" content="<?php echo e(asset('img/rcube-logo.png')); ?>" />
      <meta name="twitter:site" content="The Report Cube" />
      <meta name="twitter:title" content="<?php echo $seo_content->seo_title; ?>" />
      <meta name="twitter:description" content="<?php echo $seo_content->seo_description; ?>" />
      <base href="<?php echo e(url()->current()); ?>">

      <script type="application/ld+json">
         {
            "@context": "https://schema.org",
            "@type": "BreadcrumbList",
            "itemListElement": [{
                  "@type": "ListItem",
                  "position": 1,
                  "item": {
                     "@type": "webpage",
                     "@id": "<?php echo e(url('/')); ?>",
                     "name": "Home"
                  }
               },
               {
                  "@type": "ListItem",
                  "position": 2,
                  "item": {
                     "@type": "webpage",
                     "@id": "<?php echo e(url('/press-release')); ?>",
                     "name": "Press Release"
                  }
               }

            ]
         }
      </script>

   <?php } else if ($seo_slug_url_type == "contact-us" && $seo_slug_url == "") {

      $seo_data = \DB::table('seo_content')->where('page_type', 'contact_us')->orderBy('id', 'DESC')->first();
   ?>

      <title><?php echo $seo_data->seo_title; ?></title>
      <meta name="description" content="<?php echo $seo_data->seo_description; ?>" />
      <meta name="keywords" content="<?php echo $seo_data->seo_key_words; ?>">
      <link rel="canonical" href="<?php echo e(url()->current()); ?>" />

      <meta property="og:type" content="news" />
      <meta property="og:title" content="<?php echo $seo_data->seo_title; ?>" />
      <meta property="og:image" content="<?php echo e(asset('img/rcube-logo.png')); ?>" />
      <meta property="og:description" content="<?php echo $seo_data->seo_description; ?>" />
      <meta property="og:url" content="<?php echo e(url()->current()); ?>">

      <meta name="twitter:card" content="<?php echo e(asset('img/rcube-logo.png')); ?>" />
      <meta name="twitter:site" content="The Report Cube" />
      <meta name="twitter:title" content="<?php echo $seo_data->seo_title; ?>" />
      <meta name="twitter:description" content="<?php echo $seo_data->seo_description; ?>" />
      <base href="<?php echo e(url()->current()); ?>">

      <script type="application/ld+json">
         {
            "@context": "https://schema.org",
            "@type": "BreadcrumbList",
            "itemListElement": [

               {
                  "@type": "ListItem",
                  "position": 1,
                  "item": {
                     "@type": "webpage",
                     "@id": "<?php echo e(url('/')); ?>",
                     "name": "Home"
                  }
               },
               {
                  "@type": "ListItem",
                  "position": 2,
                  "item": {
                     "@type": "webpage",
                     "@id": "<?php echo e(url('/contact-us')); ?>",
                     "name": "Indexphp"
                  }
               }
            ]
         }
      </script>

   <?php } else if ($seo_slug_url_type == "" && $seo_slug_url == "") {
      $seo_data = \DB::table('seo_content')->where('page_type', 'home')->orderBy('id', 'DESC')->first();
   ?>


      <title><?php echo $seo_data->seo_title; ?></title>
      <meta name="description" content="<?php echo $seo_data->seo_description; ?>" />
      <meta name="keywords" content="<?php echo $seo_data->seo_key_words; ?>">
      <link rel="canonical" href="<?php echo e(url()->current()); ?>" />

      <meta property="og:type" content="news" />
      <meta property="og:title" content="<?php echo $seo_data->seo_title; ?>" />
      <meta property="og:image" content="<?php echo e(asset('img/rcube-logo.png')); ?>" />
      <meta property="og:description" content="<?php echo $seo_data->seo_description; ?>" />
      <meta property="og:url" content="<?php echo e(url()->current()); ?>">

      <meta name="twitter:card" content="<?php echo e(asset('img/rcube-logo.png')); ?>" />
      <meta name="twitter:site" content="The Report Cube" />
      <meta name="twitter:title" content="<?php echo $seo_data->seo_title; ?>" />
      <meta name="twitter:description" content="<?php echo $seo_data->seo_description; ?>" />
      <base href="<?php echo e(url()->current()); ?>">

     <script type="application/ld+json">
{
"@context": "https://schema.org/",
"@type": "WebSite",
"name": "The Report Cube",
"url": "https://www.thereportcube.com/",
"potentialAction": {
"@type": "SearchAction",
"target": "{search_term_string}",
"query-input": "required name=search_term_string"
}
}
</script>



   <?php } else if ($seo_slug_url_type == "about-us" && $seo_slug_url == "") {

      $seo_data = \DB::table('seo_content')->where('page_type', 'about_us')->orderBy('id', 'DESC')->first();
   ?>

      <title><?php echo $seo_data->seo_title; ?></title>
      <meta name="description" content="<?php echo $seo_data->seo_description; ?>" />
      <meta name="keywords" content="<?php echo $seo_data->seo_key_words; ?>">
      <link rel="canonical" href="<?php echo e(url()->current()); ?>" />

      <meta property="og:type" content="news" />
      <meta property="og:title" content="<?php echo $seo_data->seo_title; ?>" />
      <meta property="og:image" content="<?php echo e(asset('img/rcube-logo.png')); ?>" />
      <meta property="og:description" content="<?php echo $seo_data->seo_description; ?>" />
      <meta property="og:url" content="<?php echo e(url()->current()); ?>">

      <meta name="twitter:card" content="<?php echo e(asset('img/rcube-logo.png')); ?>" />
      <meta name="twitter:site" content="The Report Cube" />
      <meta name="twitter:title" content="<?php echo $seo_data->seo_title; ?>" />
      <meta name="twitter:description" content="<?php echo $seo_data->seo_description; ?>" />
      <base href="<?php echo e(url()->current()); ?>">

   <?php } else if ($seo_slug_url_type == "careers" && $seo_slug_url == "") {

      $seo_data = \DB::table('seo_content')->where('page_type', 'careers')->orderBy('id', 'DESC')->first();
   ?>

      <title><?php echo @$seo_data->seo_title; ?></title>
      <meta name="description" content="<?php echo @$seo_data->seo_description; ?>" />
      <meta name="keywords" content="<?php echo @$seo_data->seo_key_words; ?>">
      <link rel="canonical" href="<?php echo e(url()->current()); ?>" />

      <meta property="og:type" content="news" />
      <meta property="og:title" content="<?php echo @$seo_data->seo_title; ?>" />
      <meta property="og:image" content="<?php echo e(asset('img/rcube-logo.png')); ?>" />
      <meta property="og:description" content="<?php echo @$seo_data->seo_description; ?>" />
      <meta property="og:url" content="<?php echo e(url()->current()); ?>">

      <meta name="twitter:card" content="<?php echo e(asset('img/rcube-logo.png')); ?>" />
      <meta name="twitter:site" content="The Report Cube" />
      <meta name="twitter:title" content="<?php echo @$seo_data->seo_title; ?>" />
      <meta name="twitter:description" content="<?php echo @$seo_data->seo_description; ?>" />
      <base href="<?php echo e(url()->current()); ?>">

   <?php } else if ($seo_slug_url_type == "export-import-data" && $seo_slug_url == "") {

      $seo_data = \DB::table('seo_content')->where('page_type', 'tire_exim')->orderBy('id', 'DESC')->first();
   ?>

      <title><?php echo $seo_data->seo_title; ?></title>
      <meta name="description" content="<?php echo $seo_data->seo_description; ?>" />
      <meta name="keywords" content="<?php echo $seo_data->seo_key_words; ?>">
      <link rel="canonical" href="<?php echo e(url()->current()); ?>" />

      <meta property="og:type" content="news" />
      <meta property="og:title" content="<?php echo $seo_data->seo_title; ?>" />
      <meta property="og:image" content="<?php echo e(asset('img/rcube-logo.png')); ?>" />
      <meta property="og:description" content="<?php echo $seo_data->seo_description; ?>" />
      <meta property="og:url" content="<?php echo e(url()->current()); ?>">

      <meta name="twitter:card" content="<?php echo e(asset('img/rcube-logo.png')); ?>" />
      <meta name="twitter:site" content="MarkNtel" />
      <meta name="twitter:title" content="<?php echo $seo_data->seo_title; ?>" />
      <meta name="twitter:description" content="<?php echo $seo_data->seo_description; ?>" />
      <base href="<?php echo e(url()->current()); ?>">

   <?php } else if ($seo_slug_url_type == "upcoming-reports" && $seo_slug_url == "") {

      $seo_data = \DB::table('seo_content')->where('page_type', 'upcoming_reports')->orderBy('id', 'DESC')->first();
   ?>

      <title><?php echo $seo_data->seo_title; ?></title>
      <meta name="description" content="<?php echo $seo_data->seo_description; ?>" />
      <meta name="keywords" content="<?php echo $seo_data->seo_key_words; ?>">
      <link rel="canonical" href="<?php echo e(url()->current()); ?>" />

      <meta property="og:type" content="news" />
      <meta property="og:title" content="<?php echo $seo_data->seo_title; ?>" />
      <meta property="og:image" content="<?php echo e(asset('img/rcube-logo.png')); ?>" />
      <meta property="og:description" content="<?php echo $seo_data->seo_description; ?>" />
      <meta property="og:url" content="<?php echo e(url()->current()); ?>">

      <meta name="twitter:card" content="<?php echo e(asset('img/rcube-logo.png')); ?>" />
      <meta name="twitter:site" content="MarkNtel" />
      <meta name="twitter:title" content="<?php echo $seo_data->seo_title; ?>" />
      <meta name="twitter:description" content="<?php echo $seo_data->seo_description; ?>" />
      <base href="<?php echo e(url()->current()); ?>">

      <script type="application/ld+json">
         {
            "@context": "https://schema.org",
            "@type": "BreadcrumbList",
            "itemListElement": [

               {
                  "@type": "ListItem",
                  "position": 1,
                  "item": {
                     "@type": "webpage",
                     "@id": "<?php echo e(url('/')); ?>",
                     "name": "Home"
                  }
               },

               {
                  "@type": "ListItem",
                  "position": 2,
                  "item": {
                     "@type": "webpage",
                     "@id": "<?php echo e(url('/upcoming-reports')); ?>",
                     "name": "Upcoming Reports"
                  }
               }

            ]
         }
      </script>

      <?php } else if ($seo_slug_url_type == "report-store" && $seo_slug_url != "") {


      $report_slug_check = \DB::table('reports')->where('page_url', $seo_slug_url)->count();
      $report_slug_category_check = \DB::table('category')->where('category_url', $seo_slug_url)->count();
      $report_slug_subcategory_check = \DB::table('sub_category')->where('page_url', $seo_slug_url)->count();

      if ($report_slug_check > 0) {
         $parent_id = \DB::table('reports')->where('page_url', $seo_slug_url)->first();
         $seo_data = \DB::table('seo_content')->where('parent_id', $parent_id->id)->where('page_type', 'report')->orderBy('id', 'DESC')->first();
      ?>
         <script type="application/ld+json">
            {
               "@context": "https://schema.org/",
               "@type": "Dataset",
               "name": "<?php echo e(@$parent_id->title); ?>",

               "description": ["<?php echo @$seo_data->seo_description; ?>"],
               "url": "https://www.marknteladvisors.com/report-store/<?php echo e(@$parent_id->page_url); ?>",
               "sameAs": "https://www.marknteladvisors.com/report-store/<?php echo e(@$parent_id->page_url); ?>",
               "license": "https://www.marknteladvisors.com/privacy-policy",
               "keywords": ["<?php echo @$seo_data->seo_key_words; ?>"],
               "temporalCoverage": "2024-30",
               "spatialCoverage": "Global",
               "creator": {
                  "@type": "Organization",
                  "url": "https://thereportcube.com/",
                  "name": "Reporter Cube",
                  "logo": {
                     "@type": "ImageObject",
                     "url": "<?php echo e(asset('img/rcube-logo.png')); ?>"
                  }
               }
            }
         </script>
      <?php
      } else if ($report_slug_category_check > 0) {
         $parent_id = \DB::table('category')->where('category_url', $seo_slug_url)->first();
         $seo_data = \DB::table('seo_content')->where('parent_id', $parent_id->id)->where('page_type', 'category')->orderBy('id', 'DESC')->first();
      } else if ($report_slug_subcategory_check > 0) {
         $parent_id = \DB::table('sub_category')->where('page_url', $seo_slug_url)->first();
         $seo_data = \DB::table('seo_content')->where('parent_id', $parent_id->id)->where('page_type', 'sub_ctegory')->orderBy('id', 'DESC')->first();
      }

      ?>

      <title><?php echo @$seo_data->seo_title; ?></title>
      <meta name="description" content="<?php echo @$seo_data->seo_description; ?>" />
      <meta name="keywords" content="<?php echo @$seo_data->seo_key_words; ?>">
      <link rel="canonical" href="<?php echo e(url()->current()); ?>" />

      <meta property="og:type" content="news" />
      <meta property="og:title" content="<?php echo @$seo_data->seo_title; ?>" />
      <meta property="og:image" content="<?php echo e(asset('img/rcube-logo.png')); ?>" />
      <meta property="og:description" content="<?php echo @$seo_data->seo_description; ?>" />
      <meta property="og:url" content="<?php echo e(url()->current()); ?>">

      <meta name="twitter:card" content="<?php echo e(asset('img/rcube-logo.png')); ?>" />
      <meta name="twitter:site" content="Report Cube " />
      <meta name="twitter:title" content="<?php echo @$seo_data->seo_title; ?>" />
      <meta name="twitter:description" content="<?php echo @$seo_data->seo_description; ?>" />
      <base href="<?php echo e(url()->current()); ?>">


      <script type="application/ld+json">
         {
            "@context": "https://schema.org",
            "@type": "BreadcrumbList",
            "itemListElement": [

               {
                  "@type": "ListItem",
                  "position": 1,
                  "item": {
                     "@type": "webpage",
                     "@id": "<?php echo e(url('/')); ?>",
                     "name": "Home"
                  }
               },

               {
                  "@type": "ListItem",
                  "position": 2,
                  "item": {
                     "@type": "webpage",
                     "@id": "<?php echo e(url('/report-store')); ?>",
                     "name": "Report Store'"
                  }
               },

               {
                  "@type": "ListItem",
                  "position": 3,
                  "item": {
                     "@type": "webpage",
                     "@id": "<?php echo e(url('/report-store')); ?>/<?php echo e($seo_slug_url); ?>",
                     "name": "<?php echo e(@$seo_data->seo_title); ?>"
                  }
               }

            ]
         }
      </script>




      <?php if ($report_slug_check > 0) {

         $datas = \DB::table('reports')->where('page_url', $seo_slug_url)->first();
         $faqs = json_decode($datas->faqs);
         $size = count((array)$faqs->ques);
         $m = 1;
         if ($size > 0) {
      ?>

            <script type="application/ld+json">
               {
                  "@context": "https://schema.org",
                  "@type": "FAQPage",
                  "mainEntity": [
                     <?php
                     for ($i = 0; $i < $size; $i++) {
                        if ($faqs->ques[$i] != "") {
                     ?> {
                              "@type": "Question",
                              "name": "Q. <?php echo e($faqs->ques[$i]); ?>",
                              "acceptedAnswer": {
                                 "@type": "Answer",
                                 "text": "A. <?php echo e($faqs->ans[$i]); ?>"
                              }
                           }
                           <?php if ($i < $size - 1) {
                              echo ",";
                           } ?>
                     <?php }
                     } ?>

                  ]
               }
            </script>
      <?php }
      } ?>

      <?php
      if (strpos(@$parent_id->title, 'Global') !== false  && @$parent_id->report_post_date > '2020-12-31') {

         $newprice = "";
         if ($parent_id->single_licence_price) {
            $newprice = str_replace(',', '', $parent_id->single_licence_price);
         }

      ?>
         <script type="application/ld+json">
            {
               "@context": "https://schema.org/",
               "@type": "Product",
               "name": "<?php echo e(@$parent_id->title); ?>",
               "image": [
                  "<?php echo e(asset('img/rcube-logo.png')); ?>"
               ],
               "description": "<?php echo e(@$parent_id->schema_desc); ?>",
               "sku": "<?php echo e(@$parent_id->report_code); ?>",
               "mpn": "<?php echo e(@$parent_id->report_code); ?>",
               "brand": {
                  "@type": "brand",
                  "name": "Reporter Cube"
               },
               "review": {
                  "@type": "Review",
                  "reviewRating": {
                     "@type": "Rating",
                     "ratingValue": "<?php echo e(@$parent_id->rating_value); ?>",
                     "bestRating": "5"
                  },
                  "author": {
                     "@type": "Organization",
                     "name": "Reporter Cube"
                  }
               },
               "aggregateRating": {
                  "@type": "AggregateRating",
                  "ratingValue": "<?php echo e(@$parent_id->rating_value); ?>",
                  "reviewCount": "<?php echo e(@$parent_id->reviewcount); ?>"
               },
               "offers": {
                  "@type": "Offer",
                  "url": "<?php echo e(url('/report-store')); ?>/<?php echo e($seo_slug_url); ?>",
                  "priceCurrency": "USD",
                  "price": "<?php echo e(@$newprice); ?>",
                  "priceValidUntil": "2024/01/31",
                  "itemCondition": "https://schema.org/NewCondition",
                  "availability": "https://schema.org/InStock",
                  "seller": {
                     "@type": "Organization",
                     "name": "Reporter Cube"
                  }
               }
            }
         </script>

      <?php }
   } else if ($seo_slug_url_type == "report-store" && $seo_slug_url == "") {
      $seo_data = \DB::table('seo_content')->where('page_type', 'report-store')->orderBy('id', 'DESC')->first();
      ?>

      <title><?php echo $seo_data->seo_title; ?></title>
      <meta name="description" content="<?php echo $seo_data->seo_description; ?>" />
      <meta name="keywords" content="<?php echo $seo_data->seo_key_words; ?>">
      <link rel="canonical" href="<?php echo e(url()->current()); ?>" />

      <meta property="og:type" content="news" />
      <meta property="og:title" content="<?php echo $seo_data->seo_title; ?>" />
      <meta property="og:image" content="<?php echo e(asset('img/rcube-logo.png')); ?>" />
      <meta property="og:description" content="<?php echo $seo_data->seo_description; ?>" />
      <meta property="og:url" content="<?php echo e(url()->current()); ?>">

      <meta name="twitter:card" content="<?php echo e(asset('img/rcube-logo.png')); ?>" />
      <meta name="twitter:site" content="Report cube" />
      <meta name="twitter:title" content="<?php echo $seo_data->seo_title; ?>" />
      <meta name="twitter:description" content="<?php echo $seo_data->seo_description; ?>" />
      <base href="<?php echo e(url()->current()); ?>">

      <script type="application/ld+json">
         {
            "@context": "https://schema.org",
            "@type": "BreadcrumbList",
            "itemListElement": [

               {
                  "@type": "ListItem",
                  "position": 1,
                  "item": {
                     "@type": "webpage",
                     "@id": "<?php echo e(url('/')); ?>",
                     "name": "Home"
                  }
               },

               {
                  "@type": "ListItem",
                  "position": 2,
                  "item": {
                     "@type": "webpage",
                     "@id": "<?php echo e(url('/report-store')); ?>",
                     "name": "Report Store'"
                  }
               }
            ]
         }
      </script>

   <?php } else if ($seo_slug_url_type == "query" && $seo_slug_url == "request-sample") {

      $seo_page_url_request = request()->segment(3);
      $parent_id = \DB::table('reports')->where('page_url', $seo_page_url_request)->first();
      $seo_data = \DB::table('seo_content')->where('parent_id', $parent_id->id)->where('page_type', 'report')->orderBy('id', 'DESC')->first();

   ?>

      <title><?php echo $seo_data->seo_title; ?></title>
      <meta name="description" content="<?php echo $seo_data->seo_description; ?>" />
      <meta name="keywords" content="<?php echo $seo_data->seo_key_words; ?>">
      <link rel="canonical" href="<?php echo e(url()->current()); ?>" />

      <meta property="og:type" content="news" />
      <meta property="og:title" content="<?php echo $seo_data->seo_title; ?>" />
      <meta property="og:image" content="<?php echo e(asset('img/rcube-logo.png')); ?>" />
      <meta property="og:description" content="<?php echo $seo_data->seo_description; ?>" />
      <meta property="og:url" content="<?php echo e(url()->current()); ?>">

      <meta name="twitter:card" content="<?php echo e(asset('img/rcube-logo.png')); ?>" />
      <meta name="twitter:site" content=" Report cube " />
      <meta name="twitter:title" content="<?php echo $seo_data->seo_title; ?>" />
      <meta name="twitter:description" content="<?php echo $seo_data->seo_description; ?>" />
      <base href="<?php echo e(url()->current()); ?>">

      <script type="application/ld+json">
         {
            "@context": "https://schema.org",
            "@type": "BreadcrumbList",
            "itemListElement": [

               {
                  "@type": "ListItem",
                  "position": 1,
                  "item": {
                     "@type": "webpage",
                     "@id": "<?php echo e(url('/')); ?>",
                     "name": "Home"
                  }
               },

               {
                  "@type": "ListItem",
                  "position": 2,
                  "item": {
                     "@type": "webpage",
                     "@id": "<?php echo e(url('/report-store')); ?>",
                     "name": "report-store"
                  }
               }
            ]
         }
      </script>

      <?php } else if ($seo_slug_url_type == "blogs" && $seo_slug_url == "") {

      $seo_data = \DB::table('seo_content')->where('page_type', 'blog')->orderBy('id', 'DESC')->first();
      if (!is_null($seo_data)) {

      ?>

         <title><?php echo $seo_data->seo_title; ?></title>
         <meta name="description" content="<?php echo $seo_data->seo_description; ?>" />
         <meta name="keywords" content="<?php echo $seo_data->seo_key_words; ?>">
         <link rel="canonical" href="<?php echo e(url()->current()); ?>" />

         <meta property="og:type" content="news" />
         <meta property="og:title" content="<?php echo $seo_data->seo_title; ?>" />
         <meta property="og:image" content="<?php echo e(asset('img/rcube-logo.png')); ?>" />
         <meta property="og:description" content="<?php echo $seo_data->seo_description; ?>" />
         <meta property="og:url" content="<?php echo e(url()->current()); ?>">

         <meta name="twitter:card" content="<?php echo e(asset('img/rcube-logo.png')); ?>" />
         <meta name="twitter:site" content="Report cube " />
         <meta name="twitter:title" content="<?php echo $seo_data->seo_title; ?>" />
         <meta name="twitter:description" content="<?php echo $seo_data->seo_description; ?>" />
         <base href="<?php echo e(url()->current()); ?>">


         <script type="application/ld+json">
            {
               "@context": "https://schema.org",
               "@type": "BreadcrumbList",
               "itemListElement": [

                  {
                     "@type": "ListItem",
                     "position": 1,
                     "item": {
                        "@type": "webpage",
                        "@id": "<?php echo e(url('/')); ?>",
                        "name": "Home"
                     }
                  },
                  {
                     "@type": "ListItem",
                     "position": 2,
                     "item": {
                        "@type": "webpage",
                        "@id": "<?php echo e(url('/blogs')); ?>",
                        "name": "Blogs"
                     }
                  }
               ]
            }
         </script>

      <?php }
   } else if ($seo_slug_url_type == "blogs" && $seo_slug_url != "") {

      $seo_data = \DB::table('blog')->where('slug', $seo_slug_url)->orderBy('id', 'DESC')->first();
      if (!is_null($seo_data)) {
      ?>

         <title><?php echo $seo_data->seo_title; ?></title>
         <meta name="description" content="<?php echo $seo_data->seo_description; ?>" />
         <meta name="keywords" content="<?php echo $seo_data->seo_keyword; ?>">
         <link rel="canonical" href="<?php echo e(url()->current()); ?>" />

         <meta property="og:type" content="news" />
         <meta property="og:title" content="<?php echo $seo_data->seo_title; ?>" />
         <meta property="og:image" content="<?php echo e(asset('img/rcube-logo.png')); ?>" />
         <meta property="og:description" content="<?php echo $seo_data->seo_description; ?>" />
         <meta property="og:url" content="<?php echo e(url()->current()); ?>">

         <meta name="twitter:card" content="<?php echo e(asset('img/rcube-logo.png')); ?>" />
         <meta name="twitter:site" content="Report cube" />
         <meta name="twitter:title" content="<?php echo $seo_data->seo_title; ?>" />
         <meta name="twitter:description" content="<?php echo $seo_data->seo_description; ?>" />
         <base href="<?php echo e(url()->current()); ?>">


         <script type="application/ld+json">
            {
               "@context": "https://schema.org",
               "@type": "BreadcrumbList",
               "itemListElement": [

                  {
                     "@type": "ListItem",
                     "position": 1,
                     "item": {
                        "@type": "webpage",
                        "@id": "<?php echo e(url('/')); ?>",
                        "name": "Home"
                     }
                  },
                  {
                     "@type": "ListItem",
                     "position": 2,
                     "item": {
                        "@type": "webpage",
                        "@id": "<?php echo e(url('/blogs')); ?>",
                        "name": "Blogs"
                     }
                  },
                  {
                     "@type": "ListItem",
                     "position": 3,
                     "item": {
                        "@type": "webpage",
                        "@id": "<?php echo e(url('/blogs/')); ?>/<?php echo e($seo_data->slug); ?>",
                        "name": "<?php echo $seo_data->seo_title; ?>"
                     }
                  }
               ]
            }
         </script>

      <?php }
   } else if ($seo_slug_url_type == "privacy-policy" && $seo_slug_url == "") {

      $seo_data = \DB::table('seo_content')->where('page_type', 'privacy_policy')->orderBy('id', 'DESC')->first();

      ?>

      <title><?php echo $seo_data->seo_title; ?></title>
      <meta name="description" content="<?php echo $seo_data->seo_description; ?>" />
      <meta name="keywords" content="<?php echo $seo_data->seo_key_words; ?>">
      <link rel="canonical" href="<?php echo e(url()->current()); ?>" />

      <meta property="og:type" content="news" />
      <meta property="og:title" content="<?php echo $seo_data->seo_title; ?>" />
      <meta property="og:image" content="<?php echo e(asset('img/rcube-logo.png')); ?>" />
      <meta property="og:description" content="<?php echo $seo_data->seo_description; ?>" />
      <meta property="og:url" content="<?php echo e(url()->current()); ?>">

      <meta name="twitter:card" content="<?php echo e(asset('img/rcube-logo.png')); ?>" />
      <meta name="twitter:site" content="Report Cube" />
      <meta name="twitter:title" content="<?php echo $seo_data->seo_title; ?>" />
      <meta name="twitter:description" content="<?php echo $seo_data->seo_description; ?>" />
      <base href="<?php echo e(url()->current()); ?>">


      <script type="application/ld+json">
         {
            "@context": "https://schema.org",
            "@type": "BreadcrumbList",
            "itemListElement": [

               {
                  "@type": "ListItem",
                  "position": 1,
                  "item": {
                     "@type": "webpage",
                     "@id": "<?php echo e(url('/')); ?>",
                     "name": "Home"
                  }
               },
               {
                  "@type": "ListItem",
                  "position": 2,
                  "item": {
                     "@type": "webpage",
                     "@id": "<?php echo e(url('/privacy-policy')); ?>",
                     "name": "Privacy Policy"
                  }
               }
            ]
         }
      </script>

   <?php } else if ($seo_slug_url_type == "terms-conditions" && $seo_slug_url == "") {

      $seo_data = \DB::table('seo_content')->where('page_type', 'terms_condition')->orderBy('id', 'DESC')->first();

   ?>

      <title><?php echo $seo_data->seo_title; ?></title>
      <meta name="description" content="<?php echo $seo_data->seo_description; ?>" />
      <meta name="keywords" content="<?php echo $seo_data->seo_key_words; ?>">
      <link rel="canonical" href="<?php echo e(url()->current()); ?>" />

      <meta property="og:type" content="news" />
      <meta property="og:title" content="<?php echo $seo_data->seo_title; ?>" />
      <meta property="og:image" content="<?php echo e(asset('img/rcube-logo.png')); ?>" />
      <meta property="og:description" content="<?php echo $seo_data->seo_description; ?>" />
      <meta property="og:url" content="<?php echo e(url()->current()); ?>">

      <meta name="twitter:card" content="<?php echo e(asset('img/rcube-logo.png')); ?>" />
      <meta name="twitter:site" content="Report cube" />
      <meta name="twitter:title" content="<?php echo $seo_data->seo_title; ?>" />
      <meta name="twitter:description" content="<?php echo $seo_data->seo_description; ?>" />
      <base href="<?php echo e(url()->current()); ?>">


      <script type="application/ld+json">
         {
            "@context": "https://schema.org",
            "@type": "BreadcrumbList",
            "itemListElement": [

               {
                  "@type": "ListItem",
                  "position": 1,
                  "item": {
                     "@type": "webpage",
                     "@id": "<?php echo e(url('/')); ?>",
                     "name": "Home"
                  }
               },
               {
                  "@type": "ListItem",
                  "position": 2,
                  "item": {
                     "@type": "webpage",
                     "@id": "<?php echo e(url('/terms-condition')); ?>",
                     "name": "Terms Condition"
                  }
               }
            ]
         }
      </script>

   <?php  } else if ($seo_slug_url_type == "services" && $seo_slug_url == "") {

      $seo_data = \DB::table('seo_content')->where('page_type', 'services')->orderBy('id', 'DESC')->first();

   ?>

      <title><?php echo $seo_data->seo_title; ?></title>
      <meta name="description" content="<?php echo $seo_data->seo_description; ?>" />
      <meta name="keywords" content="<?php echo $seo_data->seo_key_words; ?>">
      <link rel="canonical" href="<?php echo e(url()->current()); ?>" />

      <meta property="og:type" content="news" />
      <meta property="og:title" content="<?php echo $seo_data->seo_title; ?>" />
      <meta property="og:image" content="<?php echo e(asset('img/rcube-logo.png')); ?>" />
      <meta property="og:description" content="<?php echo $seo_data->seo_description; ?>" />
      <meta property="og:url" content="<?php echo e(url()->current()); ?>">

      <meta name="twitter:card" content="<?php echo e(asset('img/rcube-logo.png')); ?>" />
      <meta name="twitter:site" content="Report cube" />
      <meta name="twitter:title" content="<?php echo $seo_data->seo_title; ?>" />
      <meta name="twitter:description" content="<?php echo $seo_data->seo_description; ?>" />
      <base href="<?php echo e(url()->current()); ?>">


      <script type="application/ld+json">
         {
            "@context": "https://schema.org",
            "@type": "BreadcrumbList",
            "itemListElement": [

               {
                  "@type": "ListItem",
                  "position": 1,
                  "item": {
                     "@type": "webpage",
                     "@id": "<?php echo e(url('/')); ?>",
                     "name": "Home"
                  }
               },
               {
                  "@type": "ListItem",
                  "position": 2,
                  "item": {
                     "@type": "webpage",
                     "@id": "<?php echo e(url('/services')); ?>",
                     "name": "Services"
                  }
               }
            ]
         }
      </script>

   <?php } ?>
  
   <link href="https://fonts.googleapis.com/css2?family=Roboto:ital,wght@0,100;0,300;0,400;0,500;0,700;0,900;1,100;1,300;1,400;1,500;1,700;1,900&display=swap" rel="stylesheet">
   <link rel="stylesheet" media="all" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css" />
   <link rel="icon" href="<?php echo e(asset('img/favicon_new.ico')); ?>" />
   <!-- <link rel="stylesheet" media="all" href="<?php echo e(asset('css/bootstrap.min.css')); ?>"> -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-rbsA2VBKQhggwzxH7pPCaAqO46MgnOM80zW1RWuH61DGLwZJEdK2Kadq2F9CUG65" crossorigin="anonymous">
   <link rel="stylesheet" media="all" href="<?php echo e(asset('css/style.css')); ?>">
   <link rel="stylesheet" media="all" href="<?php echo e(asset('css/customstyle.css')); ?>">
   <link rel="stylesheet" media="all" href="<?php echo e(asset('css/ab-style.css')); ?>">
   <style type="text/css">
      
      
    .cookie-banner {
        position: fixed;
        bottom: 0;
        left: 0;
        width: 100%;
        background-color: #f1f1f1;
        padding: 10px;
        text-align: center;
    }


   </style>
   <style>
    
   </style>
</head>

<body>
   <?php
   $allcategory = \DB::table('category')->orderBy('cat_name', 'ASC')->get();

   ?>
   <!-- top bar section -->
   <section class="navbar-area ">
      <div class="login-sign-in">
         <div id="top-nav-container">
            <span class="top-nav-shape"></span>
            <div class="center clearfix">
               <ul class="text-right right">
                  <li class="hide-phonemin">
                     <a href="mailto:sales@thereportcube.com">
                        <i class="fa fa-envelope" aria-hidden="true"></i> sales@thereportcube.com
                     </a>
                  </li>

                  <?php if(Auth::check()): ?>
                  <li class="hide-phonemin" style="cursor:pointer">
                     <a href="#">Welcome, <?php echo e(auth()->user()->first_name); ?> <?php echo e(auth()->user()->last_name); ?> </a><!-- Display user's name -->
                  </li>
                  <!--  <li class="hide-phonemin" style="cursor:pointer">
                    <a href="<?php echo e(url('logout')); ?>">Logout</a>  Logout link -->
                  </li>
                  <?php else: ?>
                  <li class="hide-phonemin" style="cursor:pointer">
                     <a href="<?php echo e(url('signin')); ?>">Sign-in/Register</a> <!-- Sign-in/Register link -->
                  </li>
                  <?php endif; ?>
                  <li class="hide-phonemin">
                        <div id="google_translate_element" style="color:#0000"></div>
                     </li>
                  <li class="hide-phonemin">
                     <div class="gtranslate_wrapper"></div>
                  </li>
               </ul>
            </div>
         </div>





         <div class="logo-search-icons">
            <div class="container">
               <div class="row align-items-center ">
                  <div class="col-md-2  hide-on-mobile">
                     <a class="navbar-brand d-inline-block hide-on-mobile" href="<?php echo e(url('/')); ?>" rel="noopener noreferrer" aria-label="logo">
                        <img src="<?php echo e(asset('img/rcube-logo.png')); ?>" class="img-fluid lazy" alt="Reporter Cube- Market Research Company" width="160" height="50" style="margin-top: -70px !important;" /></a>
                  </div>

                  <div class="col-md-10">
                     <nav class="navbar navbar-expand-lg navbar-light white-bg pt-2 pb-1 ">
                        <div class="container">
                           <a class="navbar-brand hide-on-desktop" href="<?php echo e(url('/')); ?>" rel="noopener noreferrer" aria-label="logo">
                              <img src="<?php echo e(asset('img/rcube-logo.png')); ?>" class="img-fluid lazy" alt="The Report Cube- Market Research Company" width="160" height="50" /></a>
                              <div class=" align-self-end molile-view d-none">
                                    <li class="nav-item list-unstyled d-inline-block ps-2 fs-13 black"
                                       data-bs-toggle="modal" data-bs-target="#exampleModals" style="cursor:pointer">
                                       <span class="nav-link "><i class="fa fa-search"></i></span>
                                    </li>
                                    <li class="nav-link list-unstyled d-inline-block ps-3  blue cart_counter"><a class=""
                                          href="https://www.thereportcube.com/shopping-basket" rel="noopener noreferrer"
                                          aria-label="cart"><i class="fs-20 fa fa-shopping-cart"
                                             style="color:black"></i></a>
                                    </li>
                                 </div>
                           <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNavDropdown" aria-controls="navbarNavDropdown" aria-expanded="false" aria-label="Toggle navigation">
                              <span class="navbar-toggler-icon"></span>
                           </button>
                           <div class="collapse navbar-collapse justify-content-end" id="navbarNavDropdown">
                              <ul class="navbar-nav">
                                 <li class="nav-item dropdown">
                                    <a class="nav-link dropdown-toggle  " rel="noopener noreferrer" href="javascript:void()" id="navbarDropdown" role="button" aria-expanded="false" aria-label="Research Report">
                                       What We Do
                                    </a>
                                    <ul class="dropdown-content" aria-labelledby="navbarDropdown">
                                       <li><a class="dropdown-item" href="<?php echo e(url('syndicated-research')); ?>" rel="noopener noreferrer" aria-label="Cart Name">Syndicated Research</a>
                                       </li>
                                       <li><a class="dropdown-item" href="<?php echo e(url('customized-research')); ?>" rel="noopener noreferrer" aria-label="Cart Name">Customized Research</a></li>
                                       <li><a class="dropdown-item" href="<?php echo e(url('competitive-analysis')); ?>" rel="noopener noreferrer" aria-label="Cart Name">Competitive Analysis</a></li>
                                       <li><a class="dropdown-item" href="<?php echo e(url('company-profile')); ?>" rel="noopener noreferrer" aria-label="Cart Name">Company Profile</a></li>
                                       <li><a class="dropdown-item" href="<?php echo e(url('biographies')); ?>" rel="noopener noreferrer" aria-label="Cart Name">Biographies</a></li>

                                    </ul>
                                 </li>

                                 <li class="nav-item">
                                    <a class="nav-link " aria-current="page" href="<?php echo e(url('about-us')); ?>" rel="noopener noreferrer" aria-label="Upcoming">About-Us</a>
                                 </li>
                               
                                 <li class="nav-item dropdown">
                                    <a class="nav-link dropdown-toggle" rel="noopener noreferrer" href="<?php echo e(url('report-store')); ?>" id="navbarDropdown2" role="button" aria-expanded="false" aria-label="Research Report">
                                       Report Store
                                    </a>
                                    <ul class="dropdown-content" aria-labelledby="navbarDropdown2" style="width:241px;">
                                       <?php $__currentLoopData = $allcategory; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                       <li class="nav-item dropdown">
                                          <a class="dropdown-item dropdown-toggle" href="<?php echo e(url('report-store')); ?>/<?php echo e($cat->category_url); ?>" id="categoryDropdown<?php echo e($cat->id); ?>" role="button" aria-expanded="false" aria-label="<?php echo e($cat->cat_name); ?>">
                                             <?php echo e($cat->cat_name); ?>

                                          </a>
                                          <?php
                                          $allsub_category = \DB::table('sub_category')->where('cat_id', $cat->id)->get();
                                          ?>

                                          <?php if(count($allsub_category) > 0): ?>
                                          <ul class="dropdown-content sub-dropdown " aria-labelledby="categoryDropdown<?php echo e($cat->id); ?>" style="width:200px;">
                                             <?php $__currentLoopData = $allsub_category; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sub_cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                             <li>
                                                <a class="dropdown-item" href="<?php echo e(url('report-store')); ?>/<?php echo e($sub_cat->page_url); ?>" style="padding:6px 14px;" rel="noopener noreferrer" aria-label="<?php echo e($sub_cat->sub_cat_name); ?>">
                                                   <?php echo e($sub_cat->sub_cat_name); ?>

                                                </a>
                                             </li>
                                             <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                          </ul>
                                          <?php endif; ?>
                                       </li>
                                       <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </ul>
                                 </li>
                                 <li class="nav-item">
                                    <a class="nav-link " href="<?php echo e(url('press-release')); ?>" rel="noopener noreferrer" aria-label="Infographics">Press-Release</a>
                                 </li>
                                 <li class="nav-item">
                                    <a class="nav-link " href="<?php echo e(url('contact-us')); ?>">Contact Us</a>
                                 </li>
                                 <li class="nav-item list-unstyled d-inline-block ps-2 fs-13 black" data-bs-toggle="modal" data-bs-target="#exampleModals" style="cursor:pointer">
                                    <span class="nav-link "><i class="fa fa-search"></i></span>
                                 </li>
                                 <div class="mobile-v d-block">
                                 <li class="nav-link list-unstyled d-inline-block ps-3  blue cart_counter"><a class="" href="<?php echo e(url('shopping-basket')); ?>" rel="noopener noreferrer" aria-label="cart"><i class="fs-20 fa fa-shopping-cart" style="color:black"></i></a>
                                    <?php if(count((array) session('cart')) > 0 ): ?>

                                    <div class="cart_count" data-toggle="dropdown" id="navbarDropdown" role="button" data-bs-toggle="dropdown"><?php echo e(count((array) session('cart'))); ?></div>
                                    <div class="dropdown-menu" style="width:220px;">
                                       <?php if(session('cart')): ?>
                                       <?php $__currentLoopData = session('cart'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $id => $details): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                       <div class="row cart-detail" style="width:210px; padding:0 5px;">
                                          <div class="col-lg-2 col-sm-2 col-2 cart-detail-img">
                                             <img src="<?php echo e(url('public/img/1.png')); ?>" data-src="<?php echo e(url('public/img/market_research_consulting.webp')); ?>" width="30" height="30" class="lazy" />
                                          </div>
                                          <div class="col-lg-10 col-sm-10 col-10 cart-detail-product">
                                             <p style="font-size:11px;"><?php echo e($details['name']); ?> <br>
                                                <span class="price text-primary fw-600" style="font-size:11px;"> USD <?php echo e($details['price']); ?></span> <span class="count fw-600" style="font-size:11px;"> Qty: <?php echo e($details['quantity']); ?></span>
                                             </p>
                                          </div>
                                       </div>
                                       <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                       <?php endif; ?>

                                       <div class="row total-header-section" style="min-width:210px; padding:0 5px;">
                                          <div class="col-lg-6 col-sm-6 col-6">
                                             <!-- <i class="fa fa-shopping-cart" aria-hidden="true"></i> <span class="badge badge-pill badge-danger text-danger"><?php echo e(count((array) session('cart'))); ?></span> -->
                                          </div>
                                          <?php $total = 0 ?>
                                          <?php $__currentLoopData = (array) session('cart'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $id => $details): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                          <?php if(strpos($details['price'], ',') !== false): ?>
                                          <?php
                                          $price = str_replace(',','',$details['price']);
                                          ?>

                                          <?php else: ?>
                                          <?php $price = $details['price']; ?>
                                          <?php endif; ?>

                                          <?php
                                          $price = intval($price);
                                          $total += $price * $details['quantity'];
                                          ?>

                                          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                          <div class="col-lg-12 col-sm-12 col-12 total-section text-right">
                                             <p class="fw-600">Total: <span class="text-primary"><?php echo "USD " . number_format($total) ?></span></p>
                                          </div>
                                       </div>

                                       <div class="row">
                                          <div class="col-lg-12 col-sm-12 col-12 text-center checkout">
                                             <a href="<?php echo e(url('shopping-basket')); ?>" class="btn btn-warning btn-sm" rel="noopener noreferrer" aria-label="View" View>View</a>
                                          </div>
                                       </div>
                                    </div>
                                    <?php endif; ?>
                                 </li>
                              </div>
                              </ul>


                           </div>
                        </div>
                     </nav>
                  </div>


               </div>
            </div>
         </div>

    <div class="modal fade" id="exampleModals" tabindex="-1" aria-labelledby="exampleModalsLabel" aria-hidden="true">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>" />
        <div class="modal-dialog">
            <div class="modal-content">
               <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalsLabel">Search</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                  <form action="<?php echo e(url('search/search-result')); ?>" method="get" class="search" id="mainsearch">
                     <?php echo csrf_field(); ?>

                     <div id="errors-list"></div>

                     <div class="col-md-12 mb-3">
                        <p class="mb-0">Search</p>
                        <input type="text" name="search_form" id="navsearch"  class="form-control"placeholder="Search market reports "  required autofocus >
                         
                           <input type="hidden" name="ac" class="autocomplete" disabled="" value="">   


                     <div class="col-md-12 mt-2">
                        <button type="submit" name="login_btn" class="ab-button ab-button-primary ab-button-small">Search</button>
                        <div id="search_result_data2" class="search_result_data2" style="display:none"></div>
                     </div>

                  </form>
                </div>
               
            </div>
        </div>
    </div>
   </section>
   <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
   <script>

      $(document).ready(function(){
    $('#navsearch').on('keyup', function() {
        let value = $(this).val();
        if (value === "") {
            $("#search_result_data2").css("display", "none");
        } else {
            $.ajax({
                type: 'post',
                headers: {
                    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                },
                url: base_url + 'report_search',
                data: {'search': value, _token: $('meta[name="csrf-token"]').attr('content')},
                success: function(data) {
                    if (data !== "") {
                        $("#search_result_data2").css("display", "block");
                        $("#search_result_data2").html(data);
                    } else {
                        $("#search_result_data2").css("display", "none");
                    }
                }
            });
        }
    });
});
</script>
<!-- 
    <script type="text/javascript">
        function googleTranslateElementInit() {
            new google.translate.TranslateElement({
                pageLanguage: 'en',
                layout: google.translate.TranslateElement.InlineLayout.SIMPLE
            }, 'google_translate_element');
        }
    </script>

    <script type="text/javascript" src="https://translate.google.com/translate_a/element.js?cb=googleTranslateElementInit"></script> -->
   <?php echo $__env->yieldContent('content'); ?>
   
<?php echo $__env->make('layout/footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /mnt/home2/vvsajqnq/public_html/thereportcubes.com/resources/views/layout/header_new.blade.php ENDPATH**/ ?>
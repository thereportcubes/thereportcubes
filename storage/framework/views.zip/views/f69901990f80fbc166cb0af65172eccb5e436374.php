
<?php $__env->startSection('title','Upcoming Report'); ?>
<?php $__env->startSection('content'); ?>

<link rel="stylesheet" href="https://cdn.tutorialjinni.com/intl-tel-input/17.0.8/css/intlTelInput.css"/>
 
<section class="mini-banner">
   <div class="container">
      <div class="row">
         <div class="col-md-12">
            <h1 class="mb-0 mini-banner-title">Infographics</h1>
         </div>
      </div>
   </div>
</section>
<?php
$res = "";
    // if($infographic->img_alt_tag != ''){
    //     $res = $infographic->img_alt_tag;
    // }
    // else{
    if(isset($report->title)){
        $exp_arr = explode('Market', @$report->title);
        $res = $exp_arr[0]."Market";
    }
        
   // }

?>

<section class="main-content mb-5 mt-5">
      <div class="container">
         <div class="row">
         
            <div class="col-md-8 sm-100">
                  <div class="product-item-small product-item-mobile  press-item">
                        <span class="date"><i class="fa fa-calendar"></i> <?php echo e(Carbon\Carbon::parse($infographic->created_at)->format('d M Y')); ?> </span>
                        <div class="product-item-content" style=" margin-top: 15px;">
                           <div class="content margin-zero" style="text-align: left;">
                              <h3 class="title"><a href="#" style="color:var(--primary-color);"><?php echo e($infographic->title); ?></a></h3>
                              <img  src="<?php echo e(asset($infographic->image)); ?>"  style="max-width:100%!important" alt="<?php echo e($infographic->img_alt_tag); ?>">
                              <br/><br/>
                              <div class="press-btn-div">
                                 <ul class="press-btn-list">
                                    <li ><a class="press-btn" href="<?php echo e(url('/report-store')); ?>/<?php echo e(@$infographic->slug); ?>">View Report</a></li>
                                   
                                 </ul>
                              </div>
                           </div>
                        </div>
                     </div>

            </div>
            <div class="col-md-4">

   <div class="shadow p-0">

            <?php if(session()->has('success')): ?>
              <div class="alert-success" style="padding:18px;border-radius: 5px;">
                <strong>Success!</strong> <?php echo e(session()->get('success')); ?>

              </div>
            <br>
            <?php endif; ?>
            <?php if(session()->has('error')): ?>
              <div class="alert-danger" style="padding:18px;border-radius: 5px;">
                <strong>Warning!</strong> <?php echo e(session()->get('error')); ?>

              </div>
              <br>
            <?php endif; ?>
            <h4 class="fw-600 red-title-bg text-center" style="back-ground-color:red;">Request Sample</h4>

            <div class="p-3">
               <form action="<?php echo e(url('save-infographic-request')); ?>" method="post" >
                  <?php echo csrf_field(); ?>
                  <input type hidden name="request_title" value="<?php echo e(@$infographic->title); ?>" />
                  <!-- <div class="col-sm-12 mb-3">
                     <input type="text" name="full_name" value="<?php echo e(old('full_name')); ?>" class="form-control" placeholder="Enter your Name*" required>
                  </div> -->
                    <div class="row" style="align-items: center;">
                     
                     <div class="col-md-12">
                        <input class="ab-input" type="text" name="full_name" value="<?php echo e(old('full_name')); ?>" placeholder="Enter your Name" required>
                     </div>
                  </div>
               <!--    <div class="col-sm-12 mb-3">
                     <input type="text" name="company_name" value="<?php echo e(old('company_name')); ?>" class="form-control" placeholder="Enter your company name" required>
                  </div> -->
                  <div class="row mt-2" style="align-items: center; ">
                     
                     <div class="col-md-12">
                        <input class="ab-input" type="text" name="company_name" value="<?php echo e(old('company_name')); ?>" placeholder="Enter Company Name" required>
                     </div>
                  </div>
                   <div class="row mt-2" style="align-items: center; ">
                     
                     <div class="col-md-12">
                        <input class="ab-input" type="text" name="busniess_email" value="<?php echo e(old('busniess_email')); ?>" placeholder="Enter your business Email" required>
                     </div>
                  </div>
                   <div class="row mt-2" style="align-items: center; ">
                     
                     <div class="col-md-12">
                        <input class="ab-input" type="text" name="country_name" value="<?php echo e(old('country_name')); ?>" placeholder="Enter your Country" required>
                     </div>
                  </div>
                  <div class="row mt-2" style="align-items: center; ">
                     
                     <div class="col-md-12">
                        <input class="ab-input" type="text" name="contact_number" value="<?php echo e(old('contact_number')); ?>" placeholder="Enter your Phone Number" required>
                     </div>
                  </div>

                 <!--  <div class="col-sm-12 mb-3">
                     <input type="email" name="busniess_email" value="<?php echo e(old('busniess_email')); ?>" class="form-control" placeholder="Enter your business email*" required>
                  </div> -->
               <!--    <div class="col-sm-12 mb-3">
                     <input  name="contact_number" type="text" id="phone_info" class="form-control" value="<?php echo e(old('contact_number')); ?>" required />
                  </div> -->
                  <div class="row mt-2" style="align-items: center; ">
                  
                     <div class="col-md-12">
                        <textarea class="ab-input"  name="message" cols="10" rows="1" placeholder="Type Your Message "></textarea> 
                     </div>
                  </div>
                  <!-- <div class="form-group">
                     <div class="g-recaptcha" data-sitekey="6Ldncs8oAAAAAJZ7C_pvRTzTqa1RwZKNW0jfJ-Y2" data-callback="verifyRecaptchaCallback" data-expired-callback="expiredRecaptchaCallback"></div>
                     <input class="d-none" data-recaptcha="true" data-error="Please complete the Captcha" name="verify_captcha">
                     <div class="help-block with-errors"></div>
                  </div> -->
                  <div class="col-12 mt-1">
                    <!-- <div class="captcha">
                        <button type="button" class="btn btn-info" class="reload" id="reload">
                              &#x21bb;
                        </button>&nbsp;&nbsp;
                        <span><?php echo captcha_img(); ?></span>														  
                     </div>-->
                     <div class="g-recaptcha" data-sitekey="<?php echo e(config('services.recaptcha.key')); ?>"></div>
                  </div>
                  <div class="col-12 mt-2">                     
                    <!-- <input type="text" name="captcha" id="captcha" class="form-control" placeholder="Enter Captcha" required maxlength="5"  />       -->
                    <?php if($errors->has('g-recaptcha-response')): ?>
                                    <span class="help-block">
                                        <strong><?php echo e($errors->first('g-recaptcha-response')); ?></strong>
                                    </span>
                                <?php endif; ?>
                  </div>
                  <!--<?php if($errors->has('captcha')): ?>
                     <span class="text-danger">
                           <strong><?php echo e($errors->first('captcha')); ?></strong>
                     </span>
                  <?php endif; ?> -->
                  <div class="form-group text-center"><button class="btns btn-primary market-btn text-white mt-3" type="submit" >Submit</button></div>

                  <!-- <input type="hidden" name="country_name" id="country-name"  value="United States" /> -->

               </form>

</div>
               
</div>


         </div>
         </div>
      </div>
   </section>

<script src='https://www.google.com/recaptcha/api.js'></script>
<script src="<?php echo e(url('public/js/intlTelInput.min.js')); ?>"></script>
<script>
   var input = document.querySelector("#phone_info");
   input.setAttribute('placeholder', ' ');
   const countryNameElement = document.querySelector("#country-name");
   const iti = window.intlTelInput(input, {
      utilsScript: "https://cdnjs.cloudflare.com/ajax/libs/intl-tel-input/17.0.8/js/utils.js",
      separateDialCode: true,
      initialCountry: "US",
   });
   
 
   function updateCountryName() {
      const selectedCountryData = iti.getSelectedCountryData();
      //const selectedCountryName = selectedCountryData.name;
      const selectedCountryName = selectedCountryData.name.replace(/\s*\([^)]*\)/, '');
      countryNameElement.value = selectedCountryName;
      
   }

   input.addEventListener("countrychange", updateCountryName); 

</script>

<!-- plugins -->
<script src="<?php echo e(url('public/assets/js/vendors.js')); ?>"></script>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>

    <!-- custom app -->
    <script src="<?php echo e(url('public/assets/js/app.js')); ?>"></script>
	
	<script type="text/javascript">
      let base_url_info = <?php echo json_encode(url('/')); ?>;
		$('#reload').click(function () {
			$.ajax({
				type: 'GET',
				url: base_url_info + '/reload-captcha',
				success: function (data) {
					$(".captcha span").html(data.captcha);
				}
			});
		});
	</script>
<script src="https://www.google.com/recaptcha/api.js" async defer></script>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layout/header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u171619165/domains/vishalghosh.com/public_html/stagingrcube/site/resources/views/infographics_details.blade.php ENDPATH**/ ?>

<?php $__env->startSection('title','Upcoming Report'); ?>

<?php $__env->startSection('content'); ?>

<section class="mini-banner">
   <div class="container">
      <div class="row">
         <div class="col-md-12">
            <h1 class="mb-0 mini-banner-title">Press Release Details</h1>
         </div>
      </div>
   </div>
</section>

<section class="main-content mb-5 mt-5">
      <div class="container">
         <div class="row">

            <div class="col-md-9 sm-100">


               <div class="box-shadow">
                  <h6 class="fw-600">Press Release</h6>

                  <div class="box-content p-1">

                     <div class="press-releas-description">
                        <p class="fw-600">Surging Housing Units to Influence the Home Furniture Market in Saudi Arabia
                        </p>

                        <p>The <a
                              href="https://www.marknteladvisors.com/research-library/saudi-arabia-home-furniture-market.html">Saudi
                              Arabia Home Furniture&nbsp;Market</a> is projected to grow at a CAGR of around 7.4% in the
                           forecast period of 2023-28, cites MarkNtel Advisors in the recent research report. The major
                           reason which led to an increase in the sale of home furniture is the surging construction of
                           housing units, the rich lifestyle of the population, and the emergence of eco-friendly &amp;
                           smart cities in the country. The existing problem of housing shortages due to an increase in
                           the expatriate population has led to the rise in the construction of residential buildings,
                           homes, villas, etc., during the historical period.</p>
                     </div>

                  </div>
               </div>

            </div>
            <div class="col-md-3 sm-100">
               <div class="box-shadow">
                  <h6 class="fw-600">Place an order</h6>

                  <div class="d-flex justify-content-between orders fs-14 mb-3">
                     <div class="form-check">
                        <input class="form-check-input" type="checkbox" value="" id="flexCheckDefault">
                        <label class="form-check-label" for="flexCheckDefault">
                           Default checkbox

                        </label>


                        <span class="tooltips"><i class="fa fa-info-circle"></i><span class="tooltipstext">This is a
                              tooltips<span class="caret"></span></span></span>

                     </div>


                     <div>
                        <p>USD 3,700</p>
                     </div>


                  </div>

                  <button type="button" class="btn btn-primary small-btn">Buy Now</button>
               </div>
               <div class="btn-groups">
                  <a href="#" class="btn btn-primary small-btn d-inline-block color-one"><i class="fa fa-hand-pointer"
                        aria-hidden="true"></i>
                     Request
                     Sample</a>

                  <a href="" class="btn btn-primary small-btn d-inline-block color-two"><i class="fa fa-hand-pointer"
                        aria-hidden="true"></i> Talk to our Consultant</a>

                  <a href="#" class="btn btn-primary small-btn d-inline-block color-three"><i class="fa fa-hand-pointer"
                        aria-hidden="true"></i> Request Customization</a>
               </div>
               <div class="box-shadow">
                  <h6 class="fw-600"><i class="fa fa-user fs-14" aria-hidden="true"></i> Need Assistance?</h6>


                  <div class="mb-2">
                     <p class="mb-0 fs-14">
                        <i class="fa fa-envelope me-2 orrange" aria-hidden="true"></i> WRITE AN EMAIL

                     </p>
                     <a href="mailto:sales@marknteladvisors.com">sales@marknteladvisors.com</a>
                  </div>

                  <div>
                     <p class="mb-0 fs-14"><i class="fa fa-phone me-2 orrange" aria-hidden="true"></i>CALL US</p>
                     <a class="fs-14" href="tel:+1 628 895 8081, +91 120 4278433">+1 628 895 8081, +91 120 4278433</a>
                  </div>

               </div>

               <div class="box-shadow">
                  <h6 class="fw-600"><i class="fa fa-lock me-2 fs-14 "></i>100% Safe & Secure</h6>
                  <p class="fs-14">
                     Strongest encryption on the website to make your purchase safe and secure
                  </p>
               </div>

            </div>
         </div>
      </div>
   </section>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layout/header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\markntel_advisor\resources\views/press_release_details.blade.php ENDPATH**/ ?>
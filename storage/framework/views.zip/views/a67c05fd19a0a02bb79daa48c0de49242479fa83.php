
<?php $__env->startSection('title', 'Market Advisor'); ?>
<?php $__env->startSection('content'); ?>
    <section class="pay-option mb-5">
        <div class="container">
            <div class="row">
                <div class="col-md-8 sm-100 mb-25">
                    <div class="wrap-cart">
                        <div class="report-heading">
                            <p class="mb-0 white">User Login / Registeration</p>
                        </div>
                        <div class="row cart-row" style="height:200px;">
                            <div class="col-md-12">
                                Please check your email & verify email. After email verify you can login in the system.
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-md-4 sm-100">
                    <div class="box-shadow p-0">


                        <h6 class="fw-600 blue-title-bg mb-0"><i class="fa fa-user fs-14" aria-hidden="true"></i> Need
                            Assistance?
                        </h6>
                        <div class="p-3">
                            <div class="mb-2">
                                <p class="mb-0 fs-14">
                                    <i class="fa fa-envelope me-2 orrange" aria-hidden="true"></i> WRITE AN EMAIL
                                </p>
                                <a href="mailto:sales@marknteladvisors.com">sales@marknteladvisors.com</a>
                            </div>
                            <div>
                                <p class="mb-0 fs-14"><i class="fa fa-phone me-2 orrange" aria-hidden="true"></i>CALL US
                                </p>
                                <a class="fs-14" href="tel:+1 628 895 8081, +91 120 4278433">+1 628 895 8081, +91 120
                                    4278433</a>
                            </div>

                        </div>
                    </div>
                    <div class="box-shadow p-0">


                        <h6 class="fw-600 blue-title-bg mb-0"><i class="fa fa-lock me-2 fs-14 "></i>100% Safe &amp; Secure
                        </h6>
                        <div class="p-3">
                            <hr>
                            <p class="fs-14">
                                Strongest encryption on the website to make your purchase safe and secure
                            </p>
                            <img src="img/paypal-logo.png" class="img-fluid" alt="">
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout/header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/marknteladvisors/public_html/resources/views/thanks.blade.php ENDPATH**/ ?>
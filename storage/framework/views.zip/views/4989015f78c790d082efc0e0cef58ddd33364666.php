
<?php $__env->startSection('title','All member'); ?>
<?php $__env->startSection('content'); ?>

                <!-- begin app-main -->
                <div class="app-main" id="main">
                    <!-- begin container-fluid -->
                    <div class="container-fluid">
                        <!-- begin row -->
                        <div class="row">
                            <div class="col-md-12 m-b-30">
                                <!-- begin page title -->
                                <div class="d-block d-sm-flex flex-nowrap align-items-center">
                                    <div class="page-title mb-2 mb-sm-0">
                                        <h1>All Members</h1>
                                    </div>
                                    <div class="ml-auto d-flex align-items-center">
                                        <nav>
                                            <ol class="breadcrumb p-0 m-b-0">
                                                <li class="breadcrumb-item">
                                                    <a href="<?php echo e(url('admin/dashboard')); ?>"><i class="ti ti-home"></i></a>
                                                </li>
                                                <li class="breadcrumb-item">
                                                   User
                                                </li>
                                                <li class="breadcrumb-item active text-primary" aria-current="page">All Members</li>
                                            </ol>
                                        </nav>
                                    </div>
                                </div>
                                <!-- end page title -->
                            </div>
                        </div>
                        <!-- end row -->
                        <!-- begin row -->
                        <div class="row">
                            <div class="col-lg-12">
                                <div class="card card-statistics">
                                    <div class="card-body">
                                        <div class="datatable-wrapper table-responsive">
                                            <table id="datatable" class="display compact table table-striped table-bordered">
                                                <thead>
                                                    <tr>
                                                        <th>ID</th>
                                                        <th>Name</th>
                                                        <th>Email</th>
                                                        <th>Mobile</th>
                                                        <th>DOB</th>
                                                        <th>Gender</th>
                                                        <th>Address</th>
                                                        <th>Actions</th>
                                                    </tr>
                                                </thead>
                                                <tbody>
                                                <?php $__currentLoopData = $list; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <tr>    
                                                    <th class="p-1"><?php echo e(++$key); ?></th>
                                                    <th><?php echo e($data->name); ?></th>
                                                    <th><?php echo e($data->email); ?></th>
                                                    <th><?php echo e($data->phone); ?></th>
                                                    <th><?php echo e($data->dob); ?></th>
                                                    <th><?php echo e($data->gender); ?></th>
                                                    <th><?php echo e($data->address); ?></th>
                                                    <th><a class="btn btn-sm btn-primary shadow-none" href="<?php echo e(url('admin/edit-member')); ?>/<?php echo e($data->id); ?>" role="button">Edit</a>
                                                    &nbsp;
                                                    <a class="btn btn-sm btn-info shadow-none" href="<?php echo e(url('admin/emp_update')); ?>/<?php echo e($data->id); ?>" role="button">View</a></th>
                                                    
                                                </tr>
                                                
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    
                                                </tbody>
                                                <tfoot>
                                                    <tr>
                                                        <th>Name</th>
                                                        <th>Position</th>
                                                        <th>Office</th>
                                                        <th>Age</th>
                                                        <th>Start date</th>
                                                        <th>Salary</th>
                                                    </tr>
                                                </tfoot>
                                            </table>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <!-- end row -->
                    </div>
                    <!-- end container-fluid -->
                </div>
                <!-- end app-main -->
    <?php $__env->stopSection(); ?>
<?php echo $__env->make('admin/header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\tyche-app\resources\views/admin/all-member.blade.php ENDPATH**/ ?>
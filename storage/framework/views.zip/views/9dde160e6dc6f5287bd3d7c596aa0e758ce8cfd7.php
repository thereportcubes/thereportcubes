
<?php $__env->startSection('title','Sub Industries'); ?>
<?php $__env->startSection('content'); ?>

                <div class="app-main" id="main">
                    <!-- begin container-fluid -->
                    <div class="container-fluid">
                        <!-- begin row -->
                        <div class="row">
                            <div class="col-md-12 m-b-30">
                                <!-- begin page title -->
                                <div class="d-block d-sm-flex flex-nowrap align-items-center">
                                    <div class="page-title mb-2 mb-sm-0">
                                        <h1>Sub Industries</h1>
                                    </div>
                                    <div class="ml-auto d-flex align-items-center">
                                        <nav>
                                            <ol class="breadcrumb p-0 m-b-0">
                                                <li class="breadcrumb-item">
                                                    <a href="<?php echo e(url('admin/dashboard')); ?>"><i class="ti ti-home"></i></a>
                                                </li>
                                                <li class="breadcrumb-item">
                                                   User
                                                </li>
                                                <li class="breadcrumb-item active text-primary" aria-current="page">Sub Industries</li>
                                            </ol>
                                        </nav>
                                    </div>
                                </div>
                                <!-- end page title -->
                            </div>
                        </div>
                        <!-- end row -->
                        <!-- begin row -->
                        <div class="row">
                            <div class="col-lg-12">
                                <div class="card card-statistics">
                                    <div class="card-body">
                                    
                                        <div class="card-heading">
                                            <div class="row">
                                                <div class="col-md-10">&nbsp;</div>
                                                <div class="col-md-2 text-right"><a href="<?php echo e(route('sub_industries')); ?>"><button type="button" class="btn btn-info text-right">Add New</button></a></div>
                                                </div>
                                                
                                            </div>
                                        </div>
                                   
                                        <div class="datatable-wrapper table-responsive">
                                            <table id="datatable" class="display compact table table-striped table-bordered">
                                                <thead>
                                                    <tr>
                                                        <th width="5%">ID</th>
                                                        <th width="35%">Categories Name</th>
                                                        <th width="35%">Sub Categories Name</th>
                                                        <th width="15%">Action</th>
                                                    </tr>
                                                </thead>
                                                <tbody>
                                                <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <tr>    
                                                    <th class="p-1">&nbsp;<?php echo e(++$key); ?></th>
                                                    <th><?php echo e($data->cat_name); ?></th>
                                                    <th><?php echo e($data->sub_cat_name); ?></th>
                                                    <th><a class="btn btn-sm btn-primary shadow-none" href="<?php echo e(url('admin/edit_sub_industries')); ?>/<?php echo e($data->id); ?>" role="button">Edit</a>
                                                    &nbsp;
                                                    <a class="btn btn-sm btn-danger shadow-none" onClick="delRow(<?php echo e($data->id); ?>)" href="javascript:void()" role="button">Delete</a></th>
                                                    			
                                                </tr>
                                                
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    
                                                </tbody>
                                                
                                            </table>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <!-- end row -->
                    </div>
                    <!-- end container-fluid -->
                </div>
                <!-- end app-main -->
                <script>
   function delRow(val) {
   
     var r=confirm("Are you sure?")
     if (r==true)
     {
        $.ajax({
         url : '<?php echo e(route("admin/delete_sub_industries")); ?>' ,
         type: 'get',
           data: {'rowId':val},
           dataType: "text",
         success: function(response){				  
              alert(response);
              var base_url = <?php echo json_encode(url('/')); ?>

              window.location.href= base_url + '/admin/sub_industries_list';                
           }
        });
   }
   else{         
   }
   
   };
   
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin/header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/marknteladvisors/public_html/resources/views/admin/sub_industries_list.blade.php ENDPATH**/ ?>
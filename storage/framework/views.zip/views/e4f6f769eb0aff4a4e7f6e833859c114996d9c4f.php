
<?php echo $__env->yieldContent('title'); ?>
<?php $__env->startSection('content'); ?>
<main>
   <section id="content-infos-pages">
      <section class="ab-title-section ab-bg-dark-red ab-color-white ab-section">
         <div class="ab-title-section-bg" style="background-image: url(/rcube/assent/images/banner.jpg);">
            <div class="ab-section-divider">
               <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 100 100" preserveAspectRatio="none">
                  <polygon points="0,0 100,0 0,100"></polygon>
               </svg>
            </div>
         </div>
         <div class="ab-wrapper">
            <div class="ab-title-section-text">
               <h1 class="ab-large-title">On Going Reports </h1>
               
            </div>
         </div>
      </section>
      
   </section>
   <section class="on-going-report ab-section mt-5 ">
      <div class="ab-wrapper ab-align-center">
         <div class=" product-list-spacing-mobile">
            <div id="product--related-products" class="ab-product-content-section ab-product-content-related-items">
               <div class="relatedProducts">
                  <style>
                     .report-read-more{color: var(--primary-color);
                     font-weight: 700;
                     font-size: 14px;
                     text-transform: none;}
                  </style>
                  <div class="relatedProductsList">
                  <?php if(count($datas) > 0): ?>
                  <?php $__currentLoopData = $datas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                     <div class="product-item-small product-item-mobile clearfix">
                        <div class="product-item-content">
                           <div class="ab-product-thumbnail-book-binder left">
                              <div class="product-img-box">
                                 <span class="image-report" style="color:#000;top: 7px;left: 3px;font-size: 6px;">Report</span>
                                 <h4 class="image-title" style="color: #fff;top: 20px;font-size: 6px;text-align: left;width: 50px;left: 5px;">
                                 <?php echo e($data->title); ?>

                                 </h4>
                                 <span class="imag-pages" style="color: #fff;font-size: 4px;left: 5px;bottom: 5px;"><?php echo e($data->no_of_page); ?> pages</span>
                                 <span class="book-years" style="color: #fff;font-size: 10px;right: 18px;bottom: 3px;"><?php echo e(Carbon\Carbon::parse($data->created_at)->format('Y')); ?></span>
                              </div>
                              <img loading="lazy" class="nonGenericproductSmallImage" src="<?php echo e(asset('/images/book-cover.jpg')); ?>"  width="60" height="86">
                           </div>
                           <div class="content" style="text-align: left; margin-right: 10px;">
                              <h3 class="title"><a href="<?php echo e(url('/research-library')); ?>/<?php echo e($data->page_url); ?>" style="color:var(--primary-color);"><?php echo e($data->title); ?></a></h3>
                              <p style="margin-bottom: 10px;"><?php echo ($data->heading2 !="") ? preg_replace('/\\s\\S*$/', '', substr($data->heading2, 0, 250))  : ''; ?>
                              </p> <br>
                              <ul class="product-item-list">
                                 <li class="first"> <img  style="margin-right:5px;" alt="PDF Icon" src="<?php echo e(url('public/assets/images/icon-PDF.webp')); ?>" srcset="<?php echo e(asset('/assets/images/icon-PDF.webp')); ?>" width="20"> Report </li>
                                 <li> <?php echo e($data->no_of_page); ?> Pages </li>
                                 <li id="publicationDateItemId_related_products_5807230" class="publicationDateItem"><?php echo e(Carbon\Carbon::parse($data->created_at)->format('M Y')); ?></li>
                                 <li class="last"><a href="<?php echo e(url('/research-library')); ?>/<?php echo e($data->page_url); ?>" class="report-read-more"href="">Read More</a></li>
                              </ul>
                           </div>
                        </div>
                     </div>
                  
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
                  <?php endif; ?>

                     <ul class="pagination clearfix" id="paginationBottom">
                        <li class="page-count"><strong><span><?php echo e(count($datas)); ?></span> Results</strong> (Page 1 of <?php echo e(ceil(count($datas)/10)); ?> ) </li>

                        <li class="pager-btn-container">
                           <?php echo e($datas->links('custom_pagination')); ?>

                        </li>
                     </ul>
                  </div>
               </div>
            </div>
         </div>
      </div>
   </section>
</main>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u171619165/domains/vishalghosh.com/public_html/stagingrcube/site/resources/views/ongoing-reports.blade.php ENDPATH**/ ?>
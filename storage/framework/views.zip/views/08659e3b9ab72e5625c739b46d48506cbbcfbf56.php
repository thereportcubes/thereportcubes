
<?php $__env->startSection('title','R Cube'); ?>
<?php $__env->startSection('content'); ?>
<!-- banner slider start -->


<?php $__currentLoopData = $data_banner; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<!-- style="background-image: url('<?php echo e(asset('/uploads/banner')); ?>/<?php echo e($data->banner_image); ?>'); background-size:cover;" -->
<section class="hero_top-1 mb-5" style="background-image: url('<?php echo e(asset('/uploads/banner')); ?>/<?php echo e($data->banner_image); ?>'); background-size:cover;" >
<!-- <img src="<?php echo e(asset('/uploads/banner')); ?>/<?php echo e($data->banner_image); ?>" height="600"> -->
    <div class="container">
        <div class="content">
            <h1 class="ab-large-title">
               <?php echo e($data->banner_title); ?>

            </h1>
            <div class="full-width-search">
                <form action="<?php echo e(url('search/search-result')); ?>" method="get" class="search" id="mainsearch">
                   <input type="text" placeholder="Search market reports by industry, keyword, or company name" class="search-box" id="search_123" name="search_form" autocomplete="off">
                     <button type="submit" class="search-button"><i class="fa"></i></button>
                       <div id="search_result" class="search_result_data" style="display:none"></div>
                </form>
            </div>
        </div>
    </div>
</section>

 <?php break; ?>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  
<!-- about us section gose here -->
 <section class="ab-reviews-publishers industry-services" style="background-color: #fff !important;">
      <div class="ab-wrapper">
         <h2 class="ab-title ab-align-center">Industries Served</h2>
         <div class="row">
            
            <div class="col-md-3 col-sm-6">
               <div class="ab-reviews-publishers-row-left industry-served" >                  
                  <div class="col-md-6 industry-served-logo">
                     <a href="<?php echo e(url('report-store/healthcare')); ?>" class="ab-reviews-publishers-image-hyperlink-float" target="_blank">
                     <img loading="lazy" width="60" height="27" src="<?php echo e(asset('assets/icons/healthcare.png')); ?>" alt="Forbes Logo"></a>
                     <p class="mt-2">Healthcare</p>
                  </div>
               </div>
            </div>
            <div class="col-md-3  col-sm-6">
               <div class="ab-reviews-publishers-row-left industry-served" >                  
                  <div class="col-md-6 industry-served-logo">
                     <a href="<?php echo e(url('report-store/energy-natural-resources')); ?>" class="ab-reviews-publishers-image-hyperlink-float" target="_blank">
                     <img loading="lazy" width="60" height="27" src="<?php echo e(asset('assets/icons/energy.png')); ?>" alt="Forbes Logo"></a>
                     <p class="mt-2">Energy & Natural Resources</p>
                  </div>
               </div>
            </div>
            <div class="col-md-3 col-sm-6">
               <div class="ab-reviews-publishers-row-left industry-served" >                  
                  <div class="col-md-6 industry-served-logo">
                     <a href="<?php echo e(url('report-store/information-technology')); ?>" class="ab-reviews-publishers-image-hyperlink-float" target="_blank">
                     <img loading="lazy" width="60" height="27" src="<?php echo e(asset('assets/icons/it.png')); ?>" alt="Forbes Logo"></a>
                     <p class="mt-2">Information & Technology</p>
                  </div>
               </div>
            </div>
            <div class="col-md-3 col-sm-6">
               <div class="ab-reviews-publishers-row-left industry-served">                  
                  <div class="col-md-6 industry-served-logo">
                     <a href="<?php echo e(url('report-store/chemicals-materials')); ?>" class="ab-reviews-publishers-image-hyperlink-float" target="_blank">
                     <img loading="lazy" width="60" height="27" src="<?php echo e(asset('assets/icons/chemical.png')); ?>" alt="Forbes Logo"></a>
                     <p class="mt-2">Chemicals and Materials</p>
                  </div>
               </div>
            </div>
            <div class="col-md-3 col-sm-6">
               <div class="ab-reviews-publishers-row-left industry-served" >                  
                  <div class="col-md-6 industry-served-logo">
                     <a href="<?php echo e(url('report-store/food-beverages')); ?>" class="ab-reviews-publishers-image-hyperlink-float" target="_blank">
                     <img loading="lazy" width="60" height="27" src="<?php echo e(asset('assets/icons/food.png')); ?>" alt="Forbes Logo"></a>
                     <p class="mt-2">Food & Beverage</p>
                  </div>
               </div>
            </div>
            <div class="col-md-3 col-sm-6">
               <div class="ab-reviews-publishers-row-left industry-served" >                  
                  <div class="col-md-6 industry-served-logo">
                     <a href="<?php echo e(url('report-store/manufacturing-construction')); ?>" class="ab-reviews-publishers-image-hyperlink-float" target="_blank">
                     <img loading="lazy" width="60" height="27" src="<?php echo e(asset('assets/icons/menufecture.png')); ?>" alt="Forbes Logo"></a>
                     <p class="mt-2">Manufacturing & Construction</p>
                  </div>
               </div>
            </div>
            <div class="col-md-3 col-sm-6">
               <div class="ab-reviews-publishers-row-left industry-served" >                  
                  <div class="col-md-6 industry-served-logo">
                     <a href="<?php echo e(url('report-store/automotive-transport')); ?>" class="ab-reviews-publishers-image-hyperlink-float" target="_blank">
                     <img loading="lazy" width="60" height="27" src="<?php echo e(asset('assets/icons/automotive.png')); ?>" alt="Forbes Logo"></a>
                     <p class="mt-2">Automotive & Transport</p>
                  </div>
               </div>
            </div>
            <div class="col-md-3 col-sm-6">
               <div class="ab-reviews-publishers-row-left industry-served" >                  
                  <div class="col-md-6 industry-served-logo">
                     <a href="<?php echo e(url('report-store/consumer-goods-services')); ?>" class="ab-reviews-publishers-image-hyperlink-float" target="_blank">
                     <img loading="lazy" width="60" height="27" src="<?php echo e(asset('assets/icons/consumer.png')); ?>" alt="Forbes Logo"></a>
                     <p class="mt-2">Consumer Goods & Services</p>
                  </div>
               </div>
            </div>

         </div>
      </div>
   </section>
  <section class="ab-home-products ab-bg-subtle-gray ab-section">
      <div id="productListContainer" class="ab-wrapper">
         <h2 class="ab-title ab-align-center">Recently Viewed and Related Products</h2>
         <ul class="ab-products-grid">
            
            <!-- item -->
            <?php if(count($report_data) > 0 ): ?>
            <?php $__currentLoopData = $report_data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rt): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li>
               <a href="<?php echo e(url('report-store')); ?>/<?php echo e($rt->page_url); ?>" class="ab-products-grid-item">
                  <div class="ab-products-grid-item-image ab-product-thumbnail ab-product-thumbnail-3d">
                     <div class="ab-product-thumbnail-3d-book ab-product-thumbnail-3d-book-reverse">
                        <img class="ab-product-thumbnail-image-front" src="<?php echo e(asset('img/reportimg.jpg')); ?>" style="width:115px;height:165px;" title="Global RegTech Market Research Report: Forecast (2023-2028) " alt="Report">
                        <div class="product-img-box">
                           <span class="image-report" style="color:#fff">Report</span>
                           <h4 class="image-title" style="color: #000;"><?php echo substr(html_entity_decode(strip_tags($rt->title)),0,40); ?></h4>
                           <span class="imag-pages" style="color: #000;font-weight:bold;"><?php echo e($rt->no_of_page); ?> Pages</span>
                           <span class="book-years" style="color: #000;font-size:10px;" ><?php echo e(Carbon\Carbon::parse($rt->report_post_date)->format('M Y')); ?></span>
                        </div>
                        <div class="ab-product-thumbnail-image-inside"></div>
                        <img class="ab-product-thumbnail-image-back" src="<?php echo e(asset('img/reportimg.jpg')); ?>" style="width:115px;height:165px;" alt="<?php echo substr(html_entity_decode(strip_tags($rt->title)),0,30); ?>">
                     </div>
                  </div>
                  <div class="ab-products-grid-item-text">
                     <div class="ab-products-grid-item-type">Report</div>
                     <div class="ab-products-grid-item-title"><?php echo e($rt->title); ?></div>
                     <ul class="ab-products-grid-item-info">
                        <li> <?php echo e(Carbon\Carbon::parse($rt->report_post_date)->format('M Y')); ?></li>
                        <li><?php echo e($rt->no_of_page); ?> Pages </li>
                     </ul>
                     <ul class="ab-products-grid-item-info">
                        <li class="ab-products-list-item-info-price-home"> From <span class="ab-products-list-item-info-price-amount-home">
                           <span class="dynPrice" style=""><span class="currency-2" style="color:#c00000;">$<?php echo e($rt->single_licence_price); ?></span><span content="USD" style="display: none;">USD</span></span></span>
                        </li>
                     </ul>
                  </div>
               </a>
            </li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php endif; ?>
            
            <!-- /item -->
            
         </ul>
      </div>
   </section>
<section class="ab-reviews-publishers" style="background-color: #fff !important;">
    <div class="ab-wrapper">
        <div class="row">
      <div class="col-md-4">
                <h2 class="ab-title text-center">Few Of Our Clients</h2>
                <div class="ab-reviews-publishers-row-left mt-3">
                    <div class="row">
                        <?php $__currentLoopData = $clients; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cl): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="col-md-5 text-center client mb-2 me-4 p-2" style="border:1px solid #ddd; margin: 0 auto; height: 94px;  border-radius: 10px; box-shadow: 0 .125rem .25rem rgba(0, 0, 0, .075) !important;">
                           <div >
                            <img loading="lazy"  width="120" height="90" src="<?php echo e(asset('uploads/clients/' . $cl->client_image)); ?>" alt="Logo">
                        </div>
                     </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>
            </div> 
         
            <div class="col-md-8">
                <h2 class="ab-title text-center">Our Testimonials</h2>
                <div class="ab-reviews-publishers-row-left">
                    <?php if(count($testimonials) > 0): ?>
                    <div class="row">
                        <?php $__currentLoopData = $testimonials; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $test): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="col-md-6">
                            <div class="review-box">
                                <p class="icon"><i class="fa fa-quote-left" aria-hidden="true"></i></p>
                                <p class="review-p"><?php echo $test->description; ?></p>
                                <span><?php echo e(strip_tags($test->client_name)); ?></span>
                            </div>
                        </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
</section>

    <section class="ab-about-hero ab-bg-subtle-gray ab-section">
         <div class="ab-wrapper">
            <div class="ab-row ab-row-gap-huge">
               <div class="ab-col ab-col-desktop-6 ab-col-tablet-12" style="text-align: left;">
                     <h2 class="ab-title ">About Us</h2>
                     
                     <div class="ab-about-hero-description" style="margin-top:30px;text-align:justify">
                        <p class="ab-p" >At The Report Cube, we are more than just a market research company; we are your strategic partner in unlocking the insights that drive your business forward. With a passion for data, a commitment to precision, and a dedication to delivering actionable results, we have been a trusted resource for businesses seeking a competitive edge.
                        </p>
                        <p class="ab-p">Our mission is to empower businesses with the knowledge they need to make informed decisions, innovate, and thrive in an ever-evolving marketplace. We believe that data-driven insights are the cornerstone of success, and our team is dedicated to providing you with the highest quality research and analysis to help you stay ahead of the curve.</p>
                        <p class="ab-p">Our Commitment is to your success. We understand the challenges and opportunities that businesses face in today's dynamic environment, and we're here to help you navigate them with confidence. Our work is not just about collecting data; it's about providing you with the knowledge and insights that empower you to make smarter decisions and achieve your business goals.</p>
                     </div>
               </div>
               <div class="ab-col ab-col-desktop-6 ab-col-tablet-12 mt-5 pt-1">
                     <div class="ab-about-hero-images">
                        <div class="ab-about-hero-images-item-1 ab-about-hero-images-item"><img loading="lazy"
                                 src="<?php echo e(asset('images/about-3.jpg')); ?>" alt="about"
                                 width="450" height="300"></div>
                        
                     </div>
               </div>
            </div>
         </div>
   </section>
<section class="ab-reviews-publishers" style="background-color: #fff !important;">
      <div class="ab-wrapper">
         <h2 class="ab-title ab-align-center">Our Services</h2>
         <div class="row">
            
            <div class="col">
               <div class="ab-reviews-publishers-row-left ">                  
                  <div class="col-md-12 industry-served-logo">
                     <a href="<?php echo e(url('syndicated-research')); ?>" class="ab-reviews-publishers-image-hyperlink-float" target="_blank">
                     <img loading="lazy" width="78" height="26" src="<?php echo e(asset('assets/icons/syndicated-research.png')); ?>" alt="Forbes Logo">
                     <p class="ab-color-primary mt-2">Syndicate Research</p>
                     <p class="mt-2">Our mission is to empower businesses with the knowledge they need to make informed decisions, innovate, and thrive in an ever-evolving marketplace</p>
                     </a>
                  </div>
               </div>
            </div>
            <div class="col">
               <div class="ab-reviews-publishers-row-left ">                  
                  <div class="col-md-6 industry-served-logo">
                     <a href="<?php echo e(url('customized-research')); ?>" class="ab-reviews-publishers-image-hyperlink-float" target="_blank">
                     <img loading="lazy" width="60" height="32" src="<?php echo e(asset('assets/icons/customised-research.png')); ?>" alt="Forbes Logo">
                     <p class="ab-color-primary mt-2">Customoized Research </p>
                     <p class="mt-2">Our mission is to empower businesses with the knowledge they need to make informed decisions, innovate, and thrive in an ever-evolving marketplace</p></a>
                  </div>
               </div>
            </div>
            <div class="col">
               <div class="ab-reviews-publishers-row-left ">                  
                  <div class="col-md-6 industry-served-logo">
                     <a href="<?php echo e(url('competitive-analysis')); ?>" class="ab-reviews-publishers-image-hyperlink-float" target="_blank">
                     <img loading="lazy" width="60" height="32" src="<?php echo e(asset('assets/icons/it.png')); ?>" alt="Forbes Logo">
                     <p class="ab-color-primary mt-2"> Competitive Analysis </p>
                     <p class="mt-2">Our mission is to empower businesses with the knowledge they need to make informed decisions, innovate, and thrive in an ever-evolving marketplace</p></a>
                  </div>
               </div>
            </div>
            <div class="col">
               <div class="ab-reviews-publishers-row-left ">                  
                  <div class="col-md-12 industry-served-logo">
                     <a href="<?php echo e(url('company-profile')); ?>" class="ab-reviews-publishers-image-hyperlink-float" target="_blank">
                     <img loading="lazy" width="127" height="127" src="<?php echo e(asset('assets/icons/company-profile.png')); ?>" alt="Forbes Logo">
                     <p class="ab-color-primary mt-2"> Company Profile</p>
                     <p class="mt-2">Our mission is to empower businesses with the knowledge they need to make informed decisions, innovate, and thrive in an ever-evolving marketplace</p></a>
                  </div>
               </div>
            </div>

            <div class="col">
               <div class="ab-reviews-publishers-row-left ">                  
                  <div class="col-md-12 industry-served-logo">
                     <a href="<?php echo e(url('biographies')); ?>" class="ab-reviews-publishers-image-hyperlink-float" target="_blank">
                     <img loading="lazy" width="70" height="32" src="<?php echo e(asset('assets/icons/biography.png')); ?>" alt="Forbes Logo">
                     <p class="ab-color-primary">Biographies </p>
                     <p class="mt-2">Our mission is to empower businesses with the knowledge they need to make informed decisions, innovate, and thrive in an ever-evolving marketplace</p></a>
                  </div>
               </div>
            </div>
          

         </div>
      </div>
   </section>
<section class="ab-home-news ab-section">
      <div class="ab-wrapper">
         <div class="ab-clearfix" style="padding: 0px 15px;">
            <h2 class="ab-title ab-align-center">Latest Press Release</h2>            
         </div>
         <div class="ab-news-grid ab-row ab-row-v-padding">
            <?php $__currentLoopData = $press_release; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pr): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="ab-col ab-col-desktop-3 ab-col-tablet-3 ab-col-phone-12">
               <a href="<?php echo e(url('press-release')); ?>/<?php echo e($pr->press_release_url); ?>" class="ab-news-grid-item">
                  <div class="ab-news-grid-item-image" style="background-image: url('<?php echo e(asset('uploads/press_release/' . $pr->image)); ?>');">
                  </div>
                  <div class="ab-news-grid-item-text">
                     <div class="ab-news-grid-item-date"><?php echo e(Carbon\Carbon::parse($pr->post_date)->format('D, M Y')); ?> </div>
                     <div class="ab-news-grid-item-title"><?php echo e($pr->heading); ?>

                     </div>
                  </div>
                  <div class="ab-news-grid-item-excerpt"> <?php echo substr(html_entity_decode(strip_tags($pr->description)),0,260).'...'; ?> 
                  </div>
               </a>
            </div>
            
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
         </div>
      </div>
   </section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout/header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /mnt/home2/vvsajqnq/public_html/resources/views/home.blade.php ENDPATH**/ ?>
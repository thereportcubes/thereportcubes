<?php $__env->startSection('title','Upcoming Report'); ?>
<?php $__env->startSection('content'); ?>
<link rel="stylesheet" href="https://cdn.tutorialjinni.com/intl-tel-input/17.0.8/css/intlTelInput.css"/>
<section class="mini-banner">
   <div class="container">
      <div class="row">
         <div class="col-md-12">
            <h1 class="mb-0 mini-banner-title">Contact Us</h1>
         </div>
      </div>
   </div>
</section>
<section class="main-content mt-5 mb-5">
   <div class="container">
      <div class="row box-shadow">
         <div class="col-md-6  mb-5 px-4 py-4">
            <h4 class="fw-800 mb-4">Contact Us</h4>
            <?php if(session()->has('success')): ?>
            <div class="alert-success" style="padding:18px;border-radius: 5px;">
               <strong>Success!</strong> <?php echo e(session()->get('success')); ?>

            </div>
            <br>
            <?php endif; ?>
            <?php if(session()->has('error')): ?>
            <div class="alert-danger" style="padding:18px;border-radius: 5px;">
               <strong>Warning!</strong> <?php echo e(session()->get('error')); ?>

            </div>
            <br>
            <?php endif; ?>
            <form action="<?php echo e(route('save_contact')); ?>" method="post">
               <?php echo csrf_field(); ?>
               <div class="row forms-card-details">
                  <div class="col-sm-12 mb-3">
                     <input type="text" name="name" class="form-control" placeholder="Enter your Name*" required>
                  </div>
                  <div class="col-sm-12 mb-3">
                     <input type="text" name="company_name" class="form-control" placeholder="Enter your company name" required>
                  </div>
                  <div class="col-sm-12 mb-3">
                     <input type="email" name="busniess_email" class="form-control" placeholder="Enter your business email*" required>
                  </div>
                  <div class="col-sm-6 mb-3">
                     <input name="contact_number" type="text" id="phone" class="form-control"/>
                  </div>
                  <div class="col-sm-6 mb-3">
                     <select class="form-select form-control" name="industry" required="" style="width: 100%;">
                        <option value = "">Select industry</option>
                        <option value = "Aerospace & Defense">Aerospace & Defense</option>
                        <option value = "Automotive">Automotive</option>
                        <option value = "Buildings, Construction, Metals & Mining">Buildings, Construction, Metals & Mining</option>
                        <option value = "Chemicals">Chemicals </option>
                        <option value = "Energy">Energy</option>
                        <option value = "Environment">Environment</option>
                        <option value = "FMCG">FMCG</option>
                        <option value = "FinTech">FinTech</option>
                        <option value = "Food & Beverages">Food & Beverages</option>
                        <option value = "Healthcare">Healthcare</option>
                        <option value = "ICT & Electronics">ICT & Electronics</option>
                        <option value = "Tire">Tire</option>
                        <option value = "Others">Others</option>
                     </select>
                  </div>
                  <div class="col-sm-12 mb-3">
                     <textarea name="message" id="" cols="30" rows="4" class="form-control"
                        placeholder="Type your message here..."></textarea>
                  </div>
                  <label for="captcha" class="mb-2">Captcha *:</label>
                  <div class="form-group">
                     <div class="g-recaptcha" data-sitekey="6LfKURIUAAAAAO50vlwWZkyK_G2ywqE52NU7YO0S" data-callback="verifyRecaptchaCallback" data-expired-callback="expiredRecaptchaCallback"></div>
                     <input class="form-control d-none" data-recaptcha="true"  data-error="Please complete the Captcha">
                     <div class="help-block with-errors"></div>
                  </div>
                  <div class="col-sm-4 col-md-6">
                     <button type="submit" class="read-more-btn text-white mt-3 mb-3 text-center" id="button">Submit<i class="fa fa-arrow-right ms-2" aria-hidden="true"></i></button>
                  </div>
               </div>
            </form>
         </div>
         <div class="col-md-6">
            <img src="<?php echo e(url('public/img/contact_us.jpg')); ?>" alt="" class="w-100 mt-5 mb-4">
            <div class="card p-3 bg-light" id="card">
               <h5>Address</h5>
               <span class="mt-3"><img src="<?php echo e(url('public/img/call_icon.svg')); ?>" alt="" width="30px" class="me-3">
               US Office: +1 628 895 8081, +91 120 4278433</span>
               <span class="mt-3"><img src="<?php echo e(url('public/img/email2.png')); ?>" alt="" width="30px" class="me-3">
               sales@marknteladvisors.com</span>
               <span class="mt-3"><img src="<?php echo e(url('public/img/location.svg')); ?>" alt="" width="30px" class="me-3">
               Corporate Office: Office No.106, H-160, Sector 63, Noida, Uttar 
               </span><span class="" style="margin-top: -10px; margin-left: 52px;">Pradesh - 201301, India</span> 
            </div>
         </div>
      </div>
   </div>
</section>
<script src='https://www.google.com/recaptcha/api.js'></script>

<script>
   var input = document.querySelector("#phone");
   window.intlTelInput(input, {
       separateDialCode: true,
       excludeCountries: [ "il"],
       //preferredCountries: ["in","ru", "jp", "pk", "no"]
       preferredCountries: ["in"]
   });
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout/header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\markntel_advisor\resources\views/contact_us.blade.php ENDPATH**/ ?>
<div class="clearfix">

        <footer class="main-footer">
            <div class="ab-footer-wapper " >
                <div class="ab-footer-main-bar-right" style="color:#f2f2f2; margin-bottom:px;">
                    <div class="ab-footer-menus">
                        <div class="ab-footer-menus-col">
                            <a href="#"><img loading="lazy" width="150" height="42" src="<?php echo e(asset('img/rcube-logo.png')); ?>" alt="Research and Markets"></a>
                            
                            <ul class="ab-footer-phone-list">
                                <li><a href="tel:+919876543210"><i class="fa fa-phone"></i>+91 9876543210
                                        </a>
                                </li>
                            
                                <li  style="display: list-item;"><a href="mail:info@rcube.com"><i class="fa fa-envelope"></i> info@rcube.com </a></li>
                                                        
                            </ul>
                        </div>
                        <div class="ab-footer-menus-col">
                            <div class="ab-footer-menus-col-title">Quick Links</div>
                            <ul class="footer_link">
                                <li><a href="<?php echo e(url('about-us')); ?>">About us</a></li>
                               <!-- <li><a href="<?php echo e(url('contact-us')); ?>">Contact-us</a></li> -->
                                <li><a href="<?php echo e(url('/careers')); ?>">Careers</a></li>
                           
                                    <li><a href="<?php echo e(url('signin')); ?>">Sign-in/Register</a></li>
                            
                            </ul>
                        </div>
                        <div class="ab-footer-menus-col">
                            <div class="ab-footer-menus-col-title">Products & services </div>
                            <ul class="footer_link">
                                <li><a href="<?php echo e(url('report-store')); ?>"> Reports Store</a></li>
                              
                                <li class=""><a href="<?php echo e(url('press-release')); ?>"> Press Release</a></li>
                                <li class=""><a href="<?php echo e(url('infographics')); ?>"> Infographics</a></li>
                            </ul>
                        </div>
                        
                        <div class="ab-footer-menus-col">
                            <div class="ab-footer-menus-col-title">Contact Us</div>                        
                            <ul class="ab-footer-phone-list">
                                <li>
                                    <a href="#"><i class="fa fa-globe"></i>367 Hillcrest Lane,USA</a>
                                </li>
                                <li  style="display: list-item;">
                                    <div class="ab-footer-social">
                                        <a target="_blank" href="#"><i class="fa fa-facebook"></i><span class="ab-screen-reader-text">Facebook</span></a>
                                        <a target="_blank" href="#"><i class="fa fa-instagram"></i><span class="ab-screen-reader-text">Instagram</span></a>
                                        <a target="_blank" href="#"><i class="fa fa-linkedin-square"></i><span class="ab-screen-reader-text">LinkedIn</span></a>
                                        <a target="_blank" href="#"><i class="fa fa-twitter-square"></i><span class="ab-screen-reader-text">Twitter</span></a>
                                        
                                    </div>
                                   
                                </li>                    
                            </ul>        
                                
                        </div>
                    
                    </div>
                </div>
    <section class="terms-contationsection py-1">
   <div class="container">
      <div class="row">
         <div class="col-md-12">
            <div class="copyright-bar d-flex justify-content-between">
               <div>
                  <!-- <p class="mb-0 white">&#169; Copyright <?php echo date('Y');?> MarkNtel Advisors LLP - All Rights Reserved</p> -->
               </div>
               <div>
                  <ul class="footer_link mb-0 p-0">
                     <li class="d-inline-block ps-2"><a href="<?php echo e(url('/privacy-policy')); ?>" rel="noopener noreferrer" aria-label="Privacy Policy">Privacy Policy
                        </a>
                     </li>
                     <li class="d-inline-block ps-2">|</li>
                     <li class="d-inline-block ps-2">
                        <a href="<?php echo e(url('/terms-conditions')); ?>" rel="noopener noreferrer" aria-label="Terms and Conditions">Terms and Conditions</a>
                     </li>
                  </ul>
               </div>
            </div>
         </div>
      </div>
   </div>
</section> 
                <div class="col-sm-12">
                    <div class="ab-footer-badges col-sm-12"> 
                        <div class="ab-footer-copyright-text" style="width:50%"> Copyright © 2023-2024 R-Cube. All
                            Rights Reserved. 
                        </div>                   
                        <div class="ab-footer-badge--payments" style="text-align:right;width:50%; float:right">
                            <div class="ab-footer-badge--visa" title="VISA"><img loading="lazy" src="<?php echo e(asset('assets/images/payment-icon-visa.webp')); ?>" alt="Payment Icon Visa"></div>
                            <div class="ab-footer-badge--mastercard" title="MasterCard"><img loading="lazy" src="<?php echo e(asset('assets/images/master.png')); ?>" alt="Payment Icon Mastercard">
                            </div>
                            <div class="ab-footer-badge--amex" title="American Express"><img loading="lazy" src="<?php echo e(asset('assets/images/payment-icon-americanexpress.webp')); ?>" alt="Payment Icon Americanexpress"></div> 
                            <div class="ab-footer-badge--paypal" title="American Express"><img loading="lazy" src="<?php echo e(asset('assets/images/paypal.png')); ?>" alt="Payment Icon Americanexpress"></div>                      
                        </div>
                        
                    </div>                    
                </div>
           </div>
        </footer>
    </div>
 <!-- ==================Cookies ======================!-->
  <section class="report-section" id="display_cookies">
 </section>
<!--   <button onclick="topFunction()" id="myBtn" title="Go to top">  
     <img class="img-fluid lazy"  src ="<?php echo e(asset('img/1.png')); ?>" data-src="<?php echo e(asset('img/angle-up.webp')); ?>" />
 </button> -->
 <script>
    var base_path = "<?php echo e(url('/')); ?>/";
    var base_url = "<?php echo e(url('/')); ?>/";
    var google_captch_service =  '<?php echo e(config('services.recaptcha.key')); ?>';
</script>
<script src="<?php echo e(asset('js/jquery-3.6.4.min.js')); ?>"></script>
<script type="text/javascript" src="<?php echo e(asset('js/jquery.lazy.min.js')); ?>"></script>
<script src="<?php echo e(asset('js/include.js')); ?>"></script>
<script type="text/javascript" src="https://cdn.jsdelivr.net/npm/slick-carousel@1.8.1/slick/slick.min.js"></script>
<script src="<?php echo e(asset('js/custom.js')); ?>"></script>

   <script src="<?php echo e(asset('js/bootstrap.bundle.min.js')); ?>" defer></script>
   <script src="https://cdnjs.cloudflare.com/ajax/libs/intl-tel-input/17.0.8/js/intlTelInput.min.js"  async defer></script>
<script src="https://www.google.com/recaptcha/api.js" async defer></script>
    <script type="text/javascript" src="//cdnjs.cloudflare.com/ajax/libs/jquery.lazy/1.7.9/jquery.lazy.min.js"></script>
    <script type="text/javascript" src="//cdnjs.cloudflare.com/ajax/libs/jquery.lazy/1.7.9/jquery.lazy.plugins.min.js" ></script>
    <script type="text/javascript" src="https://translate.google.com/translate_a/element.js?cb=googleTranslateElementInit"  async defer></script> 
 <script>
    $('document').ready(function(){ 
         setTimeout(() => { $('.lazy').lazy();
        }, 1000);
    });
</script>
<script>window.gtranslateSettings = {"default_language":"en","detect_browser_language":true,"languages":["en","fr","hi"],"wrapper_selector":".gtranslate_wrapper","flag_size":24,"alt_flags":{"en":"usa"}}</script>
    
        <script src="<?php echo e(asset('/js/gtranslate.js')); ?>" defer></script>
   
</body>
</html><?php /**PATH /home/u171619165/domains/vishalghosh.com/public_html/stagingrcube/site/resources/views/layout/footer_new.blade.php ENDPATH**/ ?>
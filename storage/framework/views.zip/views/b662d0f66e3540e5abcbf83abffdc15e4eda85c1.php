<!DOCTYPE html>
<html lang="en">

<head>
   <meta charset="UTF-8">
   <meta http-equiv="X-UA-Compatible" content="IE=edge">
   <meta name="viewport" content="width=device-width, initial-scale=1.0">
   <title>Market</title>
   <!--~~~~~~~~~~~~~FontAwesome CDN Link~~~~~~~~~~~~-->
   <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.2.1/css/all.min.css"
      integrity="sha512-MV7K8+y+gLIBoVD59lQIYicR65iaqukzvf/nwasF0nqhPay5w/9lJmVM2hMDcnK1OnMGCdVK+iQrJ7lzPJQd1w=="
      crossorigin="anonymous" referrerpolicy="no-referrer" />
   <link rel="stylesheet" href="<?php echo e(url('public/css/bootstrap.min.css')); ?>">
   <link rel="stylesheet" href="<?php echo e(url('public/css/style.css')); ?>">
   <link rel="stylesheet" href="<?php echo e(url('public/css/slick-theme.css')); ?>">
   <link rel="stylesheet" href="<?php echo e(url('public/css/slick.css')); ?>">
   <link rel="stylesheet" href="<?php echo e(url('public/css/customstyle.css')); ?>">
</head>

<body>
   <!-- top bar section -->
   <section class="navbar-area ">
      <div class="login-sign-in">
         <div class="container">
            <div class="row">
               <div class="col-md-12">
                  <ul class="top-right-login text-end mb-0">
                     <li class="list-unstyled d-inline-block ps-2 fs-13 black"><a class="black" href=""><i
                              class=" fs-12 fa fa-lock"></i>
                           Sign In
                        </a>
                     </li>
                     <li class="list-unstyled d-inline-block ps-2 fs-13 black"><a class="black" href=""><i
                              class="fs-12 fa fa-user"></i>
                           Register
                        </a>
                     </li>
                     <li class="list-unstyled d-inline-block ps-2 fs-13 black"><a class="black" href="">
                           Select a
                           Language
                        </a>
                     </li>
                  </ul>
               </div>
            </div>
         </div>
      </div>
      <div class="logo-search-icons">
         <div class="container">
            <div class="row align-items-center ">
               <div class="col-md-3  hide-on-mobile">
                  <a class="navbar-brand d-inline-block hide-on-mobile" href="<?php echo e(url('/')); ?>"><img src="<?php echo e(url('public/img/logo.png')); ?>" class="img-fluid" alt=""></a>
               </div>
               <div class="col-md-6">
                  <div class="searc_bar">
                     <div class="search_bar_box">
                        <input type="text" placeholder="Search Report..." class="form-control">
                     </div>
                     <div class="search_bar_btn">
                        <button type="submit" class="search_now" aria-label="Sort"><i class="fa fa-search"></i></button>
                     </div>
                  </div>
               </div>
               <div class="col-md-3">
                  <ul class="top-right-login text-end mb-0 ps-0">
                     <li class="list-unstyled d-inline-block ps-3  blue"><a class="blue" href=""><i
                              class="fs-20 fa fa-envelope"></i>
                        </a>
                     </li>
                     <li class="list-unstyled d-inline-block ps-3  blue"><a class="blue" href=""><i
                              class="fs-20 fa fa-phone"></i>
                        </a>
                     </li>
                     <li class="list-unstyled d-inline-block ps-3  blue"><a class="blue" href=""><i
                              class="fs-20 fa fa-shopping-cart"></i>
                        </a>
                     </li>
                  </ul>
               </div>
            </div>
         </div>
      </div>
      <nav class="navbar navbar-expand-lg navbar-light white-bg pt-1 pb-1 fixed-nav">
         <div class="container">
            <a class="navbar-brand hide-on-desktop" href="#"><img src="<?php echo e(url('public/img/logo.png')); ?>" class="img-fluid" alt=""></a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNavDropdown"
               aria-controls="navbarNavDropdown" aria-expanded="false" aria-label="Toggle navigation">
               <span class="navbar-toggler-icon"></span>
            </button>
            <?php $category =\DB::table('category')->get(); ?>
            <div class="collapse navbar-collapse justify-content-end" id="navbarNavDropdown">
               <ul class="navbar-nav">
                  <li class="nav-item dropdown">
                     <a class="nav-link dropdown-toggle" href="<?php echo e(url('research-report')); ?>" id="navbarDropdown" role="button"
                        data-bs-toggle="dropdown" aria-expanded="false">
                        Research Reports
                     </a>
                     <ul class="dropdown-menu" aria-labelledby="navbarDropdown">
                     <?php $__currentLoopData = $category; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><a class="dropdown-item" href="<?php echo e(url('research-report')); ?>/<?php echo e(Crypt::encrypt($data->id)); ?>"><?php echo e($data->cat_name); ?></a></li>
                     <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                     </ul>
                  </li>
                  <li class="nav-item">
                     <a class="nav-link active" aria-current="page" href="<?php echo e(url('upcoming-report')); ?>">Upcoming Reports</a>
                  </li>
                  <li class="nav-item">
                     <a class="nav-link" href="#"> Export-import Data </a>
                  </li>
                  <li class="nav-item">
                     <a class="nav-link" href="#">Press Release</a>
                  </li>
                  <li class="nav-item">
                     <a class="nav-link" href="#">Infographics</a>
                  </li>
                  <li class="nav-item">
                     <a class="nav-link" href="#">Contact Us</a>
                  </li>
               </ul>
            </div>
         </div>
      </nav>
   </section>
   
   

   <?php echo $__env->yieldContent('content'); ?>

   
<?php echo $__env->make('layout/footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\markntel_advisor(13-10-23)\resources\views/layout/header.blade.php ENDPATH**/ ?>
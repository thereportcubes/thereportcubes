<!DOCTYPE html>
<html>
<head>
    <title>MarkNtel Advisor</title>
    <style>
        table tr td{
            padding:8px 10px;
        }
    </style>
</head>
<body>   
   

   <?php if($mailData['body_type'] =='user'): ?> 
   
   <p>
        Dear <?php echo e($mailData['name']); ?>,<br>
    
        Thank you for your application, Our team will get in touch with you if your profile gets shortlisted.
    
        <br><br>
        Thank You <br>
        Team Markntel
       </p>
    <?php elseif($mailData['body_type'] =='client'): ?>

        <table>
            <tr><td colspan="3" text-align="center" style="font-size:18px;">Job Application <br><br></td></tr>
            <tr><td colspan="3" text-align="center"><u>Details for below:</u></td></tr>
            <tr>
                <td><b>Name</b></td>
                <td style="width:50px;">:</td>
                <td><?php echo e($mailData['body']['Name']); ?></td>
            </tr>
            <tr>
                <td><b>Business Email</b></td>
                <td>:</td>
                <td><?php echo e($mailData['body']['Email']); ?></td>
            </tr>
           
            <tr>
                <td><b>Phone</b></td>
                <td>:</td>
                <td><?php echo e($mailData['body']['Phone']); ?></td>
            </tr>
            <tr>
                <td><b>Message</b></td>
                <td>:</td>
                <td><?php echo e($mailData['body']['Message']); ?></td>
            </tr>
            <tr>
                <td><b>Position Apply For</b></td>
                <td>:</td>
                <td><?php echo e($mailData['body']['Position']); ?></td>
            </tr>
            <tr>
                <td><b>Experience</b></td>
                <td>:</td>
                <td><?php echo e($mailData['body']['Experience']); ?></td>
            </tr>
            <tr>
                <td><b>Location</b></td>
                <td>:</td>
                <td><?php echo e($mailData['body']['Location']); ?></td>
            </tr>
            <tr>
                <td><b>CTC</b></td>
                <td>:</td>
                <td><?php echo e($mailData['body']['CTC']); ?></td>
            </tr>
            <tr>
                <td><b>Notice Period</b></td>
                <td>:</td>
                <td><?php echo e($mailData['body']['Notice']); ?></td>
            </tr>
        </table>

    <?php endif; ?>
    
</body>
</html><?php /**PATH /home/marknteladvisors/public_html/resources/views/emails/career_mail.blade.php ENDPATH**/ ?>

<?php $__env->startSection('title','Upcoming Report'); ?>
<?php $__env->startSection('content'); ?>

<link rel="stylesheet" href="https://cdn.tutorialjinni.com/intl-tel-input/17.0.8/css/intlTelInput.css"/>
<style>
   .iti--separate-dial-code{
      width:100%!important;
   }
</style>

<section class="mini-banner">
   <div class="container">
      <div class="row">
         <div class="col-md-12">
            <h1 class="mb-0 mini-banner-title">Search Result</h1>
         </div>
      </div>
   </div>
</section>
<section class="main-content mb-5 mt-5">
   <div class="container">
      <div class="row">
         <div class="col-md-9 sm-100">
            <div class="box-shadow">
               <h6 class="fw-600 blue-title-bg">Search Result For: <?php echo e($search_keyword); ?></h6>
               <div class="box-content p-1">
               <div class="tab-content" id="myTabContent">
                     
                     <div class="tab-pane fade show active" id="Request" role="tabpanel" aria-labelledby="Request-tab">
                     <div class="p-4">
                        <form action="<?php echo e(url('service-query')); ?>" method="post">
                           <?php echo csrf_field(); ?>

                           <input type="hidden" name="search_keyword" value="<?php echo e($search_keyword); ?>">        
                           <div class="mb-3">
                              <p class="mb-2 fs-14">Full Name*:</p>
                              <input type="text" name="full_name" value="<?php echo e(old('full_name')); ?>" class="form-control" placeholder="Enter Your Name" required>
                           </div>
                           <div class="mb-3">
                              <p class="mb-2 fs-14">Company Name*:</p>
                              <input type="text" name="company_name" value="<?php echo e(old('company_name')); ?>" class="form-control" placeholder="Enter your company name" required>
                           </div>
                           <div class="mb-3">
                              <p class="mb-2 fs-14">Business Email*:</p>
                              <input type="email" name="busniess_email" value="<?php echo e(old('busniess_email')); ?>"  class="form-control" placeholder="Enter your business email" required>
                           </div>
                           <div class="mb-3">
                              <p class="mb-2 fs-14">Contact Number*:</p>
                              <input name="phone" type="text" id="phone" value="<?php echo e(old('phone')); ?>"  class="form-control" required/>
                           </div>
                           <div class="mb-3">
                              <p class="mb-2 fs-14">Message:</p>
                              <textarea name="message" id="" cols="30" rows="4" class="form-control" placeholder="Type your message here..."><?php echo e(old('message')); ?></textarea>
                           </div>

                           <!-- <div class="mb-3">
                              <p class="mb-2 fs-14">Captcha:</p>
                              <div class="g-recaptcha" data-sitekey="6Ldncs8oAAAAAJZ7C_pvRTzTqa1RwZKNW0jfJ-Y2" data-callback="verifyRecaptchaCallback" data-expired-callback="expiredRecaptchaCallback"></div>
                              <input class="form-control d-none" data-recaptcha="true"  data-error="Please complete the Captcha">
                              <div class="help-block with-errors"></div>
                           </div> -->
                           <div class="col-12">
                              <!--<div class="captcha">
                                 <button type="button" class="btn btn-info" class="reload" id="reload">
                                       &#x21bb;
                                 </button>&nbsp;&nbsp;
                                 <span><?php echo captcha_img(); ?></span>														  
                              </div>-->
                              <div class="g-recaptcha" data-sitekey="<?php echo e(config('services.recaptcha.key')); ?>">
                           </div>
                           <div class="col-12 mt-2">
                              <!--<label class="form-label" for="form3Example4">Captcha*</label>
                              <input type="text" name="captcha" id="captcha" class="form-control" placeholder="Enter Captcha" required maxlength="5" />              
                           </div>
                           <?php if($errors->has('captcha')): ?>
                              <span class="text-danger">
                                    <strong><?php echo e($errors->first('captcha')); ?></strong>
                              </span>
                           <?php endif; ?> -->
                           <?php if($errors->has('g-recaptcha-response')): ?>
                                    <span class="help-block">
                                        <strong><?php echo e($errors->first('g-recaptcha-response')); ?></strong>
                                    </span>
                                <?php endif; ?>
                                </div>
                           <div class="text-left pt-4">
                              <button type="submit" class="btns btn-primary">Submit Request</button>
                           </div>
                           <input type="hidden" name="country_name" id="country-name"  value="United States" />
                        </form>
                     </div>  
                      </div>
                  </div>
               </div>
            </div>
         </div>
         <div class="col-md-3 sm-100">
              
            <div class="box-shadow">
               <h6 class="fw-600 blue-title-bg"><i class="fa fa-user fs-14" aria-hidden="true"></i> Need Assistance?
               </h6>
               <div class="mb-2">
                  <p class="mb-0 fs-14">
                     <i class="fa fa-envelope me-2 orrange" aria-hidden="true"></i> WRITE AN EMAIL
                  </p>
                  <a href="mailto:sales@marknteladvisors.com">sales@marknteladvisors.com</a>
               </div>
               <div>
                  <p class="mb-0 fs-14"><i class="fa fa-phone me-2 orrange" aria-hidden="true"></i>CALL US</p>
                  <a class="fs-14" href="tel:+1 628 895 8081, +91 120 4278433">+1 628 895 8081, +91 120 4278433</a>
               </div>
            </div>
            <div class="box-shadow">
               <h6 class="fw-600 blue-title-bg"><i class="fa fa-lock me-2 fs-14 "></i>100% Safe & Secure</h6>
               <p class="fs-14">
                  Strongest encryption on the website to make your purchase safe and secure
               </p>
            </div>
         </div>
      </div>
   </div>
</section>

<script src='https://www.google.com/recaptcha/api.js'></script>
<script src="<?php echo e(url('public/js/intlTelInput.min.js')); ?>"></script>
<script>
   var input = document.querySelector("#phone");
   input.setAttribute('placeholder', ' ');
   const countryNameElement = document.querySelector("#country-name");
   const iti = window.intlTelInput(input, {
      utilsScript: "https://cdnjs.cloudflare.com/ajax/libs/intl-tel-input/17.0.8/js/utils.js",
      separateDialCode: true,
      initialCountry: "US",
   });
   
 
   function updateCountryName() {
      const selectedCountryData = iti.getSelectedCountryData();
      //const selectedCountryName = selectedCountryData.name;
      const selectedCountryName = selectedCountryData.name.replace(/\s*\([^)]*\)/, '');
      countryNameElement.value = selectedCountryName;
      
   }

   input.addEventListener("countrychange", updateCountryName); 

</script>

<!-- plugins -->
<script src="<?php echo e(url('public/assets/js/vendors.js')); ?>"></script>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>

    <!-- custom app -->
    <script src="<?php echo e(url('public/assets/js/app.js')); ?>"></script>
	
	<script type="text/javascript">
      let base_url_search = <?php echo json_encode(url('/')); ?>;
		$('#reload').click(function () {
			$.ajax({
				type: 'GET',
				url: base_url_search + '/reload-captcha',
				success: function (data) {
					$(".captcha span").html(data.captcha);
				}
			});
		});
	</script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout/header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/marknteladvisors/public_html/resources/views/search_query.blade.php ENDPATH**/ ?>
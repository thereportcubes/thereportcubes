 <?php if(!is_null($data) && count($data) > 0): ?>
                 <?php if(count($data)>0): ?>
                        <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $d): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                       
                         <div class="product-item-small product-item-mobile clearfix">
                              <div class="product-item-content">
                                 <div class="ab-product-thumbnail-book-binder left">
                                    <div class="product-img-box">
                                       <span class="image-report" style="color:#000;top: 7px;left: 3px;font-size: 6px;">Report</span>
                                       <h4 class="image-title" style="color: #fff;top: 20px;font-size: 6px;text-align: left;width: 50px;left: 5px;">
                                       <?php echo e($d->cat_name); ?>                        
                                       </h4>
                                       <span class="imag-pages" style="color: #fff;font-size: 4px;left: 5px;bottom: 5px;"><?php echo ($d->no_of_page) ? $d->no_of_page : '0' ?> pages</span>
                                       <span class="book-years" style="color: #fff;font-size: 10px;right: 18px;bottom: 3px;"><?php echo e(Carbon\Carbon::parse($d->report_post_date)->format('M Y')); ?></span>
                                    </div>
                                    <img loading="lazy" class="nonGenericproductSmallImage"src="<?php echo e(asset('img/reportimg.jpg')); ?>"  width="60" height="86">
                                 </div>
                                 <div class="content" style="text-align: left; margin-right: 10px;">
                                    <h3 class="title bold"><a href="<?php echo e(url('report-store')); ?>/<?php echo e(($d->page_url)); ?>" style="color:var(--primary-color);"><?php echo e($d->title); ?></a></h3>
                                    <p style="margin-bottom: 10px;"><?php echo substr(html_entity_decode(strip_tags($d->decription)),0,260); ?></p><br>
                                    <ul class="product-item-list">
                                       <li class="first"> <img  style="margin-right:5px;" alt="PDF Icon" src="<?php echo e(asset('/assets/images/icon-PDF.webp')); ?>" srcset="<?php echo e(asset('/assets/images/icon-PDF.webp')); ?>" width="20"> Report </li>
                                       <li> <?php echo ($d->no_of_page) ? $d->no_of_page : '0' ?> Pages </li>
                                       <li id="publicationDateItemId_related_products_5807230" class="publicationDateItem"><?php echo e(Carbon\Carbon::parse($d->report_post_date)->format('M Y')); ?></li>
                                       <li class="last"><a  class="report-read-more"href="<?php echo e(url('report-store')); ?>/<?php echo e(($d->page_url)); ?>">Read More</a></li>
                                    </ul>
                                 </div>
                              </div>
                           </div> 
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                     <?php endif; ?>
                         <?php endif; ?>
                      <ul class="pagination clearfix" id="paginationBottom">
                           <li class="page-count"><strong><span><?php echo e(count($data)); ?></span> Results</strong> (Page 1 of <?php echo e(ceil(count($data)/10)); ?> ) </li>

                           <li class="pager-btn-container">
                              <?php echo e($data->links('custom_pagination')); ?>

                           </li>
                        </ul>

                  <?php /**PATH /home/u171619165/domains/vishalghosh.com/public_html/stagingrcube/site/resources/views/filterresult.blade.php ENDPATH**/ ?>
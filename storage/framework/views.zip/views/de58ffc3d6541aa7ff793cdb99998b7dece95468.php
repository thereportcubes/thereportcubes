
<?php $__env->startSection('title','Markntel'); ?>
<?php $__env->startSection('content'); ?>
<div class="app-main" id="main">
   <!-- begin container-fluid -->
   <div class="container-fluid">
      <!-- begin row -->
      <div class="row">
         <div class="col-md-12 m-b-30">
            <!-- begin page title -->
            <div class="d-block d-sm-flex flex-nowrap align-items-center">
               <!-- <div class="page-title mb-2 mb-sm-0">
                  <h1>Speak To Analyst</h1>
               </div> -->
               <div class="ml-auto d-flex align-items-center">
                  <nav>
                     <ol class="breadcrumb p-0 m-b-0">
                        <li class="breadcrumb-item">
                           <a href="<?php echo e(url('admin/dashboard')); ?>"><i class="ti ti-home"></i></a>
                        </li>
                        <li class="breadcrumb-item">
                           User
                        </li>
                        <li class="breadcrumb-item active text-primary" aria-current="page">Career</li>
                     </ol>
                  </nav>
               </div>
            </div>
            <!-- end page title -->
         </div>
      </div>
      <!-- end row -->
     <!-- Categories Table -->
     <div class="card mb-3">
          <div class="card-body admin-category">
             <a href="<?php echo e(route('add_career')); ?>" class="btn btn-primary" >Add Career Page Data</a>
          </div>      
          <div class="card-body admin-category">
             <a href="https://www.marknteladvisors.com/admin/career/add" class="btn btn-info" >Add Opening</a>
          </div>  
        </div>

        <div class="card mb-3">
          
          <div class="card-body">
            <div class="table-responsive">
              <table class="table table-bordered" id="dataTable"  cellspacing="0">
                     <thead>
                     <tr>
                        <th>ID</th>
                        <th>Heading</th>
                        <th>Experiance</th>
                        <th>Location</th>
                        <th>Report To</th>
                        <th style="width:100px">Roles & Responsibilities</th>
                        <th>Created Date Time</th>
                        <th>Action</th>                   
                    </tr>
                     </thead>
                     <tbody>
                        <?php $__currentLoopData = $list; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                           <td style="width:100px" class="p-1">&nbsp;<?php echo e(++$key); ?></td>
                           <td><?php echo e($data->heading); ?></td>
                           <td><?php echo e($data->Experiance); ?></td>
                           <td><?php echo e($data->Location); ?></td>
                           <td><?php echo e($data->report_to); ?></td>
                           <td><p style="word-break:break-all;";><?php echo $data->roles_responsibilities ?></p> </td>
                           <td><?php echo e($data->created_date_time); ?></td> 
                           <td><a class="btn btn-sm btn-primary shadow-none" href="<?php echo e(url('admin/edit_career')); ?>/<?php echo e($data->id); ?>" role="button">Edit</a>
                              &nbsp;
                              <a class="btn btn-sm btn-danger shadow-none" onClick="delRow(<?php echo e($data->id); ?>)" href="javascript:void()" role="button">Delete</a>
                           </td>   
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                     </tbody>
                  </table>
               </div>
</div>
</div>

            

  </div>
  <!-- /#wrapper -->

</div>
<!-- end app-main -->
<script>
   function exportTasks(_this) {
      let _url = $(_this).data('href');
      window.location.href = _url;
   }

   function delRow(val) {
   
   var r=confirm("Are you sure?")
   if (r==true)
   {
      $.ajax({
       url : '<?php echo e(route("admin/delete_career")); ?>' ,
       type: 'get',
         data: {'rowId':val},
         dataType: "text",
       success: function(response){				  
            alert(response);
            var base_url = <?php echo json_encode(url('/')); ?>

            window.location.href= base_url + '/admin/career_list';                
         }
      });
 }
 else{         
 }
 
 };
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin/header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/marknteladvisors/public_html/resources/views/admin/career_list.blade.php ENDPATH**/ ?>
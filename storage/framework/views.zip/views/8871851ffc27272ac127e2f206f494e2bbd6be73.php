
<?php echo $__env->yieldContent('title'); ?>
<?php $__env->startSection('content'); ?> 

<main class="background-gray">
   <section id="content-infos-pages">
      <section class="ab-title-section ab-bg-dark-red ab-color-white ab-section">
         <div class="ab-title-section-bg" style="background-image: url(/rcube/assent/images/banner.jpg);">
            <div class="ab-section-divider">
               <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 100 100" preserveAspectRatio="none">
                  <polygon points="0,0 100,0 0,100"></polygon>
               </svg>
            </div>
         </div>
         <div class="ab-wrapper">
            <div class="ab-title-section-text">
               <h1 class="ab-large-title">Infographics</h1>
            </div>
         </div>
      </section>
      <div class="banner-triangle"></div>
   </section>

   <section class="ab-home-news ab-section">
      <div class="ab-wrapper">
         
         <div class="ab-news-grid ab-row ab-row-v-padding">
            <?php $__currentLoopData = $infographic; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pr): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="ab-col ab-col-desktop-3 ab-col-tablet-3 ab-col-phone-12" >
               <a href="<?php echo e(url('infographics')); ?>/<?php echo e($pr->report_link); ?>" class="" style="background-color:#fff; color:#454748; min-height:200px;">
                  <div class="" >
                   <img src="<?php echo e(asset($pr->image)); ?>" alt="<?php echo e($pr->img_alt_tag); ?>" style="min-height:150px; min-width:100%"  class="img img-responsive" />
                  </div>
                  <div class="ab-news-grid-item-text" style="min-height: 170px">
                     
                     <div class="ab-news-grid-item-title"><?php echo substr($pr->title,0,80); ?></div>
                     <div class="ab-news-grid-item-date"><i class="fa fa-calendar" aria-hidden="true" style="color:#c00000"></i> <?php echo e(Carbon\Carbon::parse($pr->created_at)->format('M Y')); ?></div>
                  </div>
              
               </a>
            </div>
            
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            
         </div>

         <ul class="pagination clearfix" id="paginationBottom">
               <li class="page-count"><strong><span><?php echo e(count($infographic)); ?></span> Results</strong> (Page 1 of <?php echo e(ceil(count($infographic)/10)); ?> ) </li>

               <li class="pager-btn-container">
                  <?php echo e($infographic->links('custom_pagination')); ?>

               </li>
            </ul>

            
      </div>
   </section>
</div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layout.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /mnt/home2/vvsajqnq/public_html/thereportcubes.com/resources/views/infographics.blade.php ENDPATH**/ ?>
<!DOCTYPE html>
<html>
<head>
    <title>MarkNtel Advisor</title>
    <style>
        table tr td{
            padding:8px 10px;
        }
    </style>
</head>
<body>   
   

   <?php if($mailData['body_type'] =='user'): ?> 
   <!-- <h1><?php echo e($mailData['title']); ?></h1> -->
   <p>
        Dear <?php echo e($mailData['name']); ?>, <br><br>
    
        Thank you for your Searh request. <br><br>
    
        We appreciate your patience and will contact you soon. <br><br>
    
        <a href='https://www.marknteladvisors.com/'>MarkNtel Advisors</a> is a premier market/business research, consulting, and analytics center known for its incessant real-time support. We work 24*7 to ensure that our clients meet their objectives. We deliver <a href='https://www.marknteladvisors.com/services'>research, consulting </a> and <a href='https://www.marknteladvisors.com/data-analytics/'>data analytics </a>services across industries like Information & Communication Technology (ICT), Healthcare, FMCG, FinTech, Aerospace & Defence, Building & Construction Materials, Automotive, Chemicals, Tires, Energy, and Banking & Financial Services among others.
        <br><br>
        For further more queries, please drop us a mail at <a href='mailto:sales@marknteladvisors.com'>sales@marknteladvisors.com</a> <br><br>
        Thank You <br>
        <strong>Team Markntel</strong>
       </p>
    <?php elseif($mailData['body_type'] =='client'): ?>
    <table>
            <tr>
                <td><b>Name</b></td>
                <td style="width:50px;">:</td>
                <td><?php echo e($mailData['body']['Name']); ?></td>
            </tr>
            <tr>
                <td><b>Company Name</b></td>
                <td>:</td>
                <td><?php echo e($mailData['body']['Company Name']); ?></td>
            </tr>
            <tr>
                <td><b>Business Email</b></td>
                <td>:</td>
                <td><?php echo e($mailData['body']['Business Email']); ?></td>
            </tr>
            <tr>
                <td><b>Country</b></td>
                <td>:</td>
                <td><?php echo e($mailData['body']['Country_Name']); ?></td>
            </tr>
            <tr>
                <td><b>Contact Number</b></td>
                <td>:</td>
                <td><?php echo e($mailData['body']['Contact_No']); ?></td>
            </tr>
            <tr>
                <td><b>Message</b></td>
                <td>:</td>
                <td><?php echo e($mailData['body']['Message']); ?></td>
            </tr>
        </table> 
    <?php endif; ?>
    
</body>
</html><?php /**PATH /home/marknteladvisors/public_html/resources/views/emails/search_mail.blade.php ENDPATH**/ ?>
<?php echo $__env->yieldContent('title'); ?>
<?php $__env->startSection('content'); ?>
<main>
   <div id="about-us" class="ab-body ab-page-about">
      <section class="ab-about-hero ab-bg-subtle-gray ab-section">
            <div class="ab-wrapper">
               <div class="ab-row ab-row-gap-huge">
                  <div class="ab-col ab-col-desktop-12 ab-col-tablet-12" style="text-align: left;">
                     <h2 class="ab-large-title ab-color-primary">Syndicated Research</h2>
                     <p class="ab-p mb-4" ><b>Syndicated Research </b> is a tailor made solution and a powerful tool that leverages the collective knowledge and resources of multiple experts to provide a robust and insightful analysis of a specific subject.</p>

                     <div><img src="<?php echo e(asset('/assets/images/product_images/syndicate_research2.png')); ?>"  /></div>

                     <p class="mt-4 ab-p" ><b>What is syndicated research?</b><br>
Syndicated market research is a ready-made report about a specific industry or a market with a pre-defined table of content. The findings are typically compiled into reports that provide a comprehensive overview of the market, including trends, opportunities, challenges, and other relevant information.</p>


                  </div>
                  
               </div>
            </div>
      </section>

      <?php echo $__env->make('layout.why_us', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

   </div>
</main>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.newheader', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\markintal_site\resources\views/service_syndicated_research.blade.php ENDPATH**/ ?>
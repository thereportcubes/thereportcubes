
<?php $__env->startSection('title','About Us'); ?>
<?php $__env->startSection('content'); ?>

<section class="mini-banner">
   <div class="container">
      <div class="row">
         <div class="col-md-12">
            <h1 class="mb-0 mini-banner-title">About Us</h1>
         </div>
      </div>
   </div>
</section>

<section>
     <div class="container mb-4 mt-4">
       <div class="row">
           <div class="col-sm-1">
           </div>
           <div class="col-sm-11 mb-4">
       
                 <h2><strong>Why Choose Us</strong></h2>
                 <p>MarkNtel Advisors is a leading consulting, data analytics, and <strong>market research firm</strong> that provides an extensive range of strategic reports on diverse industry verticals. We being a <strong>qualitative & quantitative research company</strong>, strive to deliver data to a substantial & varied client base, including multinational corporations, financial institutions, governments, and individuals, among others. </p>
   
   <p>We have our existence across the market for many years and have conducted multi-industry research <strong>across 80+ countries</strong>, spreading our reach across numerous regions like America, Asia-Pacific, Europe, the Middle East & Africa, etc., and many countries across the regional scale, namely, the US, India, the Netherlands, Saudi Arabia, the UAE, Brazil, and several others.</p>
   
   <p>Being one of the most efficient <Strong>market research companies in India</strong>, our specialized team of experienced & efficient market research professionals is capable of grasping every minute and valuable information & data of the market to offer our clients with satisfactory details. Our company has served the biggest market research firms in India at leading positions and is proficient in managing all types of market research projects.</p>
   
    <p>Our specialization in niche industries & emerging geographies allows our clients, who are large research and consulting firms, to formulate their strategies in a much more informed way and entail parameters like Go-to-Market (GTM), product development, feasibility analysis, project scoping, market segmentation, competitive benchmarking, market sizing & forecasting, and trend analysis, among others, for 15 diverse industrial verticals. </p>
    
    <p>Using such information, the top market research companies can identify attractive investment opportunities & strategize their moves to yield higher ROI (Return of Interest) through an early mover advantage with top-management approaches.We understand the mounting & diverse needs of our clients. Hence, our analysts focus on emerging industries to provide services that fulfill their assessment of the current & future industry potential, identify white spaces & hotspots, and venture into new geographies or business segments in the future.</p>

               </div>
           </div>
       </div>
   </section>
   
   <section>
      <div class="container mt-4">
       <div class="row">
           <div class="col-sm-1">
               <div class="">
               <img src="<?php echo e(url('public/img/Group_2.svg')); ?>" alt="" class="about-us-icon img-responsive" id="about-us-icon">
           </div>
           </div>
           <div class="col-sm-11">
               <div class="">
                 <h2 class=""><strong>Mission</strong></h2>
                 <p>Our team entails professional analysts and researchers who intelligently utilize research techniques to procure detail-driven, unbiased, and reliable data encompassing the industry. We aim to nurture a result-oriented team to offer strategically-moving insights to our clients.
               &nbsp;</p>
   
   <p>Our fact-based reports allow the user to design their motives, funds, and strategies, with a higher focus on mitigating confusion and bringing forward a clear insight into the industry. It further allows the clients to identify the lucrative opportunities awaiting.&nbsp;</p>
   
   <p>Insights offered by MarkNtel Advisors comprise in-depth information on regional &amp; country-based trends emerging in the industry. The team studies &amp; compiles the prospects, ensuring consistency in reports.&nbsp;</p>
   
   <p>Our services are beyond offering research reports to the clients and further expand into addressing queries while incorporating with them for advice, development, &amp; execution of strategies for exception growth.</p>
               </div>
           </div>
       </div>
      </div>
   </section>
   
   <section>
      <div class="container mb-5 mt-5">
       <div class="row">
           <div class="col-sm-1">
               <div class="">
               <img src="<?php echo e(url('public/img/Group_3.svg')); ?>" alt="" class="about-us-icon img-responsive" id="about-us-icon">
           </div>
           </div>
           <div class="col-sm-11 mb-5">
               <div class="">
                 <h2><strong>Vision</strong></h2>
                 <p>We help our investors to establish robust strategies for the implementation of best practices to overcome challenges & tap new opportunities for their growth in the industry. Our goal is to benefit individuals & communities by working with our clients in diverse ways. &nbsp;</p>
   
   <p>We understand that making durable, substantial, and unique improvements in the overall performance and establishing oneself comes with great backstories for firms. Hence, MarkNtel Advisors aims to put together values that reflect adherence to professional standards. &nbsp;</p>
   
   <p>Our core values revolve around putting the interests & requirements of our clients ahead of our organization & delivering exceptional services while maintaining utmost professionalism. We believe in preserving the confidence of our users & maintaining an independent perspective while utilizing resources intelligently & cost-effectively, creating abiding associations based on trust. &nbsp;</p>
               </div>
           </div>
       </div>
      </div>
   </section>
   
   

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout/header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\markintal_site\resources\views/about.blade.php ENDPATH**/ ?>
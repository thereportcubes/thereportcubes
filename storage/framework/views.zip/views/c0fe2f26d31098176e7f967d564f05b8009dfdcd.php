
<?php $__env->startSection('title','Edit seo'); ?>
<?php $__env->startSection('content'); ?>

<!-- begin app-main -->
<div class="app-main" id="main">
    <!-- begin container-fluid -->
    <div class="container-fluid">
        <!-- begin row -->
        <div class="row">
            <div class="col-md-12 m-b-30">
                <!-- begin page title -->
                <div class="d-block d-sm-flex flex-nowrap align-items-center">
                    <!-- <div class="page-title mb-2 mb-sm-0">
                        <h1>MemberShip</h1>
                    </div> -->
                    <div class="ml-auto d-flex align-items-center">
                        <nav>
                            <ol class="breadcrumb p-0 m-b-0">
                                <li class="breadcrumb-item">
                                    <a href="<?php echo e(url('admin/dashboard')); ?>"><i class="ti ti-home"></i></a>
                                </li>
                                <li class="breadcrumb-item">
                                Seo Pages
                                </li>
                                <li class="breadcrumb-item active text-primary" aria-current="page">Edit Seo Page</li>
                            </ol>
                        </nav>
                    </div>
                </div>
                <!-- end page title -->
            </div>
        </div>
        <!-- end row -->
        <!-- begin row -->
        <div class="row">
            
            <div class="col-xl-12">
                <div class="card card-statistics">
                    <div class="card-header">
                        <div class="card-heading">
                            <div class="row">
                                <div class="col-md-10"><h4 class="card-title">Edit Seo Page</h4></div>
                                <div class="col-md-2">&nbsp;</div>
                            </div>
                        </div>
                    </div>
                    <div class="card-body">
                        <?php if(session()->has('success')): ?>
                            <div class="alert-success" style="padding:18px;border-radius: 5px;">
                                <strong>Success!</strong> <?php echo e(session()->get('success')); ?>

                            </div><br>
                        <?php endif; ?>
                        <?php if(session()->has('error')): ?>
                            <div class="alert-danger" style="padding:18px;border-radius: 5px;">
                                <strong>Warning!</strong> <?php echo e(session()->get('error')); ?>

                            </div><br>
                        <?php endif; ?>
                        <form action="<?php echo e(url('admin/update-seo-page')); ?>/<?php echo e(request()->segment(3)); ?>" method="post" enctype="multipart/form-data">
                            <?php echo csrf_field(); ?>
                            <div class="form-row">
                                <div class="form-group col-md-12">
                                    <label for="category">Pages</label>
                                    <select name="page_category" class="form-control " id="paage_category" required = "true">
                                        <option value="">Select Page</option>
                                        <option value="home" <?php if($list->page_key == 'home'): ?> <?php echo e("selected"); ?> <?php endif; ?> >Home</option>
                                        <option value="report_stores" <?php if($list->page_key == 'report_stores'): ?> <?php echo e("selected"); ?> <?php endif; ?>>Report Store</option>
                                        <option value="services" <?php if($list->page_key == 'services'): ?> <?php echo e("selected"); ?> <?php endif; ?>>Services</option>
                                        <option value="press_release" <?php if($list->page_key == 'press_release'): ?> <?php echo e("selected"); ?> <?php endif; ?>>Press Release</option>
                                        <option value="about_us" <?php if($list->page_key == 'about_us'): ?> <?php echo e("selected"); ?> <?php endif; ?>>About Us</option>
                                        <option value="contact_us" <?php if($list->page_key == 'contact_us'): ?> <?php echo e("selected"); ?> <?php endif; ?>>Contact Us</option>
                                        <option value="search_page" <?php if($list->page_key == 'search_page'): ?> <?php echo e("selected"); ?> <?php endif; ?>>Search</option>
                                        <option value="infographics" <?php if($list->page_key == 'infographics'): ?> <?php echo e("selected"); ?> <?php endif; ?>>Infographics</option>
                                        <option value="blog" <?php if($list->page_key == 'blog'): ?> <?php echo e("selected"); ?> <?php endif; ?>>Blogs</option>
                                        <option value="careers" <?php if($list->page_key == 'careers'): ?> <?php echo e("selected"); ?> <?php endif; ?>>Careers</option>
                                        <option value="upcoming_reports" <?php if($list->page_key == 'upcoming_reports'): ?> <?php echo e("selected"); ?> <?php endif; ?>>Upcoming Report</option>
                                        <option value="terms_condition" <?php if($list->page_key == 'terms_condition'): ?> <?php echo e("selected"); ?> <?php endif; ?>>Terms and Condition</option>
                                        <option value="privacy_policy" <?php if($list->page_key == 'privacy_policy'): ?> <?php echo e("selected"); ?> <?php endif; ?>>Privacy Policy</option>

                                         <option value="syndicated_research" <?php if($list->page_key == 'syndicated_research'): ?> <?php echo e("selected"); ?> <?php endif; ?>>Syndicated Research</option>
                                          <option value="customized_research" <?php if($list->page_key == 'customized_research'): ?> <?php echo e("selected"); ?> <?php endif; ?>>Customized Research</option>
                                           <option value="competitive_analysis" <?php if($list->page_key == 'competitive_analysis'): ?> <?php echo e("selected"); ?> <?php endif; ?>>Competitive Analysis</option>
                                            <option value="company_profile" <?php if($list->page_key == 'company_profile'): ?> <?php echo e("selected"); ?> <?php endif; ?>>Company Profile</option>
                                             <option value="biographies" <?php if($list->page_key == 'biographies'): ?> <?php echo e("selected"); ?> <?php endif; ?>>Biographies</option>
                                    </select>
                                </div>
                               <div class="form-group col-md-12">
                                    <label for="page">Seo Title</label>
                                        <input type="text" name="seo_title" placeholder="Seo Title" class="form-control" id="seo_title" required value="<?php echo !empty($seo_content->seo_title) ? $seo_content->seo_title : ''; ?>">
                                </div>
                              <div class="form-group col-md-12">
                                 <label for="page">Seo Description</label>
                                         <textarea name="seo_description" rows="4" cols="50" class="form-control"><?php echo !empty($seo_content->seo_description) ? $seo_content->seo_description : ''; ?></textarea>
                                        </div>
                                <div class="form-group col-md-12">
                                         <label for="page">Seo Key Words</label>
                                    <textarea name="seo_key_words" rows="4" cols="50" class="form-control"><?php echo !empty($seo_content->seo_key_words) ? $seo_content->seo_key_words : ''; ?></textarea>
                                        </div>
                                
                            </div>
                           
                            <button type="submit" class="btn btn-primary">Update</button>
                        </form>
                    </div>
                </div>
            </div>
            
        </div>
        <!-- end row -->

    </div>
    <!-- end container-fluid -->
</div>
<!-- end app-main -->


<script src="https://cdn.ckeditor.com/4.5.7/full/ckeditor.js"></script>

<script>

  CKEDITOR.replace( 'Description' , {
              // filebrowserBrowseUrl : '/browser/browse/type/all',
              filebrowserUploadUrl: '/media/upload/type/all',
              // filebrowserImageBrowseUrl : '/public/media',
              filebrowserImageUploadUrl: 'https://www.marknteladvisors.com/admin/Add_report/upload_image_description_ckeditor',
              filebrowserWindowWidth: 800,
              filebrowserWindowHeight: 500
          });
  CKEDITOR.replace( 'Description2' , {
              // filebrowserBrowseUrl : '/browser/browse/type/all',
              filebrowserUploadUrl: '/media/upload/type/all',
              // filebrowserImageBrowseUrl : '/public/media',
              filebrowserImageUploadUrl: 'https://www.marknteladvisors.com/admin/Add_report/upload_image_description_ckeditor',
              filebrowserWindowWidth: 800,
              filebrowserWindowHeight: 500
          });

  CKEDITOR.replace( 'table_of_content');

</script>

<script type="text/javascript">

CKEDITOR.replace( 'Description', {
    extraPlugins: 'imageuploader',
   filebrowserImageBrowseUrl :
    'https://www.marknteladvisors.com/theme/plugins/imageuploader/imgbrowser.php?CKEditor=textarea&CKEditorFuncNum=1&langCode=en-gb'
  
});
</script>


<?php $__env->stopSection(); ?>
           
<?php echo $__env->make('admin/header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u171619165/domains/vishalghosh.com/public_html/stagingrcube/site/resources/views/admin/edit_seo_page.blade.php ENDPATH**/ ?>
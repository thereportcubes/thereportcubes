<!DOCTYPE html>
<html>
<head>
    <title>MarkNtel Advisor</title>
    <style>
        table tr td{
            padding:8px 10px;
        }
    </style>
</head>
<body>   
   

   <?php if($mailData['body_type'] =='send_verification'): ?> 
   <p>
        Dear <?php echo e($mailData['name']); ?>, <br><br>
    
        Please click the button below to verify you email address.<br><br>
        <a href='https://www.marknteladvisors.com/email/verify/<?php echo e($mailData['code']); ?>'>Verify Email Address</a><br /><br />
        WeIf you did not create an account, no further action is required. <br><br>
        Thank You <br>
        Team Markntel
       </p>
   <?php elseif($mailData['body_type'] =='user'): ?> 
   <!-- <h1><?php echo e($mailData['title']); ?></h1> -->
   <p>
        Dear <?php echo e($mailData['name']); ?>, <br><br>
    
        Thank you for showing interest. <br><br>
    
        We appreciate your patience and will contact you soon. <br><br>
    
        For further more queries, please drop us a mail at <a href='mailto:sales@marknteladvisors.com'>sales@marknteladvisors.com</a> <br>
    
        <a href='https://www.marknteladvisors.com/'>MarkNtel Advisors</a> is a premier market/business research, consulting, and analytics center known for its incessant real-time support. We work 24*7 to ensure that our clients meet their objectives. We deliver <a href='https://www.marknteladvisors.com/services'>research, consulting </a> and <a href='https://www.marknteladvisors.com/data-analytics/'>data analytics </a>services across industries like Information & Communication Technology (ICT), Healthcare, FMCG, FinTech, Aerospace & Defence, Building & Construction Materials, Automotive, Chemicals, Tires, Energy, and Banking & Financial Services among others.
        <br><br>
         <table>
            <tr>
                <td><b>Name</b></td>
                <td style="width:50px;">:</td>
                <td><?php echo e($mailData['name']); ?></td>
            </tr>
            <tr>
                <td><b>Company Name</b></td>
                <td>:</td>
                <td><?php echo e($mailData['company_name']); ?></td>
            </tr>
            <tr>
                <td><b>Payment Type</b></td>
                <td>:</td>
                <td><?php echo e($mailData['payment_type']); ?></td>
            </tr>
            <tr>
                <td><b>Business Email</b></td>
                <td>:</td>
                <td><?php echo e($mailData['email']); ?></td>
            </tr>
            <tr>
                <td><b>Country</b></td>
                <td>:</td>
                <td><?php echo e($mailData['country']); ?></td>
            </tr>
            <tr>
                <td><b>Contact Number</b></td>
                <td>:</td>
                <td><?php echo e($mailData['phone_number']); ?></td>
            </tr>
            <tr>
                <td><b>City</b></td>
                <td>:</td>
                <td><?php echo e($mailData['city']); ?></td>
            </tr><tr>
                <td><b>Address</b></td>
                <td>:</td>
                <td><?php echo e($mailData['address']); ?></td>
            </tr><tr>
                <td><b>Designation</b></td>
                <td>:</td>
                <td><?php echo e($mailData['designation']); ?></td>
            </tr><tr>
                <td><b>Zip</b></td>
                <td>:</td>
                <td><?php echo e($mailData['zip']); ?></td>
            </tr>
            <tr>
                <td colspan="2">
                    <table>
                       <tr>
                            <td>Order Confirmation #</td>
                            <td>Amount</td>
                        </tr>
                        <tr>
                            <td><?php echo e($mailData['product_title']); ?></td>
                            <td>$<?php echo e($mailData['product_price']); ?></td>
                        </tr>
                        <tr>
                            <td>TOTAL</td>
                            <td>$<?php echo e($mailData['product_price']); ?></td>
                        </tr>
                    </table>
                </td>
            </tr>
            <tr>
                <td><b>Message</b></td>
                <td>:</td>
                <td><?php echo e($mailData['message']); ?></td>
            </tr>
        </table> 
        <br><br>
        Thank You <br>
        Team Markntel
       </p>
    <?php elseif($mailData['body_type'] =='client'): ?>        

        <table>
            <tr>
                <td><b>Name</b></td>
                <td style="width:50px;">:</td>
                <td><?php echo e($mailData['name']); ?></td>
            </tr>
            <tr>
                <td><b>Company Name</b></td>
                <td>:</td>
                <td><?php echo e($mailData['company_name']); ?></td>
            </tr>
            <tr>
                <td><b>Payment Type</b></td>
                <td>:</td>
                <td><?php echo e($mailData['payment_type']); ?></td>
            </tr>
            <tr>
                <td><b>Business Email</b></td>
                <td>:</td>
                <td><?php echo e($mailData['email']); ?></td>
            </tr>
            <tr>
                <td><b>Country</b></td>
                <td>:</td>
                <td><?php echo e($mailData['country']); ?></td>
            </tr>
            <tr>
                <td><b>Contact Number</b></td>
                <td>:</td>
                <td><?php echo e($mailData['phone_number']); ?></td>
            </tr>
            <tr>
                <td><b>City</b></td>
                <td>:</td>
                <td><?php echo e($mailData['city']); ?></td>
            </tr><tr>
                <td><b>Address</b></td>
                <td>:</td>
                <td><?php echo e($mailData['address']); ?></td>
            </tr><tr>
                <td><b>Designation</b></td>
                <td>:</td>
                <td><?php echo e($mailData['designation']); ?></td>
            </tr><tr>
                <td><b>Zip</b></td>
                <td>:</td>
                <td><?php echo e($mailData['zip']); ?></td>
            </tr>
            <tr>
                <td colspan="2">
                    <table>
                        <tr>
                            <td>Order Confirmation #</td>
                            <td>Amount</td>
                        </tr>
                        <tr>
                            <td><?php echo e($mailData['product_title']); ?></td>
                            <td>$<?php echo e($mailData['product_price']); ?></td>
                        </tr>
                        <tr>
                            <td>TOTAL</td>
                            <td>$<?php echo e($mailData['product_price']); ?></td>
                        </tr>
                    </table>
                </td>
            </tr>
            <tr>
                <td><b>Message</b></td>
                <td>:</td>
                <td><?php echo e($mailData['message']); ?></td>
            </tr>
        </table> 
        <?php elseif($mailData['body_type'] =='request_user'): ?>
        <p>
        Dear <?php echo e($mailData['name']); ?>, <br><br>
    
        Thank you for showing interest. <br><br>
    
        We appreciate your patience and will contact you soon. <br><br>
    
        For further more queries, please drop us a mail at <a href='mailto:sales@marknteladvisors.com'>sales@marknteladvisors.com</a> <br>
    
        <a href='https://www.marknteladvisors.com/'>MarkNtel Advisors</a> is a premier market/business research, consulting, and analytics center known for its incessant real-time support. We work 24*7 to ensure that our clients meet their objectives. We deliver <a href='https://www.marknteladvisors.com/services'>research, consulting </a> and <a href='https://www.marknteladvisors.com/data-analytics/'>data analytics </a>services across industries like Information & Communication Technology (ICT), Healthcare, FMCG, FinTech, Aerospace & Defence, Building & Construction Materials, Automotive, Chemicals, Tires, Energy, and Banking & Financial Services among others.
        <br><br>
         Thank You <br>
        Team Markntel
        </p>
        <?php elseif($mailData['body_type'] =='request'): ?>        

        <table>
            <tr>
                <td><b>Name</b></td>
                <td style="width:50px;">:</td>
                <td><?php echo e($mailData['body']['Name']); ?></td>
            </tr>
            <tr>
                <td><b>Company Name</b></td>
                <td>:</td>
                <td><?php echo e($mailData['body']['Company Name']); ?></td>
            </tr>
            <tr>
                <td><b>Business Email</b></td>
                <td>:</td>
                <td><?php echo e($mailData['body']['Business Email']); ?></td>
            </tr>
            <tr>
                <td><b>Country</b></td>
                <td>:</td>
                <td><?php echo e($mailData['body']['Country_Name']); ?></td>
            </tr>
            <tr>
                <td><b>Contact Number</b></td>
                <td>:</td>
                <td><?php echo e($mailData['body']['Contact_No']); ?></td>
            </tr>
            <tr>
                <td><b>Message</b></td>
                 <td>:</td>
                <td><?php echo e($mailData['body']['Message']); ?></td>
            </tr>
        </table> 
    <?php endif; ?>
    
</body>
</html><?php /**PATH /home/marknteladvisors/public_html/resources/views/emails/request_mail.blade.php ENDPATH**/ ?>
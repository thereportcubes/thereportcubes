
<?php $__env->startSection('title','Thankyou'); ?>
<?php $__env->startSection('content'); ?>

<section class="mini-banner">
   <div class="container">
      <div class="row">
         <div class="col-md-12">
         <h1 class="mb-0 mini-banner-title">Thank You</h1>
         </div>
      </div>
   </div>
</section>

<section class="">
   <div class="container mt-5 mb-5">
      <div class="row box-shadow px-4">
      
         <div class="col-md-12 text-center">
            <div class="card px-2 py-3 mb-4 mt-4">
               <h2 class="fw-800 mb-4">Payment Success</h2>
               <p class="ms-2">
                  Thank You!! Your Payment has been Success.
               </p>
               <div class="col-md-12 "><a href="<?php echo e(url('/')); ?>" class="">Go back to Home Page</a> </div>
               
            </div>
         </div>

         
         
      </div>

      

   </div>
   </section>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout/header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/marknteladvisors/public_html/resources/views/ccavenue_payment_success.blade.php ENDPATH**/ ?>

<?php $__env->startSection('title','Research Report'); ?>

<?php $__env->startSection('content'); ?>

<style>
.modal-content{
   margin-top:100px;
}
.modal-body {
   font-weight: normal;
}
</style>

<section class="mini-banner">
   <div class="container">
      <div class="row">
         <div class="col-md-12">
            <h1 class="mb-0 mini-banner-title">Market Research Report</h1>
         </div>
      </div>
   </div>
</section>

<section class="main-content mb-5 mt-5">
      <div class="container">
         <div class="row">
            <div class="col-md-3 sm-100">
               <?php if(count($data)>0): ?>
               
               <div class="box-shadow gray-bg-light">
                  <div class="category-box">
                     <h6 class="fw-600">Categories</h6>
                     <hr>
                     <div class="accordion">

                       <?php $__currentLoopData = $category; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                        <div class="research-accordion-box">
                           <div class="research-accordion-item">
                              <div class="accordion-text">
                              <a href="<?php echo e(url('research-library')); ?>/<?php echo e($cat->category_url); ?>"><?php echo e($cat->cat_name); ?> </a>
                              </div>
                              <div class="icon-researchs"><i class="fa fa-plus" aria-hidden="true"></i></div>
                           </div>
                           <div class="content_research">
                              <ul class="mb-0 ps-0 cat-submenu">
                              <?php $sub_category = \DB::table('sub_category')->where('cat_id',$cat->id)->get(); ?> 

                              <?php if(count($sub_category)>0): ?>
                              <?php $__currentLoopData = $sub_category; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sub_cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                 <li><a href="<?php echo e(url('research-library/')); ?>/sub-category/<?php echo e($sub_cat->page_url); ?>"><?php echo e($sub_cat->sub_cat_name); ?></a></li>
                              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                              <?php endif; ?>
                              </ul>
                           </div>
                        </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                     </div>
                  </div>
               </div>
              
              <?php endif; ?>
            </div>

            <div class="col-md-9 sm-100">
               <?php if(count($data)>0): ?>
               <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $d): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
               <div class="box-shadow">
                  <div class="row align-items-center mb-3 category-box">
                     <div class="col-md-3">
                        <img src="<?php echo e(url('public/img/market_research_consulting.webp')); ?>" class="img-fluid" alt="Market Research Report">
                     </div>
                     <div class="col-md-9">
                        <a href="<?php echo e(url('research-library')); ?>/<?php echo e(($d->page_url)); ?>" class="fw-600 d-block blue mb-2" target="_blank"><?php echo e($d->title); ?></a>
                        <p class="fs-14 mb-2">
                        <?php //echo ($d->decription !="") ? preg_replace('/\\s\\S*$/', '', substr($d->decription, 0, 250))  : ''; ?>
                        
                        <?php echo substr(html_entity_decode(strip_tags($d->decription)),0,260); ?>
                        
                           <span class="read-more"> 
                              <a href="<?php echo e(url('research-library')); ?>/<?php echo e(($d->page_url)); ?>" class="read-more-small-btn" target="_blank"><i class="fa fa-angle-double-right" aria-hidden="true"></i> Read more</a>
                           </span>
                        </p>
                     </div>
                  </div>
                  <div class="row">
                     <div class="col-md-12">
                        <ul class="catefory-list ps-0 mb-0">
                           <li>
                              <label><i class="fa fa-industry" aria-hidden="true"></i></label>
                              <span><?php echo e($d->cat_name); ?></span>
                           </li>
                           <li>
                              <label> <i class="fa fa-calendar" aria-hidden="true"></i></label>
                              <span> <?php echo e(Carbon\Carbon::parse($d->report_post_date)->format('M Y')); ?></span>
                           </li>
                           <li>
                              <label>Pages</label>
                              <span><?php echo ($d->no_of_page) ? $d->no_of_page : '0' ?></span>
                           </li>
                           <?php if($d->report_code !=''): ?>
                           <li>                              
                              <label>Report Code</label>
                              <span><?php echo ($d->report_code) ? $d->report_code : '---' ?> </span>                             
                           </li>
                           <?php endif; ?>
                           <li>
                              <label>USD</label>
                              <span><?php echo ($d->single_licence_price) ? $d->single_licence_price : '0' ?></span>
                           </li>
                           <li class="last">
                              <div class="add-carts">
                                 <!-- <a href="#" data-toggle="modal" data-target="#placeorder"><i class="fa fa-cart-plus" aria-hidden="true"></i> Add Cart</a> -->
                                 
                                 <a class="cart-btn" href="javascript:void()" onclick="priceModal(<?php echo e($d->id); ?>)"><i class="fa fa-cart-plus"
                                       aria-hidden="true"></i> Add Cart</a>
                              </div>
                           </li>
                        </ul>
                     </div>
                  </div>
               </div>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              <?php endif; ?>

              
               <div class="row">
                  <div class="col-md-12">
                     <nav aria-label="Page navigation example">
                        <?php echo e($data->links('custom_pagination')); ?>

                     </nav>
                  </div>
               </div>
               
            </div>            
         </div>         
      </div>      
   </div>

   <!-- Model !-->

   <div class="modal fade" id="exampleModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
      <div class="modal-dialog">
         <div class="modal-content">
               <div class="modal-header">
                  <h5 class="modal-title" id="exampleModalLabel">Place an order</h5>
                  <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
               </div>
               <div class="modal-body">
                  <div class="d-flex justify-content-between orders fs-14 mb-3">
                     <div class="form-check">
                           <input class="form-check-input excel_data_pack" type="radio" value="" id="flexCheckDefault" name="price_type" checked>
                           <label class="form-check-label" for="flexCheckDefault">
                              Excel Data Pack
                           </label>
                              <span class="tooltips"><i class="fa fa-info-circle"></i><span class="tooltipstext">
                                 This is a Only market data will be provided in the excel spreadsheet.
                                 <span class="caret"></span></span></span>
                     </div>
                     <div>
                           <p class="mb-0" >USD <span id="excel_data_pack"></span></p>
                     </div>
                  </div>
                  <div class="d-flex justify-content-between orders fs-14 mb-3">
                     <div class="form-check">
                           <input class="form-check-input single_user_license" type="radio" value="" id="flexCheckDefault" name="price_type" >
                           <label class="form-check-label" for="flexCheckDefault" >
                              Single User License
                           </label>
                           <span class="tooltips"><i class="fa fa-info-circle"></i><span class="tooltipstext">This
                                 is a
                                 The report will be delivered in PDF format without printing rights. It is
                                 advised for a
                                 single user.<span class="caret"></span></span></span>
                     </div>
                     <div>
                           <p class="mb-0">USD <span id="single_user_license"></span></p>
                     </div>
                  </div>
                  <div class="d-flex justify-content-between orders fs-14 mb-3">
                     <div class="form-check">
                           <input class="form-check-input multi_user_license" type="radio" value="" id="flexCheckDefault" name="price_type">
                           <label class="form-check-label" for="flexCheckDefault">
                              Multi User License
                           </label>
                           <span class="tooltips"><i class="fa fa-info-circle"></i><span class="tooltipstext">This
                                 is a
                                 The report will be delivered in PDF format with printing rights. It is advised
                                 for up
                                 to five users.<span class="caret"></span></span></span>
                     </div>
                     <div>
                           <p class="mb-0">USD <span id="multi_user_license"></span> </p>
                     </div>
                  </div>
                  <div class="d-flex justify-content-between orders fs-14 mb-3">
                     <div class="form-check">
                           <input class="form-check-input enterprise_license" type="radio" value="" name="price_type" id="flexCheckDefault">
                           <label class="form-check-label" for="flexCheckDefault">
                              Enterprise License
                           </label>
                           <span class="tooltips"><i class="fa fa-info-circle"></i><span class="tooltipstext">This
                                 is a
                                 The report will be delivered in PDF format with printing rights and excel sheet.
                                 It is
                                 advised for companies where multiple users would like to access the report from
                                 multiple locations<span class="caret"></span></span></span>
                     </div>
                     <div>
                           <p class="mb-0">USD <span id="enterprise_license"></span></p>
                     </div>
                  </div>
               </div>
               <div class="modal-footer">
                  <input type="hidden" name="idH" value="" id="idH" />
                  <button type="button" class="btn btn-primary" onClick="add_to_cart()">Add To Cart</button>
               </div>
         </div>
      </div>
   </div>
   
</section>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.7.1/jquery.min.js"></script>
<script>
   function priceModal(id){

      $.ajax({
			url : '<?php echo e(route("report-all-amounts")); ?>' ,
			type: 'get',
         data: {'rid':id},
         dataType: "text",
			   success: function(response){
               let res = JSON.parse(response);
               $("#idH").val(id);
               $("#excel_data_pack").html(res.excel_data_pack)
               $("#single_user_license").html(res.single_licence_price)
               $("#multi_user_license").html(res.multi_user_price)
               $("#enterprise_license").html(res.custom_report_price)

               $(".excel_data_pack").val(res.excel_data_pack + "-excel_data_pack")
               $(".single_user_license").val(res.single_licence_price+ "-single_licence_price")
               $(".multi_user_license").val(res.multi_user_price+ "-multi_user_price")
               $(".enterprise_license").val(res.custom_report_price+ "-custom_report_price")
               
               $("#exampleModal").modal('show');    
         }
      });     
   }

   function add_to_cart(){
      
      let report_type_price = $("input[name='price_type']:checked").val();
      
      if(report_type_price == "" || report_type_price === 'undefined'){
         alert('Please Select At-least One Licence Price');
         return false;
      }
      let id = $("#idH").val();
      
      $.ajax({
			url : '<?php echo e(route("add-to-cart-new")); ?>' ,
			type: 'get',
         data: {'id':id, report_type_price: report_type_price},
         dataType: "JSON",
         success: function(response){
            if(response.status == true){
            window.location = "<?php echo e(url('/cart')); ?>";
         }else{
             alert("Already in Cart");
         }
         }
      }); 

   }
</script>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layout/header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\markintal_site\resources\views/research_report_main.blade.php ENDPATH**/ ?>

<?php $__env->startSection('title','Read More'); ?>
<?php $__env->startSection('content'); ?>

<!-- mini banner section -->
<section class="mini-banner">
   <div class="container">
      <div class="row">
         <div class="col-md-12">
            <h1 class="mb-0 mini-banner-title">Page Under Construction</h1>
         </div>
      </div>
   </div>
</section>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout/header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/marknteladvisors/public_html/resources/views/read_more.blade.php ENDPATH**/ ?>
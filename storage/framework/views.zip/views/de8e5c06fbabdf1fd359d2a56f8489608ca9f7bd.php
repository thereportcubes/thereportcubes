<?php echo $__env->yieldContent('title'); ?>
<?php $__env->startSection('content'); ?> 

<main>
   <section id="home-page">
      <div class="ab-body ram ab-page-home ">
         <section class="ab-home-hero ab-bg-dark-blue ab-color-white ab-section home-banner">
            <div class="ab-wrapper ab-align-center">
               <div class="clearfix" style="clear: both;">
                  <h1 class="ab-large-title" style="margin-bottom: 0px;">The Largest Marketplace for Research Reports</h1>
               </div>
               <div id="search-bar-container" class="clearfix center">
                  <div class="clearfix">
                     <form action="#" class="search" id="mainsearch" method="get">
                        <input required="" type="text" name="q" id="q" maxlength="1024" class="search-box" placeholder="Search market reports by industry, keyword, or company name" autocomplete="off">
                        <input type="hidden" name="ac" class="autocomplete" disabled="" value=""><button type="submit" class="search-button searchsubmit"><i class="fa"></i></button>
                     </form>
                  </div>
               </div>
            </div>
         </section>
      </div>
   </section>
   
   <section class="ab-reviews-publishers" style="background-color: #fff !important;">
      <div class="ab-wrapper">
         <h2 class="ab-title ab-align-center">Industries Served</h2>
         <div class="row">
            
            <div class="col-md-3">
               <div class="ab-reviews-publishers-row-left industry-served" >                  
                  <div class="col-md-6 industry-served-logo">
                     <a href="<?php echo e(url('report')); ?>" class="ab-reviews-publishers-image-hyperlink-float" target="_blank">
                     <img loading="lazy" width="50" height="27" src="<?php echo e(asset('assets/icons/health.png')); ?>" alt="Forbes Logo"></a>
                     <p class="mt-2">Healthcare</p>
                  </div>
               </div>
            </div>
            <div class="col-md-3">
               <div class="ab-reviews-publishers-row-left industry-served" >                  
                  <div class="col-md-6 industry-served-logo">
                     <a href="<?php echo e(url('report')); ?>" class="ab-reviews-publishers-image-hyperlink-float" target="_blank">
                     <img loading="lazy" width="50" height="27" src="<?php echo e(asset('assets/icons/energy.png')); ?>" alt="Forbes Logo"></a>
                     <p class="mt-2">Energy & Natural Resources</p>
                  </div>
               </div>
            </div>
            <div class="col-md-3">
               <div class="ab-reviews-publishers-row-left industry-served" >                  
                  <div class="col-md-6 industry-served-logo">
                     <a href="<?php echo e(url('report')); ?>" class="ab-reviews-publishers-image-hyperlink-float" target="_blank">
                     <img loading="lazy" width="50" height="27" src="<?php echo e(asset('assets/icons/it.png')); ?>" alt="Forbes Logo"></a>
                     <p class="mt-2">Information & Technology</p>
                  </div>
               </div>
            </div>
            <div class="col-md-3">
               <div class="ab-reviews-publishers-row-left industry-served">                  
                  <div class="col-md-6 industry-served-logo">
                     <a href="<?php echo e(url('report')); ?>" class="ab-reviews-publishers-image-hyperlink-float" target="_blank">
                     <img loading="lazy" width="50" height="27" src="<?php echo e(asset('assets/icons/chemical.png')); ?>" alt="Forbes Logo"></a>
                     <p class="mt-2">Chemicals and Materials</p>
                  </div>
               </div>
            </div>
            <div class="col-md-3">
               <div class="ab-reviews-publishers-row-left industry-served" >                  
                  <div class="col-md-6 industry-served-logo">
                     <a href="<?php echo e(url('report')); ?>" class="ab-reviews-publishers-image-hyperlink-float" target="_blank">
                     <img loading="lazy" width="50" height="27" src="<?php echo e(asset('assets/icons/food.png')); ?>" alt="Forbes Logo"></a>
                     <p class="mt-2">Food & Beverage</p>
                  </div>
               </div>
            </div>
            <div class="col-md-3">
               <div class="ab-reviews-publishers-row-left industry-served" >                  
                  <div class="col-md-6 industry-served-logo">
                     <a href="<?php echo e(url('report')); ?>" class="ab-reviews-publishers-image-hyperlink-float" target="_blank">
                     <img loading="lazy" width="50" height="27" src="<?php echo e(asset('assets/icons/menufecture.png')); ?>" alt="Forbes Logo"></a>
                     <p class="mt-2">Manufacturing & Construction</p>
                  </div>
               </div>
            </div>
            <div class="col-md-3">
               <div class="ab-reviews-publishers-row-left industry-served" >                  
                  <div class="col-md-6 industry-served-logo">
                     <a href="<?php echo e(url('report')); ?>" class="ab-reviews-publishers-image-hyperlink-float" target="_blank">
                     <img loading="lazy" width="50" height="27" src="<?php echo e(asset('assets/icons/automotive.png')); ?>" alt="Forbes Logo"></a>
                     <p class="mt-2">Automotive & Transport</p>
                  </div>
               </div>
            </div>
            <div class="col-md-3">
               <div class="ab-reviews-publishers-row-left industry-served" >                  
                  <div class="col-md-6 industry-served-logo">
                     <a href="<?php echo e(url('report')); ?>" class="ab-reviews-publishers-image-hyperlink-float" target="_blank">
                     <img loading="lazy" width="50" height="27" src="<?php echo e(asset('assets/icons/consumer.png')); ?>" alt="Forbes Logo"></a>
                     <p class="mt-2">Consumer Goods & Services</p>
                  </div>
               </div>
            </div>

         </div>
      </div>
   </section>
   <section class="ab-home-products ab-bg-subtle-gray ab-section">
      <div id="productListContainer" class="ab-wrapper">
         <h2 class="ab-title ab-align-center">Recently Viewed and Related Products</h2>
         <ul class="ab-products-grid">
            
            <!-- item -->
            <?php if(count($report_data) > 0 ): ?>
            <?php $__currentLoopData = $report_data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rt): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li>
               <a href="<?php echo e(url('report-store')); ?>/<?php echo e($rt->page_url); ?>" class="ab-products-grid-item">
                  <div class="ab-products-grid-item-image ab-product-thumbnail ab-product-thumbnail-3d">
                     <div class="ab-product-thumbnail-3d-book ab-product-thumbnail-3d-book-reverse">
                        <img class="ab-product-thumbnail-image-front" src="https://thereportcube.com/public/uploads/report_images/64be3fae86723.jpg" style="width:115px;height:165px;" title="Global RegTech Market Research Report: Forecast (2023-2028) ">
                        <div class="product-img-box">
                           <span class="image-report" style="color:#fff">Report</span>
                           <h4 class="image-title" style="color: #000;"><?php echo substr(html_entity_decode(strip_tags($rt->title)),0,40); ?></h4>
                           <span class="imag-pages" style="color: #000;"><?php echo e($rt->no_of_page); ?> Pages</span>
                           <span class="book-years" style="color: #000;">-0001</span>
                        </div>
                        <div class="ab-product-thumbnail-image-inside"></div>
                        <img class="ab-product-thumbnail-image-back" src="https://thereportcube.com/uploads/report_images/64be3fae86723.jpg" style="width:115px;height:165px;">
                     </div>
                  </div>
                  <div class="ab-products-grid-item-text">
                     <div class="ab-products-grid-item-type">Report</div>
                     <div class="ab-products-grid-item-title"><?php echo e($rt->title); ?></div>
                     <ul class="ab-products-grid-item-info">
                        <li>Nov -0001</li>
                        <li><?php echo e($rt->no_of_page); ?> Pages </li>
                     </ul>
                     <ul class="ab-products-grid-item-info">
                        <li class="ab-products-list-item-info-price-home"> From <span class="ab-products-list-item-info-price-amount-home">
                           <span class="dynPrice" style=""><span class="currency-2" style="">$2,950</span><span content="USD" style="display: none;">USD</span></span></span>
                        </li>
                     </ul>
                  </div>
               </a>
            </li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php endif; ?>
            
            <!-- /item -->
            
         </ul>
      </div>
   </section>
   <section class="ab-reviews-publishers" style="background-color: #fff !important;">
      <div class="ab-wrapper">
      <h2 class="ab-title">Our Testimonials</h2>
         <div class="row">
            <div class="col-md-4">
               <div class="ab-reviews-publishers-row-left" style=" padding: 10px; padding-top:55px;">
                  
              
                     <div class="col-md-6 review-logo">
                        &nbsp;
                     </div>
                  
                        <div class="col-md-6 review-logo">
                           <img loading="lazy" width="101" height="31" src="<?php echo e(asset('img/clint1.png')); ?>" alt="Time Magazine Logo">
                        </div>
                
                     <div class="col-md-6 review-logo">
                        &nbsp;
                     </div>
              
                        <div class="col-md-6 review-logo">
                           <img loading="lazy" width="101" height="31" src="<?php echo e(asset('img/clint2.png')); ?>" alt="Time Magazine Logo">
                        </div>
                 
               </div>
            </div>
            <div class="col-md-8">
               <div class="ab-reviews-publishers-row-left">
                  <?php if(count($testimonials)>0): ?>
                     <?php $__currentLoopData = $testimonials; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $test): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                     <div class="col-md-6">
                        <div class="review-box">
                           <p class="icon"><i class="fa fa-quote-left" aria-hidden="true"></i></p>
                           <p class="review-p"><?php echo strip_tags($test->description)?></p>
                           <span ><?php echo strip_tags($test->client_name)?></span>
                        </div>
                     </div>
                     <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  <?php endif; ?>
               </div>
            </div>
         </div>
      </div>
   </section>
   
   <section class="ab-about-hero ab-bg-subtle-gray ab-section">
         <div class="ab-wrapper">
            <div class="ab-row ab-row-gap-huge">
               <div class="ab-col ab-col-desktop-6 ab-col-tablet-12" style="text-align: left;">
                     <h2 class="ab-title ">About Us</h2>
                     
                     <div class="ab-about-hero-description" style="margin-top:30px;text-align:justify">
                        <p class="ab-p" >At The Report Cube, we are more than just a market research company; we are your strategic partner in unlocking the insights that drive your business forward. With a passion for data, a commitment to precision, and a dedication to delivering actionable results, we have been a trusted resource for businesses seeking a competitive edge.
                        </p>
                        <p class="ab-p">Our mission is to empower businesses with the knowledge they need to make informed decisions, innovate, and thrive in an ever-evolving marketplace. We believe that data-driven insights are the cornerstone of success, and our team is dedicated to providing you with the highest quality research and analysis to help you stay ahead of the curve.</p>
                        <p class="ab-p">Our Commitment is to your success. We understand the challenges and opportunities that businesses face in today's dynamic environment, and we're here to help you navigate them with confidence. Our work is not just about collecting data; it's about providing you with the knowledge and insights that empower you to make smarter decisions and achieve your business goals.</p>
                     </div>
               </div>
               <div class="ab-col ab-col-desktop-6 ab-col-tablet-12">
                     <div class="ab-about-hero-images">
                        <div class="ab-about-hero-images-item-1 ab-about-hero-images-item"><img loading="lazy"
                                 src="<?php echo e(asset('images/about-3.jpg')); ?>" alt=""
                                 width="450" height="300"></div>
                        
                     </div>
               </div>
            </div>
         </div>
   </section>

   <section class="ab-reviews-publishers" style="background-color: #fff !important;">
      <div class="ab-wrapper">
         <h2 class="ab-title ab-align-center">Our Services</h2>
         <div class="row">
          
         <?php $__currentLoopData = $services; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $service): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col-md-3">
               <div class="ab-reviews-publishers-row-left " >                  
                  <div class="col-md-6 industry-served-logo">
                     <a href="<?php echo e(url('/services')); ?>" class="ab-reviews-publishers-image-hyperlink-float" target="_blank">
                     <img loading="lazy" src="<?php echo e(asset('uploads/services')); ?>/<?php echo e($service->services_image); ?>" width="50" height="27" data-src="<?php echo e(asset('uploads/services')); ?>/<?php echo e($service->services_image); ?>" alt="Forbes Logo"></a>
                     <p class="ab-color-primary mt-2"><?php echo e($service->service_name); ?></p>
                     <p class="mt-2"><?php echo e($service->services_desc); ?></p>
                  </div>
               </div>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    

         </div>
      </div>
   </section>

   <section class="ab-home-news ab-section">
      <div class="ab-wrapper">
         <div class="ab-clearfix" style="padding: 0px 15px;">
            <h2 class="ab-title ab-align-center">Latest Press Release</h2>            
         </div>
         <div class="ab-news-grid ab-row ab-row-v-padding">
            <?php $__currentLoopData = $press_release; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pr): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="ab-col ab-col-desktop-3 ab-col-tablet-3 ab-col-phone-12">
               <a href="#" class="ab-news-grid-item">
                  <div class="ab-news-grid-item-image" style="background-image: url(/images/new1.webp);">
                  </div>
                  <div class="ab-news-grid-item-text">
                     <div class="ab-news-grid-item-date"><?php echo e(Carbon\Carbon::parse($pr->post_date)->format('D, M Y')); ?> </div>
                     <div class="ab-news-grid-item-title"><?php echo e($pr->heading); ?>

                     </div>
                  </div>
                  <div class="ab-news-grid-item-excerpt"> <?php echo substr(html_entity_decode(strip_tags($pr->description)),0,260).'...'; ?> 
                  </div>
               </a>
            </div>
            
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
         </div>
      </div>
   </section>
</main>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.newheader', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u171619165/domains/vishalghosh.com/public_html/stagingrcube/site/resources/views/home3.blade.php ENDPATH**/ ?>
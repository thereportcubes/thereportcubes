<ul class="pagination mb-0">
    <?php if($paginator->onFirstPage()): ?>
        <li class="page-item" aria-label="Previous"><span><i class="icon-west"></i></span></li>
    <?php else: ?>
        <li class="page-item"><a href="<?php echo e($paginator->previousPageUrl()); ?>"  aria-label="Previous" class="page-link"><i class="icon-west"></i>Previous</a></li>
    <?php endif; ?>

    <?php $__currentLoopData = $elements; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $element): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php if(is_string($element)): ?>
            <li class="page-item"><span><?php echo e($element); ?></span></li>
        <?php endif; ?>
        <?php if(is_array($element)): ?>
            <?php $__currentLoopData = $element; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $page => $url): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php if($page == $paginator->currentPage()): ?>
                    <li class="active page-item"><a href="<?php echo e($url); ?>" class="page-link"><span><?php echo e($page); ?></span></a></li>
                <?php else: ?>
                    <li class="page-item"><a href="<?php echo e($url); ?>" class="page-link"><?php echo e($page); ?></a></li>
                <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php endif; ?>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    
    <?php if($paginator->hasMorePages()): ?>
        <li class="page-item"><a href="<?php echo e($paginator->nextPageUrl()); ?>" aria-label="Next" class="page-link"><i class="icon-east"></i>Next</a></li>
    <?php else: ?>
        <li class="page-item"><i class="icon-east"></i></li>
    <?php endif; ?>
</ul><?php /**PATH C:\wamp64\www\markintal_site\resources\views/custom_pagination.blade.php ENDPATH**/ ?>

<?php $__env->startSection('title','Upcoming Report'); ?>

<?php $__env->startSection('content'); ?>

<style>
.modal-content{
   margin-top:100px;
}
.modal-body {
   font-weight: normal;
}
</style>

<section class="mini-banner">
   <div class="container">
      <div class="row">
         <div class="col-md-12">
            <h1 class="mb-0 mini-banner-title"><?php echo e($rigion1->region_name); ?></h1>
         </div>
      </div>
   </div>
</section>

<section class="main-content mb-5 mt-5">
      <div class="container">
         <div class="row">
       <div class="col-md-3 sm-100">

    <div class="filter">
        <h3 style="font-size: 18px; padding-bottom: 15px; font-weight:bold; color: var(--primary-color);">Categories</h3>

            <?php $__currentLoopData = $sidebar_category; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="filter-item">
                           <a href="<?php echo e(url('report-store')); ?>/<?php echo e($cat->category_url); ?>" class="filter-cate-tilte" ata-toggle="collapse" data-parent="#accordionMenu" 
                              aria-expanded="false" aria-controls="collapse_1"><input type="checkbox" name="catchk"  onclick="window.location.href='<?php echo e(url('report-store')); ?>/<?php echo e($cat->category_url); ?>';" value="<?php echo e($cat->cat_name); ?>">  <?php echo e($cat->cat_name); ?>   
                           </a>
                           <div id="collapse_1" class="panel-collapse in collapse" role="tabpanel" aria-labelledby="headingOne_1" style=" display:none;">
                              <div class="panel-body">
                                 <?php $sub_category = \DB::table('sub_category')->where('cat_id',$cat->id)->get(); ?> 

                                 <?php if(count($sub_category)>0): ?>
                                 <?php $__currentLoopData = $sub_category; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sub_cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li><input type="checkbox" name="catchk" value="<?php echo e($cat->cat_name); ?>"> <a href="<?php echo e(url('report-store')); ?>/<?php echo e($cat->category_url); ?>" ><?php echo e($sub_cat->sub_cat_name); ?></a></li>
                                 <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                 <?php endif; ?>
                              </div>
                           </div>
                        </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

          <!--  <div class="filter mt-4">
               <h3 style=" font-size: 18px; padding-bottom: 15px; color: var(--primary-color);">Countries</h3>

                    <?php $__currentLoopData = $region; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <div class="filter-item">
                      <a href="<?php echo e(url('report-store/category')); ?>/<?php echo e($cat->category_url); ?>" class="filter-cate-tilte" ata-toggle="collapse" data-parent="#accordionMenu" 
                              aria-expanded="false" aria-controls="collapse_2">
                              <input type="checkbox" name="region"  onclick="updateResults()" value="<?php echo e($cat->id); ?>"> <?php echo e($cat->region_name); ?>   
                           </a>
                        <div id="collapse_2" class="panel-collapse in collapse" role="tabpanel" aria-labelledby="headingOne_1" style=" display:none;">
                              <div class="panel-body">
                                 <?php $country = \DB::table('country')->where('region_id',$cat->id)->get(); ?> 

                                 <?php if(count($country)>0): ?>
                                 <?php $__currentLoopData = $country; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sub_cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li><a href="<?php echo e(url('report-store/')); ?>/country/<?php echo e($sub_cat->page_url); ?>"><?php echo e($sub_cat->country_name); ?></a></li>
                                 <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                 <?php endif; ?>
                              </div>
                           </div> 
                        </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                     </div>  -->
                           <div class="filter mt-4">
                                 <h3 style="font-size: 18px; padding-bottom: 15px; color: var(--primary-color);">Countries</h3>

                            <?php $__currentLoopData = $region; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $regn): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                  <div class="filter-item">
                                    <label style="font-weight: 600;
                                  color: black;">
                                    <input type="checkbox" class="filter-cate-tilte" name="region" onclick="window.location.href='<?php echo e(url('report-store')); ?>/<?php echo e($regn->page_url); ?>';" value="<?php echo e($regn->id); ?>" onchange="updateResults(this)" <?php echo e($rigion1->id == $regn->id ? 'checked' : ''); ?>  >
                             <?php echo e($regn->region_name); ?>

                          </label>
                           </div>
                           <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                              </div>

</div>
             
      </div>  

           
                  <div class="col-md-9">
                     <div class="relatedProductsList">
                     <?php if(count($data)>0): ?>
                        <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $d): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                           <div class="product-item-small product-item-mobile clearfix">
                              <div class="product-item-content">
                                 <div class="ab-product-thumbnail-book-binder left">
                                    <div class="product-img-box">
                                       <span class="image-report" style="color:#000;top: 7px;left: 3px;font-size: 6px;">Report</span>
                                       <h4 class="image-title" style="color: #fff;top: 20px;font-size: 6px;text-align: left;width: 50px;left: 5px;">
                                       <?php echo e($d->cat_name); ?>                        
                                       </h4>
                                       <span class="imag-pages" style="color: #fff;font-size: 4px;left: 5px;bottom: 5px;"><?php echo ($d->no_of_page) ? $d->no_of_page : '0' ?> pages</span>
                                       <span class="book-years" style="color: #fff;font-size: 10px;right: 18px;bottom: 3px;">-0002</span>
                                    </div>
                                    <img loading="lazy" class="nonGenericproductSmallImage"src="<?php echo e(asset('img/reportimg.jpg')); ?>"  width="60" height="86">
                                 </div>
                                 <div class="content" style="text-align: left; margin-right: 10px;">
                                    <h3 class="title bold"><a href="<?php echo e(url('report-store')); ?>/<?php echo e(($d->page_url)); ?>" style="color:var(--primary-color);"><?php echo e($d->title); ?></a></h3>
                                    <p style="margin-bottom: 10px;"><?php echo substr(html_entity_decode(strip_tags($d->decription)),0,260); ?></p><br>
                                    <ul class="product-item-list">
                                       <li class="first"> <img  style="margin-right:5px;" alt="PDF Icon" src="<?php echo e(asset('/assets/images/icon-PDF.webp')); ?>" srcset="<?php echo e(asset('/assets/images/icon-PDF.webp')); ?>" width="20"> Report </li>
                                       <li> <?php echo ($d->no_of_page) ? $d->no_of_page : '0' ?> Pages </li>
                                       <li id="publicationDateItemId_related_products_5807230" class="publicationDateItem"><?php echo e(Carbon\Carbon::parse($d->created_at)->format('M Y')); ?></li>
                                       <li class="last"><a  class="report-read-more"href="<?php echo e(url('report-store')); ?>/<?php echo e(($d->page_url)); ?>">Read More</a></li>
                                    </ul>
                                 </div>
                              </div>
                           </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                     <?php endif; ?>

                        <ul class="pagination clearfix" id="paginationBottom">
                           <li class="page-count"><strong><span><?php echo e(count($data)); ?></span> Results</strong> (Page 1 of <?php echo e(ceil(count($data)/10)); ?> ) </li>

                           <li class="pager-btn-container">
                              <?php echo e($data->links('custom_pagination')); ?>

                           </li>
                        </ul>
                     </div>
                  </div>              
       
   </div>

 

</section>

<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.7.1/jquery.min.js"></script>
<script>
   function priceModal(id){

      $.ajax({
			url : '<?php echo e(route("report-all-amounts")); ?>' ,
			type: 'get',
         data: {'rid':id},
         dataType: "text",
			   success: function(response){
               let res = JSON.parse(response);
               $("#idH").val(id);
               $("#excel_data_pack").html(res.excel_data_pack)
               $("#single_user_license").html(res.single_licence_price)
               $("#multi_user_license").html(res.multi_user_price)
               $("#enterprise_license").html(res.custom_report_price)

               $(".excel_data_pack").val(res.excel_data_pack + "-excel_data_pack")
               $(".single_user_license").val(res.single_licence_price+ "-single_licence_price")
               $(".multi_user_license").val(res.multi_user_price+ "-multi_user_price")
               $(".enterprise_license").val(res.custom_report_price+ "-custom_report_price")
               
               $("#exampleModal").modal('show');    
         }
      });     
   }

   function add_to_cart(){
      
      let report_type_price = $("input[name='price_type']:checked").val();
      
      if(report_type_price == "" || report_type_price === 'undefined'){
         alert('Please Select At-least One Licence Price');
         return false;
      }
      let id = $("#idH").val();
      
      $.ajax({
			url : '<?php echo e(route("add-to-cart-new")); ?>' ,
			type: 'get',
         data: {'id':id, report_type_price: report_type_price},
         dataType: "JSON",
success: function(response){
    console.log(response);
    if(response.status == true){
    window.location = "<?php echo e(url('/cart')); ?>";
 }else{
     alert("Already in Cart");
 }
 }
      }); 

   }

   
     $(document).ready(function() {
    $('.filter-cate-tilte').click(function(event) {
      event.preventDefault(); 
      

      $(this).attr('aria-expanded', function(_, attr) {
        return attr === 'true' ? 'false' : 'true';
      });
 
      $(this).next('.panel-collapse').slideToggle();
    });
  });
</script>

<!-- <script>
   function updateResults(checkbox) {
        var selectedCategories = [];
        var selectedRegions = [];

        var selectedCategories = [];
        document.querySelectorAll('input[name="catchk"]:checked').forEach(function(element) {
            selectedCategories.push(element.value);
        });

        // Get selected regions
        var selectedRegions = [];
        document.querySelectorAll('input[name="catchk"]:checked').forEach(function(element) {
            selectedRegions.push(element.value);
        });
       alert(selectedCategories);
        // Make AJAX request
        $.ajax({
            url: "<?php echo e(route('update-results')); ?>",
            type: "POST",
            data: {
                categories: selectedCategories,
                regions: selectedRegions,
                _token: '<?php echo e(csrf_token()); ?>'
            },
            success: function(response) {
                // Update the content with the received data
                $('#updatedResults').html(response);
            },
            error: function(xhr, status, error) {
                console.error(error);
            }
        });
    }
</script>
 -->
<!-- <script>
   function updateCategoryResults(checkbox) {
    var selectedCategories = [];
    document.querySelectorAll('input[name="category"]:checked').forEach(function(element) {
        selectedCategories.push(element.value);
    });

    // Make an AJAX call to update the results for categories
    updateResults(selectedCategories);
}

function updateRegionResults(checkbox) {
    var selectedRegion = checkbox.value;

    // Make an AJAX call to update the results for regions
    updateResults(selectedRegion);
}

  function updateResults(selectedItems) {
    // Get the CSRF token from the meta tag
    var csrfToken = document.querySelector('meta[name="csrf-token"]').getAttribute('content');

    // Make an AJAX call to update the results
    $.ajax({
        url: "<?php echo e(route('update-results')); ?>",
        type: "POST",
        data: { 
            items: selectedItems,
            // Include the CSRF token in the request headers
            _token: csrfToken
        },
        success: function(response) {
            // Update the UI with the updated results
            // For example, replace the current results with the updated results
            // Assuming you have a div with id="results" to display the results
            $('.relatedProductsList').html(response);
        },
        error: function(xhr, status, error) {
            console.error(error);
        }
    });
}
</script> -->
<script>
function updateResults() {
    var selectedRegions =[];
    var selectedCategories = [];

    // Gather selected regions
    document.querySelectorAll('input[name="region"]:checked').forEach(function(element) {
        selectedRegions.push(element.value);
    });

    // Gather selected categories
    document.querySelectorAll('input[name="category"]:checked').forEach(function(element) {
        selectedCategories.push(element.value);
    });

    // Get the CSRF token from the meta tag
    var csrfToken = document.querySelector('meta[name="csrf-token"]').getAttribute('content');

    // Make an AJAX call to update the results
    $.ajax({
        url: "<?php echo e(route('update-results')); ?>",
        type: "POST",
        data: { 
            regions: selectedRegions,
            categories: selectedCategories,
            _token: csrfToken
        },
        success: function(response) {
            // Update the UI with the updated results
            $('.relatedProductsList').html(response);
        },
        error: function(xhr, status, error) {
            console.error(error);
        }
    });
}
</script>

<?php $__env->stopSection(); ?>


<?php echo $__env->make('layout/header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u171619165/domains/vishalghosh.com/public_html/stagingrcube/site/resources/views/regionreport.blade.php ENDPATH**/ ?>
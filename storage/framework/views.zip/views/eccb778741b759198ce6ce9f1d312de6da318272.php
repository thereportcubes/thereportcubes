<section class="footer py-5">
   <div class="container">
      <div class="row">
         <div class="col-md-3 mb-4 mb-md-4 mb-lg-0">               
            <div>
               <div class="footer-logo">
              </div>
            </div>
            <div class="mt-lg-4">
               <ul class="footer-socail" >
                  <li><a target="_blank" href="https://www.facebook.com/MarkNteladvisors1" rel="noopener noreferrer" aria-label="Facebook"><i class="fa fa-facebook"></i></a></li>
                  <li><a target="_blank" href="https://linkedin.com/company/markntel-advisors" rel="noopener noreferrer" aria-label="Linkedin"><i class="fa fa-linkedin"></i></a></li>
                  <li><a target="_blank" href="https://twitter.com/markntel" rel="noopener noreferrer"><i class="fa fa-twitter" aria-label="Twitter"></i></a></li>
                  <li><a target="_blank" href="https://www.youtube.com/c/MarkNtelAdvisorsLLP" rel="noopener noreferrer" aria-label="Youtube"><i class="fa fa-youtube-play"></i></a></li>
                  <li><a target="_blank" href="https://in.pinterest.com/marknteladvisors" rel="noopener noreferrer" aria-label="Pinterest"><i class="fa fa-pinterest"></i></a></li>                     
               </ul>
            </div>   
            <div class="mt-lg-5">
               <img  src ="<?php echo e(url('public/img/1.png')); ?>" data-src="<?php echo e(url('public/img/paypal-crcard.webp')); ?>" class="img-fluid footer-paypal lazy" alt="" width="251" height="90" />
            </div>            
         </div>
         <div class="col-md-3 mb-4 mb-md-4 mb-xl-0 footer-links">
            <div>
               <h4 class="footer_heading">Quick Links</h4>
               <ul class="footer-menu">
                  <li><a href="<?php echo e(url('/about-us')); ?>" rel="noopener noreferrer" aria-label="About Us">About Us</a></li>
                  <li><a href="<?php echo e(url('/careers')); ?>" rel="noopener noreferrer" aria-label="Careers">Careers</a></li>
                  <li><a href="<?php echo e(url('/contact-us')); ?>" rel="noopener noreferrer" aria-label="Contact Us">Contact Us</a></li>
                  <li><a href="<?php echo e(url('/blogs')); ?>" rel="noopener noreferrer" aria-label="Our Blog">Our Blogs</a></li>
               </ul>
            </div>
         </div>
         <div class="col-md-3 mb-4 mb-md-0 footer-links">
            <div>
               <h4 class="footer_heading">Product & Services</h4>
               <ul class="footer-menu">
                  <li><a href="<?php echo e(url('research-library')); ?>" rel="noopener noreferrer" aria-label="Research Reports" >Research Reports</a></li>
                  <li><a href="<?php echo e(url('upcoming-reports')); ?>" rel="noopener noreferrer" aria-label="Upcoming Reports" >Upcoming Reports</a></li>
                  <li><a href="<?php echo e(url('press-release')); ?>" rel="noopener noreferrer" aria-label="Press Release" >Press Release</a></li>
                  <li><a href="<?php echo e(url('infographics')); ?>" rel="noopener noreferrer" aria-label="Infographics" >Infographics</a></li>
               </ul>
            </div>
         </div>
         <div class="col-md-3 mb-4 mb-md-0 footer-links">
            <h4 class="footer_heading">Contact Us</h4>
            <div class="mb-3">
               <ul>
                  <li><a href="tel:+1 628 895 8081," rel="noopener noreferrer" aria-label="Phone"><i class="fa fa-phone pe-1" aria-hidden="true"></i> +1 628
                        895 8081, +91 120 4278433</a>
                  </li>
                  <li><a href="mailto:sales@marknteladvisors.com" rel="noopener noreferrer" aria-label="email" ><i class="fa fa-envelope pe-1"
                           aria-hidden="true"></i>
                        sales@marknteladvisors.com</a>
                  </li>
                  <li><a href="<?php echo e(url('contact-us')); ?>" rel="noopener noreferrer" aria-label="Contact" ><i class="fa fa-globe pe-1" aria-hidden="true"></i> Corporate Office:
                        Office No.106, <br> H-160, Sector 63, Noida, Uttar Pradesh - 201301, India</a>
                  </li>
               </ul>
            </div>
            
         </div>
      </div>
   </div>
   </div>

</section>

<section class="copy_right_section py-3">
   <div class="container">
      <div class="row">
         <div class="col-md-12">
            <div class="copyright-bar d-flex justify-content-between">
               <div>
                  <p class="mb-0 white">&#169; Copyright <?php echo date('Y');?> MarkNtel Advisors LLP - All Rights Reserved</p>
               </div>
               <div>
                  <ul class="mb-0 p-0">
                     <li class="d-inline-block ps-2"><a href="<?php echo e(url('/privacy-policy')); ?>" rel="noopener noreferrer" aria-label="Privacy Policy">Privacy Policy
                        </a>
                     </li>
                     <li class="d-inline-block ps-2">|</li>
                     <li class="d-inline-block ps-2">
                        <a href="<?php echo e(url('/terms-conditions')); ?>" rel="noopener noreferrer" aria-label="Terms and Conditions">Terms and Conditions</a>
                     </li>
                  </ul>
               </div>
            </div>
         </div>
      </div>
   </div>
</section> 
 <!-- ==================Cookies ======================!-->
  <section class="report-section" id="display_cookies">
 </section>
  <button onclick="topFunction()" id="myBtn" title="Go to top">  
     <img class="img-fluid lazy"  src ="<?php echo e(url('public/img/1.png')); ?>" data-src="<?php echo e(url('public/img/angle-up.webp')); ?>" />
 </button>
 <script>
    var base_path = "<?php echo e(url('/')); ?>/";
    var base_url = "<?php echo e(url('/')); ?>/";
    var google_captch_service =  '<?php echo e(config('services.recaptcha.key')); ?>';
</script>
<script src="<?php echo e(url('public/js/jquery-3.6.4.min.js')); ?>"></script>
<script type="text/javascript" src="<?php echo e(url('public/js/jquery.lazy.min.js')); ?>"></script>
<script src="<?php echo e(url('public/js/include.js')); ?>"></script>
 <script>
    $('document').ready(function(){ 
         setTimeout(() => { $('.lazy').lazy();
        }, 1000);
    });
</script>
   
</body>
</html><?php /**PATH /home/marknteladvisors/public_html/resources/views/layout/footer_new.blade.php ENDPATH**/ ?>

<?php $__env->startSection('title','Edit Press Release'); ?>
<?php $__env->startSection('content'); ?>
<!-- begin app-main -->
<div class="app-main" id="main">
   <!-- begin container-fluid -->
   <div class="container-fluid">
      <!-- begin row -->
      <div class="row">
         <div class="col-md-12 m-b-30">
            <!-- begin page title -->
            <div class="d-block d-sm-flex flex-nowrap align-items-center">
               <!-- <div class="page-title mb-2 mb-sm-0">
                  <h1>MemberShip</h1>
                  </div> -->
               <div class="ml-auto d-flex align-items-center">
                  <nav>
                     <ol class="breadcrumb p-0 m-b-0">
                        <li class="breadcrumb-item">
                           <a href="<?php echo e(url('admin/dashboard')); ?>"><i class="ti ti-home"></i></a>
                        </li>
                        <li class="breadcrumb-item">
                           
                        </li>
                        <li class="breadcrumb-item active text-primary" aria-current="page">Edit Press Release Upload</li>
                     </ol>
                  </nav>
               </div>
            </div>
            <!-- end page title -->
         </div>
      </div>
      <!-- end row -->
      <!-- begin row -->
      <div class="row">
         <div class="col-xl-12">
            <div class="card card-statistics">
               <div class="card-header">
                  <div class="card-heading">
                     <div class="row">
                        <div class="col-md-10">
                           <h4 class="card-title">Edit Press Release</h4>
                        </div>
                        <div class="col-md-2">&nbsp;</div>
                     </div>
                  </div>
               </div>
               <div class="card-body">
                  <?php if(session()->has('success')): ?>
                  <div class="alert-success" style="padding:18px;border-radius: 5px;">
                     <strong>Success!</strong> <?php echo e(session()->get('success')); ?>

                  </div>
                  <br>
                  <?php endif; ?>
                  <?php if(session()->has('error')): ?>
                  <div class="alert-danger" style="padding:18px;border-radius: 5px;">
                     <strong>Warning!</strong> <?php echo e(session()->get('error')); ?>

                  </div>
                  <br>
                  <?php endif; ?>
                  <form action="<?php echo e(url('admin/update_press_release')); ?>/<?php echo e(request()->segment(3)); ?>" id="myForm" method="post" enctype="multipart/form-data">
                     <?php echo csrf_field(); ?>
                     <div class="form-row">
                        <div class="form-group col-md-12">
                           <label for="title">Heading *</label>
                           <input type="text" name="heading" value="<?php echo e($list->heading); ?>" placeholder="Title" class="form-control" required="required"  id="title">
                        </div>
                        <div class="form-group col-md-6">
                           <label for="title">Post Date *</label>
                           <input type="date" name="post_date" value="<?php echo e($list->post_date); ?>" class="form-control" required="required"  id="post_date">
                        </div>
                        
                        <div class="form-group col-md-12">
                           <label for="description">Description</label>
                           <textarea  class="form-control ckeditor" name="description" ><?php echo e($list->description); ?></textarea>
                        </div>
                        <div class="form-group col-md-12">
                           <label for="description">Description2</label>
                           <textarea class="form-control ckeditor" name="description2"><?php echo e($list->description2); ?></textarea>
                        </div>
                        <div class="form-group col-md-12">
                           <label for="title">Press Release Url *</label>
                           <input type="text" name="press_release_url" value="<?php echo e($list->press_release_url); ?>" placeholder="press release url" class="form-control" id="press_release_url">
                        </div>
                        <div class="form-group col-md-12">
                           <label for="title"> Report Url *</label>
                           <input type="text" name="report_url" value="<?php echo e($list->button_refrence); ?>" placeholder="report-url" class="form-control"  id="title">
                        </div>
                        <div class="form-group col-md-12">
                           <label for="page">Seo Title</label>
                           <input type="text" name="seo_title" value="<?php echo e($seo_content->seo_title); ?>" placeholder=" seo title" class="form-control" id="seo_title">
                           <input type="hidden" name="page_type" class="form-control" id="page_type" value = "press_release">
                        </div>
                        <div class="form-group col-md-6">
                           <label for="page">Seo Description</label>
                           <textarea class="form-control" name="seo_description" rows = "4" cols="50"><?php echo e($seo_content->seo_description); ?></textarea>
                        </div>
                        <div class="form-group col-md-6">
                           <label for="page">Seo Key Words</label>
                           <textarea class="form-control" name="seo_keyword" rows = "4" cols="50"><?php echo e($seo_content->seo_key_words); ?></textarea>
                        </div>
                        <div class="form-group col-md-12 text-left">
                           <label></label>
                           <button type="submit" name = "update_press_release" class="btn btn-warning">Update <i class="glyphicon glyphicon-send"></i></button>
                        </div>
                        <div class="form-group col-md-6 text-center">
                        </div>
                     </div>
                  </form>
               </div>
            </div>
         </div>
      </div>
      <!-- end row -->
   </div>
   <!-- end container-fluid -->
</div>
<!-- end app-main -->

<script src="https://cdn.ckeditor.com/4.5.7/full/ckeditor.js"></script>

<script>

  CKEDITOR.replace( 'description' , {
              // filebrowserBrowseUrl : '/browser/browse/type/all',
              filebrowserUploadUrl: '/media/upload/type/all',
              // filebrowserImageBrowseUrl : '/public/media',
              filebrowserImageUploadUrl: 'https://www.marknteladvisors.com/admin/Add_report/upload_image_description_ckeditor',
              filebrowserWindowWidth: 800,
              filebrowserWindowHeight: 500
          });
  CKEDITOR.replace( 'Description2' , {
              // filebrowserBrowseUrl : '/browser/browse/type/all',
              filebrowserUploadUrl: '/media/upload/type/all',
              // filebrowserImageBrowseUrl : '/public/media',
              filebrowserImageUploadUrl: 'https://www.marknteladvisors.com/admin/Add_report/upload_image_description_ckeditor',
              filebrowserWindowWidth: 800,
              filebrowserWindowHeight: 500
          });


</script>

<script type="text/javascript">

CKEDITOR.replace( 'description', {
    extraPlugins: 'imageuploader',
   filebrowserImageBrowseUrl :
    'https://www.marknteladvisors.com/theme/plugins/imageuploader/imgbrowser.php?CKEditor=textarea&CKEditorFuncNum=1&langCode=en-gb'
  
});
</script>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('user/header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/marknteladvisors/public_html/resources/views/user/edit_press_release.blade.php ENDPATH**/ ?>
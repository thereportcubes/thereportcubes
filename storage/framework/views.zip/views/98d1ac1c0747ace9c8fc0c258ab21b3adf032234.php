
<?php $__env->startSection('title','Edit Report Upload'); ?>
<?php $__env->startSection('content'); ?>

<style>
    #selected_data
    {
        /*display:none;*/
    }
	#pm_icons{display: inline-block;}
	i.ti.ti-plus.add {
		margin-left: 5px;
		margin-top: 9px;
		padding: 5px;
		background: #289604;
		color: #fff;
		border-radius: 5%;
		height: 20px;
		width: 20px;
		font-size: 12px;
	}
	a.ti.ti-minus.delete-option {
		margin-left: 10px;
		margin-top: 18px;
		padding: 5px;
		background: #e62d2d;
		color: #fff;
		border-radius: 5%;
		height: 20px;
		width: 20px;
		font-size: 12px;
	}
	.faqs {
		width: 100%;
		display: block;
		clear: both;
	}
	.halfInput{width:46%;float:left;resize:none;}

    #edit_data
    {
        display:block;
    }
        #delete_data
    {
        display:block;
    }
    #edit_data
    {
        display:none;
    }
        #delete_data
    {
        display:none;
    }    
</style>

<!-- begin app-main -->
<div class="app-main" id="main">
    <!-- begin container-fluid -->
    <div class="container-fluid">
        <!-- begin row -->
        <div class="row">
            <div class="col-md-12 m-b-30">
                <!-- begin page title -->
                <div class="d-block d-sm-flex flex-nowrap align-items-center">
                    <!-- <div class="page-title mb-2 mb-sm-0">
                        <h1>MemberShip</h1>
                    </div> -->
                    <div class="ml-auto d-flex align-items-center">
                        <nav>
                            <ol class="breadcrumb p-0 m-b-0">
                                <li class="breadcrumb-item">
                                    <a href="<?php echo e(url('TRC/11/dashboard')); ?>"><i class="ti ti-home"></i></a>
                                </li>
                                <li class="breadcrumb-item">
                                Report Upload
                                </li>
                                <li class="breadcrumb-item active text-primary" aria-current="page">Edit Report Upload</li>
                            </ol>
                        </nav>
                    </div>
                </div>
                <!-- end page title -->
            </div>
        </div>
        <!-- end row -->
        <!-- begin row -->
        <div class="row">
            
            <div class="col-xl-12">
                <div class="card card-statistics">
                    <div class="card-header">
                        <div class="card-heading">
                            <div class="row">
                                <div class="col-md-10"><h4 class="card-title">Edit Report</h4></div>
                                <div class="col-md-2 text-right"><a href=" <?php echo e(route('TRC/11/report_list')); ?>"><button type="button" class="btn btn-info ">All Reports</button></a></div>
                            </div>
                        </div>
                    </div>
                    <div class="card-body">
                        <?php if(session()->has('success')): ?>
                            <div class="alert-success" style="padding:18px;border-radius: 5px;">
                                <strong>Success!</strong> <?php echo e(session()->get('success')); ?>

                            </div><br>
                        <?php endif; ?>
                        <?php if(session()->has('error')): ?>
                            <div class="alert-danger" style="padding:18px;border-radius: 5px;">
                                <strong>Warning!</strong> <?php echo e(session()->get('error')); ?>

                            </div><br>
                        <?php endif; ?>
                        <form action="<?php echo e(route('update_report')); ?>" method="post" id="myForm" enctype="multipart/form-data">
                            <?php echo csrf_field(); ?>
                            <input type="hidden" name="report_id" value="<?php echo e(request()->segment(4)); ?>" />
                            <div class="form-row">
                                <div class="form-group col-md-12">
                                    <label for="title">H1 *</label>
                                    <input type="text" name="title" placeholder="Title" class="form-control" id="title" value="<?php echo e($list->title); ?>">
                                </div>
                                <div class="form-group col-md-12">
                                    <label for="title">H2 *</label>
                                    <input type="text" name="heading2"placeholder="Title" class="form-control" required="required"  id="title2" value="<?php echo e($list->heading2); ?>">
                                </div>
                                <div class="form-group col-md-6">
                                    <label for="category"> Category</label>
                                    <select onchange ="getSubCatData()"  name="category_id" class="form-control" id="category">
                                        <option value="">Select Category</option>
                                        <?php $__currentLoopData = $category; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($cat->id); ?>" <?php if($cat->id == $list->cat_id): ?> <?php echo e("selected"); ?> <?php endif; ?>><?php echo e($cat->cat_name); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>    
                                    </select>
                                </div>
                                <div class="form-group col-md-6">
                                    <label for="subcategory">Sub Category</label>
                                    <select name="subcategory_id" class="form-control" id="subcategory">
                                        <option value=''>Sub-Category</option>
                                        <?php $__currentLoopData = $sub_category; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$sc): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($sc->id); ?>" <?php if($sc->id == $list->sub_cat_id): ?> <?php echo e("selected"); ?> <?php endif; ?>><?php echo e($sc->sub_cat_name); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>
                                <div class="form-group col-md-6">
                                    <label for="region"> Region</label>
                                    <select onchange ="getCountryData()"  name="region_id" class="form-control" id="region" >
                                        <option value="">Select Region</option>
                                        <?php $__currentLoopData = $region; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($cat->id); ?>" <?php if($cat->id == $list->region_id): ?> <?php echo e("selected"); ?> <?php endif; ?>><?php echo e($cat->region_name); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>    
                                    </select>
                                </div>
                                <div class="form-group col-md-6">
                                    <label for="Country">Country</label>
                                    <select name="country_id" class="form-control" id="country" >
                                        <option value=''>Country</option>
                                        <?php $__currentLoopData = $country; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$sc): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($sc->id); ?>" <?php if($sc->id == $list->country_id): ?> <?php echo e("selected"); ?> <?php endif; ?>><?php echo e($sc->country_name); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>
                                <div class="form-group col-md-6">
                                    <label for="page">No. Of Page</label>
                                    <input type="number" name="no_of_page" value="<?php echo e($list->no_of_page); ?>" placeholder="Number of page" class="form-control" id="page">
                                </div>
                                <!-- <div class="form-group col-md-6">
                                    <label for="page">Report Code</label>
                                    <input type="text" name="report_code" value="<?php echo e($list->report_code); ?>" placeholder="Report Code" class="form-control" id="report_code">
                                </div> -->
                                <div class="form-group col-md-6">
                                    <label for="page">Single License Price</label>
                                    <input type="text" name="single_user_license" value="<?php echo e($list->single_licence_price); ?>" placeholder="Single License Price" class="form-control" id="single_user_license">
                                </div>
                                <div class="form-group col-md-6">
                                    <label for="page">Special Single License Price</label>
                                    <input type="text" name="special_single_licence_price"  placeholder="Single License Price" class="form-control" id="special_single_licence_price"  value="<?php echo e($list->special_single_licence_price); ?>">
                                </div>
                                <div class="form-group col-md-6">
                                    <label for="page">Group license Price</label>
                                    <input type="text" name="group_user_license" value="<?php echo e($list->multi_user_price); ?>" placeholder="Group License Price" class="form-control" id="group_user_license">
                                </div>
                                <div class="form-group col-md-6">
                                    <label for="page">Special Group License Price</label>
                                    <input type="text" name="special_multi_user_price"  placeholder="Special Group License Price" class="form-control" id="special_multi_user_price" value="<?php echo e($list->special_multi_user_price); ?>">
                                </div>
                                <div class="form-group col-md-6">
                                    <label for="page">Enterprise License Price</label>
                                    <input type="text" name="group_user_license_2" value="<?php echo e($list->custom_report_price); ?>" placeholder="Enterprise License Price" class="form-control" id="group_user_license_2">
                                </div>
                                <div class="form-group col-md-6">
                                    <label for="page">Special Enterprise License Price</label>
                                    <input type="text" name="special_custom_report_price" placeholder="Special Enterprise License Price" class="form-control" id="special_custom_report_price" value="<?php echo e($list->special_custom_report_price); ?>">
                                </div>
                               <!--  <div class="form-group col-md-6">
                                    <label for="page">Excel Data Pack</label>
                                    <input type="text" name="excel_data_pack" placeholder="Excel Data Pack" class="form-control" id="excel_data_pack" value="<?php echo e($list->excel_data_pack); ?>">
                                </div> -->
                               <!--  <div class="form-group col-md-6">
                                    <label for="page">Special Excel Data Pack</label>
                                    <input type="text" name="special_excel_data_pack" placeholder="Special Excel Data Pack" class="form-control" id="special_excel_data_pack" value="<?php echo e($list->special_excel_data_pack); ?>">
                                </div> -->
                                
                                <div class="form-group col-md-6">
                                    <label for="page">Report Post Date</label>
                                    <input type="date" name="report_post_date" id = "report_post_date" class="form-control" value="<?php echo e($list->report_post_date); ?>">
                                </div>
                                <div class="form-group col-md-3">
                                    <label for="page">Report Status</label>                                    
                                    <div class="checkbox checbox-switch switch-success">
                                        <label>                                               
                                            <input type="checkbox" name="active_inactive" <?php echo ($list->active_inactive == 1) ? 'checked' : ''; ?> >
                                            <span></span>                                           
                                        </label>
                                    </div>
                                </div>
                              <!--   <div class="form-group col-md-3">
                                    <label for="page">Upcoming Report</label>                                    
                                    <div class="checkbox checbox-switch switch-success">
                                        <label>
                                           <input type="checkbox" name="upcomingactive_inactive" <?php echo ($list->upcomingstatus == 1) ? 'checked' : ''; ?> >
                                            <span></span>                                          
                                        </label>
                                    </div>
                                </div> -->
                                <div class="form-group col-md-12">
                                    <label for="description">Description 1</label>
                                    <textarea name="Description"><?php echo e($list->decription); ?></textarea>
                                </div>
                                <div class="form-group col-md-12">
                                    <label for="description">Description 2</label>
                                    <textarea name="Description2" ><?php echo e($list->description_last); ?></textarea>
                                </div>
                                <div class="form-group col-md-3">
                                    <label for="page">Infographic Image</label>
                                    <?php $infoimage = ""; if($infographic_data != "") { $infoimage = $infographic_data->image; } else{$infoimage = ""; } ?>
                                    <input type="file" name="infographic_img" class="form-control" value="">
                                    <input type="hidden" name="infographic_img_H" class="form-control" value="<?php echo e($infoimage); ?>">
                                </div>

                                <div class="form-group col-md-3">
                                    <label for="page">View Image</label>
                                    <br/>
                                    <?php $infoimage = ""; if($infographic_data != "") { ?>
                                    <a href="<?php echo e(url('public/')); ?>/<?php echo e($infographic_data->image); ?>" target="_blank"><img src="<?php echo e(url('public/')); ?>/<?php echo e($infographic_data->image); ?>" width="60" height="40"/></a>
                                    <?php } ?>
                                </div>
                                <div class="form-group col-md-6">
                                         <label for="infographic_title">Infographic Alt</label>
                                             <input type="text" name="infographic_title" placeholder="Infographic title" class="form-control" id="infographic_title" value="<?php echo e($infographic_data->img_alt_tag ?? ''); ?>">
                                        </div>
                                <div class="form-group col-md-12">
                                    <label for="description">Faqs</label>
                                    <div id="faqs">

                                        <?php 
                                            $Faqs = $list->faqs ; 
                                            if($Faqs!=""){
                                                $Faqs = json_decode($Faqs);
                                                $Ques = $Faqs->ques;
                                                $Ans  = $Faqs->ans;
                                                $Length = count($Ques);
                                                for($i=0;$i<$Length;$i++){
                                        ?>

                                        <div class="faqs">
                                            <textarea type="text" placeholder="Question" rows="1" class="form-control halfInput" name="faqs_ques[]"><?php echo $Ques[$i]; ?></textarea>
                                            <textarea type="text" placeholder="Answer" rows="1" class="form-control halfInput" name="faqs_ans[]"><?php echo $Ans[$i]; ?></textarea>
                                            
                                            <?php if($i==0 && $Length>1){ ?>
                                                <div style="text-align:right;visibility:visible;" id="pm_icons" class="pm_icons_first">
                                                        <a href="javascript:" class="ti ti-miuns delete-option" style="display:none;"></a> 
                                                </div>
                                            <?php }elseif($i == $Length-1){ ?>
                                                    <div style="text-align:right;visibility:visible;" id="pm_icons"><a href="javascript:" class="ti ti-minus delete-option" ></a> 
                                                    <a href="javascript:" class="option_add font-14" ><i class="ti ti-plus add"></i></a></div>
                                            <?php } else{ ?>
                                                <div style="text-align:right;visibility:visible;" id="pm_icons"><a href="javascript:" class="ti ti-minus delete-option" ></a> </div>
                                            <?php } ?>

                                        </div>
                                        <?php } } else{ ?>
                                        <div class="faqs">
                                            <textarea type="text" placeholder="Question1" rows="1" class="form-control halfInput" name="faqs_ques[]"></textarea>
                                            <textarea type="text" placeholder="Answer1" rows="1" class="form-control halfInput" name="faqs_ans[]"></textarea>
                                            <div style="" id="pm_icons" class="pm_icons_first">
                                                <a href="javascript:" class="ti ti-miuns delete-option" style="display:none;"></a> 
                                                <a href="javascript:" class="option_add font-14" ><i class="ti ti-plus add"></i></a>
                                            </div>
                                        </div>
                                        <?php } ?>
                                    </div>
                                </div>
                                <br>
                                <div class="form-group col-md-12">
                                    <label for="description">Table of Content</label>
                                    <textarea name="table_of_content"><?php echo e($list->table_of_content); ?></textarea>
                                </div>
                                <div class="form-group col-md-12">
                                    <label for="description">Companies Mentioned</label>
                                    <textarea name="companies_mentioned"><?php echo e($list->companies_mentioned); ?></textarea>
                                </div>
                                
                                <div class="form-group col-md-6">
                                    <label for="page">page Url</label>
                                    <input type="text" name="page_url"  placeholder="Page Url" class="form-control" id="page_url" value="<?php echo e($list->page_url); ?>">
                                </div>
                                
                                <div class="form-group col-md-6">
                                    <label for="page">Schema Description</label>
                                    <textarea type="text" name="schema_desc"  placeholder="Schema Description" class="form-control" id="schema_desc"><?php echo e($list->schema_desc); ?></textarea>
                                </div>
                                <div class="form-group col-md-6">
                                    <label for="page">Review Count</label>
                                    <input type="text" name="review_count"  placeholder="Review Count" class="form-control" id="review_count" value="<?php echo e($list->reviewcount); ?>">
                                </div>
                                <div class="form-group col-md-6">
                                    <label for="page">Rating Value</label>
                                    <input type="text" name="review_value"  placeholder="Rating Value" class="form-control" id="review_value" value="<?php echo e($list->rating_value); ?>">
                                </div>
                                
                                <div class="form-group col-md-12">
                                    <label for="page">Seo Title</label>
                                    <input type="text" name="seo_title"  placeholder=" seo title" class="form-control" id="seo_title" value="<?php echo e($seo_content->seo_title); ?>">
                                    
                                    <input type="hidden" name="page_type" class="form-control" id="page_type" value = "report" >
                                </div>
                                <div class="form-group col-md-6">
                                    <label for="page">Seo Description</label>
                                    <textarea name="seo_description" class="form-control" rows = "4" cols="50"><?php echo e($seo_content->seo_description); ?></textarea>
                                </div>
                                <div class="form-group col-md-6">
                                    <label for="page">Seo Key Words</label>
                                    <textarea name="seo_key_words" class="form-control" rows = "4" cols="50"><?php echo e($seo_content->seo_key_words); ?></textarea>
                                </div>
                                
                                <div class="form-group col-md-6" id = "selected_data">
                                    <label for="page">You are selected</label>
                                    <div id = "se_data">
                                        
                                    </div>
                                </div>
                                
                                <div class="form-group col-md-6">
                                    <label for="page">Releted Report</label>
                                    <input type="text" name = "search_form_admin" id = "search_form_admin"  class="form-control" placeholder="Search..">
                                    <div id="suggesstion-box-admin" style = "display:none;">
                                        <!--<select name = "country-list-admin" id="country-list-admin">-->
                                        <ul id="country-list-admin"></ul>
                                        </select>
                                    </div>
                                </div>

                            </div>
                           
                            <button type="submit" class="btn btn-primary">Update</button>

                        </form>
                    </div>
                </div>
            </div>
            
        </div>
        <!-- end row -->

    </div>
    <!-- end container-fluid -->
</div>
<!-- end app-main -->

<script src="https://cdn.ckeditor.com/4.5.7/full/ckeditor.js"></script>

<script>
   CKEDITOR.replace('Description', {
        filebrowserUploadUrl: '<?php echo e(route("TRC.11.ckeditor.upload", ["_token" => csrf_token()])); ?>',
        filebrowserImageUploadUrl: '<?php echo e(route("TRC.11.ckeditor.upload", ["_token" => csrf_token()])); ?>',
        filebrowserWindowWidth: 800,
        filebrowserWindowHeight: 500,
        on: {
            instanceReady: function() {
                this.on('fileUploadRequest', function(evt) {
                    var xhr = evt.data.fileLoader.xhr;
                    var token = document.querySelector('meta[name="csrf-token"]').getAttribute('content');
                    xhr.setRequestHeader('X-CSRF-TOKEN', token);
                });
            }
        }
    });


     CKEDITOR.replace('Description2', {
        filebrowserUploadUrl: '<?php echo e(route("TRC.11.ckeditor.upload", ["_token" => csrf_token()])); ?>',
        filebrowserImageUploadUrl: '<?php echo e(route("TRC.11.ckeditor.upload", ["_token" => csrf_token()])); ?>',
        filebrowserWindowWidth: 800,
        filebrowserWindowHeight: 500,
        on: {
            instanceReady: function() {
                this.on('fileUploadRequest', function(evt) {
                    var xhr = evt.data.fileLoader.xhr;
                    var token = document.querySelector('meta[name="csrf-token"]').getAttribute('content');
                    xhr.setRequestHeader('X-CSRF-TOKEN', token);
                });
            }
        }
    });
     // Replace table_of_content textarea
    CKEDITOR.replace('table_of_content');

    // Replace companies_mentioned textarea
    CKEDITOR.replace('companies_mentioned');
</script>

<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.4/jquery.min.js"></script>

<script type="text/javascript">

    $(document).ready(function(){
        $('#faqs').delegate('.option_add ','click',function(){
            $('#faqs .option_add').remove();
            var randid = Math.floor(Math.random() * (89562 - 112 + 1) + 112);
            add_condition('faqs',randid);
        });
        $('#faqs').delegate('.delete-option','click',function(){
            $('#faqs .option_add').remove();
            this.parentNode.parentNode.remove();
            $('#faqs .faqs:last-child').find('.delete-option').after('<a href="javascript:" class="option_add font-14"><i class="ti ti-plus add"></i></a>');
        });
    });

    function add_condition(section,randid)
    {
        var opt = document.createElement("div");
        opt.className = 'faqs additional_conditions';
        opt.innerHTML = '<textarea type="text" placeholder="Question" rows="1" required class="form-control halfInput" name="faqs_ques[]"></textarea><textarea type="text" placeholder="Answer" rows="1" required class="form-control halfInput" name="faqs_ans[]"></textarea><div style="text-align:right;visibility:visible;" id="pm_icons"><a href="javascript:" class="ti ti-minus delete-option" ></a> <a href="javascript:" class="option_add font-14" ><i class="ti ti-plus add"></i></a></div>';
        var xx = document.querySelector("#faqs");
        xx.appendChild(opt);
    }
</script>

<script>
    function getSubCatData()
    {
        $("#category").val();
        $.ajax(
        {
            url : '<?php echo e(route("TRC/11/showCategory")); ?>' ,
            data: "cat_id="+$("#category").val(),
            type: 'GET',
            success: function (resp) 
            {
                $("#subcategory").html(resp);
            }
        });
    }
    function getCountryData()
    {
        $("#region").val();
        $.ajax(
        {
            url : '<?php echo e(route("TRC/11/showCountry")); ?>' ,
            data: "region_id="+$("#region").val(),
            type: 'GET',
            success: function (resp) 
            {
                $("#country").html(resp);
            }
        });
    }
</script>

<?php $__env->stopSection(); ?>
           
<?php echo $__env->make('admin/header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /mnt/home2/vvsajqnq/public_html/resources/views/admin/edit_report.blade.php ENDPATH**/ ?>
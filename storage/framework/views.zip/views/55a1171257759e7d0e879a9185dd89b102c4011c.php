
<?php $__env->startSection('title','Upcoming Report'); ?>

<?php $__env->startSection('content'); ?>

<section class="mini-banner">
   <div class="container">
      <div class="row">
         <div class="col-md-12">
            <h1 class="mb-0 mini-banner-title">Press Release</h1>
         </div>
      </div>
   </div>
</section>

<section class="main-content mb-5 mt-5">
      <div class="container">
         <div class="row">

            <div class="col-md-9 sm-100">
               <div class="box-shadow p-0">
                  <h6 class="fw-600 blue-title-bg mb-0">Press Release</h6>
                  
                  <div class="box-content p-3">

                     <?php if(count($press) > 0): ?>
                        <?php $__currentLoopData = $press; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                           <div class="press-releas">
                              <a href="<?php echo e(url('press-release')); ?>/<?php echo e(($p->press_release_url)); ?>" class="press-release-title d-block blue" target="_blank"><?php echo e($p->heading); ?></a>
                              <div><?php //echo ($p->description !="") ? preg_replace('/\\s\\S*$/', '', substr($p->description, 0, 200))  : ''; ?>

                              <?php echo substr(strip_tags($p->description),0, 200);  ?>
                              
                              <span class="read-more"> &nbsp;
                                 <a href="<?php echo e(url('press-release')); ?>/<?php echo e($p->press_release_url); ?>" class="text-warning" target="_blank">Read more</a>
                                 </span>
</div>

                           </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                     <?php endif; ?>
                     
                     <nav aria-label="Page navigation example">
                        <?php echo e($press->links('custom_pagination')); ?>

                     </nav>
                     

                  </div>
               </div>

            </div>
            <div class="col-md-3 sm-100">
               <div class="box-shadow p-0">
                  <h6 class="fw-600 blue-title-bg mb-0"><i class="fa fa-user fs-14" aria-hidden="true"></i> Need Assistance?</h6>


                 <div class="p-3">
                 <div class="mb-2">
                     <p class="mb-0 fs-14">
                        <i class="fa fa-envelope me-2 orrange" aria-hidden="true"></i> WRITE AN EMAIL

                     </p>
                     <a href="mailto:sales@marknteladvisors.com">sales@marknteladvisors.com</a>
                  </div>

                  <div>
                     <p class="mb-0 fs-14"><i class="fa fa-phone me-2 orrange" aria-hidden="true"></i>CALL US</p>
                     <a class="fs-14" href="tel:+1 628 895 8081, +91 120 4278433">+1 628 895 8081, +91 120 4278433</a>
                  </div>
                 </div>

               </div>

               <div class="box-shadow p-0">
                  <h6 class="fw-600 blue-title-bg mb-0"><i class="fa fa-lock me-2 fs-14 "></i>100% Safe & Secure</h6>
                  <div class="p-3">
                  <p class="fs-14">
                     Strongest encryption on the website to make your purchase safe and secure
                  </p>
</div>
               </div>

            </div>
         </div>
      </div>
   </section>

<?php $__env->stopSection(); ?>


<?php echo $__env->make('layout/header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/marknteladvisors/public_html/resources/views/press_release.blade.php ENDPATH**/ ?>

<?php $__env->startSection('title','About Us'); ?>
<?php $__env->startSection('content'); ?>

<section class="mini-banner">
   <div class="container">
      <div class="row">
         <div class="col-md-12">
            <h1 class="mb-0 mini-banner-title">404 Page</h1>
         </div>
      </div>
   </div>
</section>

<section>
      <div class="container mt-5" >
       <div class="row ">
            <div class="text-center mt-4 mb-4">
                <h1>Page Not Found</h1>
                <p>Sorry, the page you are looking for could not be found.</p>
                <a href="<?php echo e(url('/')); ?>"><button class="btn btn-info">Go to Home</button></a>
            </div>
       </div>
      </div>
   </section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout/header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\markintal_site\resources\views/errors/404.blade.php ENDPATH**/ ?>
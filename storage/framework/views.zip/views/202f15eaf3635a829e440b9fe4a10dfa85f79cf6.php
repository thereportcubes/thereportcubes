
<?php echo $__env->yieldContent('title'); ?>
<?php $__env->startSection('content'); ?>
<main class="background-gray">
   <section id="content-infos-pages">
      <section class="ab-title-section ab-bg-dark-red ab-color-white ab-section">
         <div class="ab-title-section-bg" style="background-image: url(/rcube/assent/images/banner.jpg);">
            <div class="ab-section-divider">
               <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 100 100" preserveAspectRatio="none">
                  <polygon points="0,0 100,0 0,100"></polygon>
               </svg>
            </div>
         </div>
         <div class="ab-wrapper">
            <div class="ab-title-section-text">
               <h1 class="ab-large-title">Press Releases</h1>
            </div>
         </div>
      </section>
      <div class="banner-triangle"></div>
   </section>
   <section class="on-going-report ab-section ">
      <div class="ab-wrapper">
         <div class=" product-list-spacing-mobile">
            <div id="product--related-products" class="ab-product-content-section ab-product-content-related-items">
               <div class="relatedProducts">
                  <div class="relatedProductsList" style=" margin-top: 50px;">
                     <?php if(count($press) > 0): ?>
                        <?php $__currentLoopData = $press; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php
                                     $button_ref = $p->button_refrence;
                                     $but_ref = explode('/', $button_ref);
                                     $report_url1 = $but_ref[4] ?? '';
                                       ?>
                           <div class="product-item-small product-item-mobile  press-item">
                           <span class="date"><i class="fa fa-calendar"></i> <?php echo e(Carbon\Carbon::parse($p->post_date)->format('d M Y')); ?> </span>
                           <div class="product-item-content" style=" margin-top: 15px;">
                              <div class="content margin-zero" style="text-align: left;">
                                 <h3 class="title"><a href="<?php echo e(url('press-release')); ?>/<?php echo e($p->press_release_url); ?>" style="color:var(--primary-color);"><?php echo e($p->heading); ?></a></h3>
                                 <p style="margin-bottom: 10px;"><?php echo substr($p->description,0,250) ?>...
                                 </p>
                                 <div class="press-btn-div">
                                    <ul class="press-btn-list">
                                       <li ><a class="press-btn" href="<?php echo e(url('press-release')); ?>/<?php echo e($p->press_release_url); ?>">Read More</a></li>
                                       <li ><a class="press-btn" href="<?php echo e(url('/report-store')); ?>/<?php echo e($report_url1); ?>">View Report</a></li>
                                       <li ><a class="press-btn" href="<?php echo e(url('/request-sample')); ?>/<?php echo e($report_url1); ?>">Request Sample</a></li>
                                    </ul>
                                 </div>
                              </div>
                           </div>
                           </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                     <?php endif; ?>
                     
                     <ul class="pagination clearfix" id="paginationBottom">
                        <li class="page-count"><strong><span><?php echo e(count($press)); ?></span> Results</strong> (Page 1 of <?php echo e(ceil(count($press)/10)); ?> ) </li>

                        <li class="pager-btn-container">
                           <?php echo e($press->links('custom_pagination')); ?>

                        </li>
                     </ul>

                  </div>
               </div>
            </div>
         </div>
      </div>
   </section>
</main>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /mnt/home2/vvsajqnq/public_html/resources/views/press_release.blade.php ENDPATH**/ ?>
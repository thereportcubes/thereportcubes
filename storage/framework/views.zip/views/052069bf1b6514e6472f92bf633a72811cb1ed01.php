
<?php $__env->startSection('title','Upcoming Report'); ?>
<?php $__env->startSection('content'); ?>

<?php  
//echo $report->title;
    // if(isset($infographic) && $infographic->img_alt_tag != ''){
    //     $res = $infographic->img_alt_tag;
    // }
    // else{
    if(!empty($report)){
        $exp_arr = explode('Market', $report->title);
        $res = $exp_arr[0]."Market";
    } else {
        $res = 'Market';
    }
    //}

?>

<section class="mini-banner">
   <div class="container">
      <div class="row">
         <div class="col-md-12">
         <h1 class="mb-0 mini-banner-title">Press Release</h1>
         </div>
      </div>
   </div>
</section>
<section class="main-content mb-5 mt-5">
   <div class="container">
      <div class="row">
         <div class="col-md-9 sm-100">
            <div class="box-shadow">
               <h6 class="fw-600 blue-title-bg">Press Release Description</h6>
               <div class="box-content p-1">
                  <div class="press-releas-description">
                      <?php if($press): ?>
                     <p class="fw-600"> <?php echo e($press->heading); ?></p>
                     <p><?php echo $press->description ?></p>
                     <p><?php if($infographic_image !=""): ?><img src="<?php echo e(url('/public')); ?>/<?php echo e($infographic_image); ?>" width="100%" alt="<?php echo e($res); ?>" /><?php endif; ?></p>
                     <p><?php echo $press->description2 ?></p>
                     <?php endif; ?>
                  </div>
                  <div class="text-center"><a href="<?php echo e(url('/research-library')); ?>/<?php echo e($report_url); ?>"><button class="btn btn-info">Click here to Report</button></a></div>
               </div>
            </div>
         </div>
         <div class="col-md-3 sm-100">
            <div class="box-shadow ">
               <h6 class="fw-600 blue-title-bg">Place an order</h6>
               <div class="d-flex justify-content-between orders fs-14 mb-3">
                  <div class="form-check">
                     <input class="form-check-input" name="price_type" type="checkbox" value="<?php echo e(@$report->excel_data_pack); ?>-Excel_Data_Pack" data-id="<?php echo e(@$report->id); ?>" id="flexCheckDefault">
                     <label class="form-check-label" for="flexCheckDefault">
                     Excel Data Pack
                     </label>
                     <span class="tooltips"><i class="fa fa-info-circle"></i><span class="tooltipstext">
                       
                     Only market data will be provided in the excel spreadsheet.<span
                        class="caret"></span></span></span>
                  </div>
                  <div>
                     <p class="mb-0">USD <?php echo e(@$report->excel_data_pack); ?></p>
                  </div>
               </div>
               <div class="d-flex justify-content-between orders fs-14 mb-3">
                  <div class="form-check">
                     <input class="form-check-input" type="checkbox" value="<?php echo e(@$report->single_licence_price); ?>-Single_User_License"  data-id="<?php echo e(@$report->id); ?>" name="price_type" id="flexCheckDefault">
                     <label class="form-check-label" for="flexCheckDefault">
                     Single User License
                     </label>
                     <span class="tooltips"><i class="fa fa-info-circle"></i><span class="tooltipstext">
                       
                     The report will be delivered in PDF format without printing rights. It is advised for a
                     single user.<span class="caret"></span></span></span>
                  </div>
                  <div>
                     <p class="mb-0">USD <?php echo e(@$report->single_licence_price); ?></p>
                  </div>
               </div>
               <div class="d-flex justify-content-between orders fs-14 mb-3">
                  <div class="form-check">
                     <input class="form-check-input" type="checkbox" value="<?php echo e(@$report->multi_user_price); ?>-Multi_User_License" data-id="<?php echo e(@$report->id); ?>"  name="price_type" id="flexCheckDefault">
                     <label class="form-check-label" for="flexCheckDefault">
                     Multi User License
                     </label>
                     <span class="tooltips"><i class="fa fa-info-circle"></i><span class="tooltipstext">
                       
                     The report will be delivered in PDF format with printing rights. It is advised for up
                     to five users.<span class="caret"></span></span></span>
                  </div>
                  <div>
                     <p class="mb-0">USD <?php echo e(@$report->multi_user_price); ?></p>
                  </div>
               </div>
               <div class="d-flex justify-content-between orders fs-14 mb-3">
                  <div class="form-check">
                     <input class="form-check-input" type="checkbox" data-id="<?php echo e(@$report->id); ?>" value="<?php echo e(@$report->custom_report_price); ?>-Enterprise_License"  name="price_type" id="flexCheckDefault">
                     <label class="form-check-label" for="flexCheckDefault">
                     Enterprise License
                     </label>
                     <span class="tooltips"><i class="fa fa-info-circle"></i><span class="tooltipstext">
                       
                     The report will be delivered in PDF format with printing rights and excel sheet. It is
                     advised for companies where multiple users would like to access the report from
                     multiple locations<span class="caret"></span></span></span>
                  </div>
                  <div>
                     <p class="mb-0">USD <?php echo e(@$report->custom_report_price); ?></p>
                  </div>
               </div>
               <button type="button" class="btn btn-primary small-btn max-100" onclick="add_to_cart()">Buy Now</button>
            </div>
            <div class="btn-groups">
               <a href="<?php echo e(url('query/request-sample')); ?>/<?php echo e($report_url); ?>" class="btn btn-primary small-btn d-inline-block max-100 color-one"><i
                  class="fa fa-hand-pointer" aria-hidden="true"></i>
               Request
               Sample</a>
               <a href="<?php echo e(url('query/talk-to-our-consultant')); ?>/<?php echo e($report_url); ?>" class="btn btn-primary small-btn d-inline-block max-100 color-two"><i
                  class="fa fa-hand-pointer" aria-hidden="true"></i> Talk to our Consultant</a>
               <a href="<?php echo e(url('query/request-customization')); ?>/<?php echo e($report_url); ?>" class="btn btn-primary small-btn d-inline-block max-100 color-three"><i
                  class="fa fa-hand-pointer" aria-hidden="true"></i> Request Customization</a>
            </div>
            <div class="box-shadow">
               <h6 class="fw-600 blue-title-bg"><i class="fa fa-user fs-14" aria-hidden="true"></i> Need Assistance?
               </h6>
               <div class="mb-2">
                  <p class="mb-0 fs-14">
                     <i class="fa fa-envelope me-2 orrange" aria-hidden="true"></i> WRITE AN EMAIL
                  </p>
                  <a href="mailto:sales@marknteladvisors.com">sales@marknteladvisors.com</a>
               </div>
               <div>
                  <p class="mb-0 fs-14"><i class="fa fa-phone me-2 orrange" aria-hidden="true"></i>CALL US</p>
                  <a class="fs-14" href="tel:+1 628 895 8081, +91 120 4278433">+1 628 895 8081, +91 120 4278433</a>
               </div>
            </div>
            <div class="box-shadow">
               <h6 class="fw-600 blue-title-bg"><i class="fa fa-lock me-2 fs-14 "></i>100% Safe & Secure</h6>
               <p class="fs-14">
                  Strongest encryption on the website to make your purchase safe and secure
               </p>
            </div>
         </div>
      </div>
   </div>
</section>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.7.1/jquery.min.js"></script>
   <script>
      function add_to_cart(){
      
      let report_type_price = $("input[name='price_type']:checked").val();
      
      if(report_type_price == "" || report_type_price === 'undefined'){
         alert('Please Select At-least One Licence Price');
         return false;
      }
      let id = $("input[name='price_type']:checked").attr('data-id');
        $.ajax({
			url : '<?php echo e(route("add-to-cart-new")); ?>' ,
			type: 'get',
         data: {'id':id, report_type_price: report_type_price},
         dataType: "JSON",
success: function(response){
    if(response.status == true){
    window.location = "<?php echo e(url('/cart')); ?>";
 }else{
     alert("Already in Cart");
 }
 }
      }); 

   }
   </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout/header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/marknteladvisors/public_html/resources/views/press_release_details.blade.php ENDPATH**/ ?>

<?php $__env->startSection('title','Upcoming Report'); ?>

<?php $__env->startSection('content'); ?>

<style>
   .iti--separate-dial-code{
      width:100%!important;
   }
   #more {display: none;}
</style>
 <link rel="stylesheet" media="all" href="<?php echo e(asset('css/ab-product.css')); ?>"> 
<section class="mini-banner">
   <div class="container">
      <div class="row">
         <div class="col-md-12">
            <h1 class="mb-0 mini-banner-title">Request Sample</h1>
         </div>
      </div>
   </div>
</section>

<section class="main-content mb-5 mt-5">
      <div class="container">
         <div class="row">

            <div class="col-md-9 sm-100">
         <div class="box-shadow">

                  <div class="row  category-box">
                     <div class=" col-md-3">
                        <img src="<?php echo e(asset('/images/global_industrial_automation_market_thumbnail.webp')); ?>" class="img-fluid with-border" alt="Market Research Report">
                     </div>
                     <div class="col-md-9">
                        <a class="fw-600 d-block blue pt-2" href="<?php echo e(url('report-store')); ?>/<?php echo e(($datas->page_url)); ?>"target="_blank"><h1 class="title_heading"><?php echo e($datas->title); ?></h1></a>
                        <p class="fs-14 mb-2">
                           <h2 class="title_descr">
                              <?php echo substr($datas->heading2,0,180); ?><span id="dots">...</span><span id="more"><?php echo trim(substr($datas->heading2,180,2000));  ?>
                              </span>

                              <a href="javascript:void()" onclick="myFunction()" id="myBtn2" class="read-more-small-btn text-danger"> Read more</a>
                           </h2>
                        </p>
                         <ul id="productDetails" class="ab-product-header-info">
                  <li><?php echo e($datas->cat_name); ?></li>                
                  
                  <li>
                     <img alt="PDF Icon" src="<?php echo e(asset('/assets/images/icon-PDF.webp')); ?>"  width="25">  
                     <p>Report</p>
                  </li>
                  <li> <?php echo e($datas->no_of_page); ?> Pages </li>
                  <li id="publicationDateItemId_5395374" class="publicationDateItem" data-result="Thursday, April 6, 2023"><?php echo e(Carbon\Carbon::parse($datas->created_at)->format('M Y')); ?></li>
                  <?php if($datas->report_code !=''): ?>
                  <li>
                     <label>Report ID: </label>
                     <span>&nbsp;<?php echo e($datas->report_code); ?></span>
                  </li>
                  <?php endif; ?>
               </ul>
                     </div>
                  </div>

                  
               </div>

               <div class="box-shadow" style="position:relative;">
                
                  <div class="tab-content" id="myTabContent">
                     <div class="tab-pane fade" id="Overview" role="tabpanel"
                        aria-labelledby="Overview-tab">

                        <div class="tabs-content">
                           <?php echo $datas->decription;  ?>                          
                        </div>

                     </div>
                     <div class="tab-pane fade " id="Content" role="tabpanel" aria-labelledby="Content-tab">
                        <p><?php echo $datas->table_of_content;  ?> </p>
                     </div>
                     <div class="tab-pane fade" id="Segmentation" role="tabpanel" aria-labelledby="Segmentation-tab">
                        <img src="<?php echo e(url('/')); ?>/<?php echo e($datas->segmentaion); ?>" /> 
                     </div>

                        
                     <div class="tab-pane fade show active" id="Request" role="tabpanel" aria-labelledby="Request-tab">

                     <div class="p-4">
                        <?php if(session()->has('success')): ?>
                        <div class="alert-success" style="padding:18px;border-radius: 5px;">
                           <strong>Success!</strong> <?php echo e(session()->get('success')); ?>

                        </div>
                        <br>
                        <?php endif; ?>
                        <?php if(session()->has('error')): ?>
                        <div class="alert-danger" style="padding:18px;border-radius: 5px;">
                           <strong>Warning!</strong> <?php echo e(session()->get('error')); ?>

                        </div>
                        <br>
                        <?php endif; ?>
                          <span class="date"><i class="fa fa-calendar"></i> please share your details to receive a free sample copy</span>
                        <form action="<?php echo e(url('save-request-sample')); ?>" method="post" id="form_request">
                           <?php echo csrf_field(); ?>
                           <input type="hidden" name="request_title" value="<?php echo e($datas->title); ?>" />
                        
                     <div class="row" style="align-items: center;">
                     <div class="col-md-3">
                        <p style="font-size: 16px;">Full Name<span style="color:var(--primary-color)">*</span></p>
                     </div>
                     <div class="col-md-9">
                        <input class="ab-input" type="text" name="full_name" value="<?php echo e(old('full_name')); ?>" placeholder="Enter your name" required>
                     </div>
                  </div>
                  <div class="row" style="align-items: center;">
                     <div class="col-md-3">
                        <p style="font-size: 16px;">Company Name<span style="color:var(--primary-color)">*</span></p>
                     </div>
                     <div class="col-md-9">
                        <input class="ab-input" type="text" name="company_name"  placeholder="Enter your company name" value="<?php echo e(old('company_name')); ?>" required>
                     </div>
                  </div>
                       
                            <div class="row" style="align-items: center;">
                     <div class="col-md-3">
                        <p style="font-size: 16px;">Business Email<span style="color:var(--primary-color)">*</span></p>
                     </div>
                     <div class="col-md-9">
                        <input class="ab-input" type="email"  name="busniess_email" placeholder="Enter your business email" value="<?php echo e(old('busniess_email')); ?>" required>
                     </div>
                  </div>
                 <div class="row" style="align-items: center;">
                     <div class="col-md-3">
                        <p style="font-size: 16px;">Country Name<span style="color:var(--primary-color)">*</span></p>
                     </div>
                     <div class="col-md-9">
                        <input class="ab-input " type="text" maxlength="13" style="height:49px;"  name="country_name" value="<?php echo e(old('country_name')); ?>" placeholder="Enter Your country" required>
                     </div>
                  </div>
                            <div class="row" style="align-items: center;">
                     <div class="col-md-3">
                        <p style="font-size: 16px;">Contact Number<span style="color:var(--primary-color)">*</span></p>
                     </div>
                     <div class="col-md-9">
                        <input class="ab-input mobivali" type="text" maxlength="13" style="height:49px;"  name="phone" value="<?php echo e(old('phone')); ?>" placeholder="Enter Your Contact Number" required> 
                     </div>
                  </div>
                                              
                  <div class="row" style="align-items: center;">
                     <div class="col-md-3">
                        <p style="font-size: 16px;">Message<span style="color:var(--primary-color)">*</span></p>
                     </div>
                     <div class="col-md-9">
                        <textarea class="ab-input"  name="message" cols="10" rows="1" required></textarea> 
                     </div>
                  </div>
                   <div class="row" style="align-items: center;">
                     <div class="col-md-3">
                        
                     </div>
                     <div class="col-md-9">
                       <div class="col-12">
                              <!--<div class="captcha">
                                 <button type="button" class="btn btn-info" class="reload" id="reload">
                                       &#x21bb;
                                 </button>&nbsp;&nbsp;
                                 <span><?php echo captcha_img(); ?></span>                                           
                              </div>-->
                               <div class="g-recaptcha" data-sitekey="<?php echo e(config('services.recaptcha.key')); ?>"></div>
                           </div>
                           <div class="col-12 mt-2">
                              <!--<label class="form-label" for="form3Example4">Captcha*</label>
                              <input type="text" name="captcha" id="captcha" class="form-control" placeholder="Enter Captcha" required />              
                           </div>
                           <?php if($errors->has('captcha')): ?>
                              <span class="text-danger">
                                    <strong><?php echo e($errors->first('captcha')); ?></strong>
                              </span>
                           <?php endif; ?>-->
                           <?php if($errors->has('g-recaptcha-response')): ?>
                                    <span class="help-block">
                                        <strong><?php echo e($errors->first('g-recaptcha-response')); ?></strong>
                                    </span>
                                <?php endif; ?>
                           </div> 
                     </div>
                  </div>
                          
                             
                           <div class="text-center pt-4">
                              <button type="submit" class="btns btn-primary">Submit Request</button>
                           </div>

                           <!-- <input type="hidden" name="country_name" id="country-name"  value="United States" /> -->

                        </form>
                     </div>  
                      </div>
                  </div>
               </div>
            </div>
            <div class="col-md-3 sm-100 ">
               <div class="right-sidebar when-scroll">
                   <h6 class="fw-600 blue-title-bg text-center">PURCHASE OPTIONS <i class="fa fa-info-circle"></i></h6>
                  <div class=" side">
                    <!--  <div class="d-flex justify-content-between orders  mb-2 ">
                     <div class="form-check">
                        <input class="radio radio-btn" type="radio" value="<?php  echo ($datas->special_excel_data_pack !='') ? $datas->special_excel_data_pack.'-excel_data_pack' : $datas->excel_data_pack.'-excel_data_pack' ?>" id="flexCheckDefault" checked name="price_type" >
                        <label class="form-check-label" for="flexCheckDefault">
                           Excel Data Pack
                        </label>
                        <span class="tooltips"><i class="fa fa-info-circle"></i><span class="tooltipstext">  
                              Only market data will be provided in the excel spreadsheet.<span
                                 class="caret"></span></span></span>
                     </div>
                     <div>
                        <p class="mb-0">
                           <?php if($datas->special_excel_data_pack !='' ): ?>
                           <s> USD  <?php echo e($datas->excel_data_pack); ?> </s> <br> <?php echo e('USD ' .$datas->special_excel_data_pack); ?> 
                           
                           <?php else: ?> 
                           USD  <?php echo e($datas->excel_data_pack); ?>

                           <?php endif; ?>
                        </p>
                     </div>

                  </div> -->

                  <div class="d-flex justify-content-between orders  mb-2">
                     <div class="form-check">
                        <input class=" single_user_license" name="price_type" type="radio" value="<?php  echo ($datas->special_single_licence_price !='') ? $datas->special_single_licence_price.'-single_licence_price' : $datas->single_licence_price.'-single_licence_price' ?> " id="flexCheckDefault" checked>
                        <label class="form-check-label" for="flexCheckDefault">
                           Single User License
                        </label>
                        <span class="tooltips"><i class="fa fa-info-circle"></i><span class="tooltipstext">  
                              The report will be delivered in PDF format without printing rights. It is advised for a
                              single user.<span class="caret"></span></span></span>
                     </div>
                     <div>
                        <p class="mb-0">
                           <?php if($datas->special_single_licence_price !='' ): ?>
                              <s> USD  <?php echo e($datas->single_licence_price); ?> </s> <br> <?php echo e('USD ' .$datas->special_single_licence_price); ?> 
                              
                              <?php else: ?> 
                              USD  <?php echo e($datas->single_licence_price); ?>

                           <?php endif; ?>   
                        </p>
                     </div>
                  </div>

                  <div class="d-flex justify-content-between orders  mb-2">
                     <div class="form-check">
                        <input class="" type="radio" value="<?php echo ($datas->special_multi_user_price !='') ? $datas->special_multi_user_price.'-multi_user_price' : $datas->multi_user_price.'-multi_user_price' ?> " id="flexCheckDefault" name="price_type">
                        <label class="form-check-label" for="flexCheckDefault">
                           Multi User License
                        </label>
                        <span class="tooltips"><i class="fa fa-info-circle"></i><span class="tooltipstext">  
                              The report will be delivered in PDF format with printing rights. It is advised for up
                              to five users.<span class="caret"></span></span></span>
                     </div>
                     <div>
                        <p class="mb-0">
                           <?php if($datas->special_multi_user_price !='' ): ?>
                              <s> USD  <?php echo e($datas->multi_user_price); ?> </s> <br> <?php echo e('USD ' .$datas->special_multi_user_price); ?> 
                              
                              <?php else: ?> 
                              USD  <?php echo e($datas->multi_user_price); ?>

                           <?php endif; ?>
                        </p>
                     </div>
                  </div>


                  <div class="d-flex justify-content-between orders  mb-2">
                     <div class="form-check">
                        <input class="" type="radio" value="<?php echo ($datas->special_custom_report_price !='') ? $datas->special_custom_report_price.'-custom_report_price' : $datas->custom_report_price.'-custom_report_price' ?> " id="flexCheckDefault" name="price_type">
                        <label class="form-check-label" for="flexCheckDefault">
                           Enterprise License
                        </label>
                        <span class="tooltips"><i class="fa fa-info-circle"></i><span class="tooltipstext">  
                              The report will be delivered in PDF format with printing rights and excel sheet. It is
                              advised for companies where multiple users would like to access the report from
                              multiple locations<span class="caret"></span></span></span>
                     </div>
                     <div>
                        <p class="mb-0">
                           <?php if($datas->special_custom_report_price !='' ): ?>
                              <s> USD  <?php echo e($datas->custom_report_price); ?> </s> <br> <?php echo e('USD ' .$datas->special_custom_report_price); ?> 
                              
                              <?php else: ?> 
                              USD  <?php echo e($datas->custom_report_price); ?>

                           <?php endif; ?>
                        </p>
                     </div>
                  </div>   
               </div>
                <input type="hidden" name="idH" value="<?php echo e($datas->id); ?>" id="idH" />
                  <div class="">
                     <button type="button" class="addtocart  max-100" onclick="add_to_cart()"><i class="fa"> </i> Add To Basket</button>
                  </div>
                   <div class="">
                      <a href="<?php echo e(url('/talk-to-our-consultant')); ?>/<?php echo e(request()->segment(2)); ?>" class="quote  max-100">NEED A QUOTE</a> 
                  </div>
                 <!--  <div class="btn-groups">
                     <a href="<?php echo e(url('query/request-sample')); ?>/<?php echo e(request()->segment(2)); ?>" class="btn btn-primary small-btn d-inline-block max-100 color-one"><i
                           class="fa fa-hand-pointer" aria-hidden="true"></i>
                        Request
                        Sample</a>
                     <a href="<?php echo e(url('query/talk-to-our-consultant')); ?>/<?php echo e(request()->segment(2)); ?>" class="btn btn-primary small-btn d-inline-block max-100 color-two"><i
                           class="fa fa-hand-pointer" aria-hidden="true"></i> Talk to our Consultant</a>
                     <a href="<?php echo e(url('query/request-customization')); ?>/<?php echo e(request()->segment(2)); ?>" class="btn btn-primary small-btn d-inline-block max-100 color-three"><i
                           class="fa fa-hand-pointer" aria-hidden="true"></i> Request Customization</a>
                  </div> -->
              
               </div>
            </div>
         </div>
      </div>
   </section>

<script src='https://www.google.com/recaptcha/api.js'></script>
<script src="<?php echo e(url('public/js/intlTelInput.min.js')); ?>"></script>
<script>
   var input = document.querySelector("#phone2");
   input.setAttribute('placeholder', ' ');
   const countryNameElement = document.querySelector("#country-name");
   const iti = window.intlTelInput(input, {
      utilsScript: "https://cdnjs.cloudflare.com/ajax/libs/intl-tel-input/17.0.8/js/utils.js",
      separateDialCode: true,
      initialCountry: "US",
   });
   
 
   function updateCountryName() {
      const selectedCountryData = iti.getSelectedCountryData();
      //const selectedCountryName = selectedCountryData.name;
      const selectedCountryName = selectedCountryData.name.replace(/\s*\([^)]*\)/, '');
      countryNameElement.value = selectedCountryName;
      
   }

   input.addEventListener("countrychange", updateCountryName); 

</script>

<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.7.1/jquery.min.js"></script>
   <script>
      function add_to_cart(){
      
      let report_type_price = $("input[name='price_type']:checked").val();
      
      if(report_type_price == "" || report_type_price === 'undefined'){
         alert('Please Select At-least One Licence Price');
         return false;
      }
      let id = $("#idH").val();
      
      $.ajax({
			url : '<?php echo e(route("add-to-cart-new")); ?>' ,
			type: 'get',
         data: {'id':id, report_type_price: report_type_price},
         dataType: "text",
         success: function(response){
            //location.reload(true)
            window.location = "<?php echo e(url('/shopping-basket')); ?>";
         }
      }); 

   }
   </script>

<!-- plugins -->
<script src="<?php echo e(url('public/assets/js/vendors.js')); ?>"></script>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>

<!-- custom app -->
<script src="<?php echo e(url('public/assets/js/app.js')); ?>"></script>

<script type="text/javascript">
let base_url_req_sample = <?php echo json_encode(url('/')); ?>;
$('#reload').click(function () {
   $.ajax({
      type: 'GET',
      url: base_url_req_sample + '/reload-captcha',
      success: function (data) {
         $(".captcha span").html(data.captcha);
      }
   });
});
</script>
<script src="https://www.google.com/recaptcha/api.js" async defer></script>
<script>
function myFunction() {
  var dots = document.getElementById("dots");
  var moreText = document.getElementById("more");
  var btnText = document.getElementById("myBtn2");

  if (dots.style.display === "none") {
    dots.style.display = "inline";
    btnText.innerHTML = "Read more"; 
    moreText.style.display = "none";
  } else {
    dots.style.display = "none";
    btnText.innerHTML = "Read less"; 
    moreText.style.display = "inline";
  }
}
</script>

<?php $__env->stopSection(); ?>




<?php echo $__env->make('layout/header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u171619165/domains/vishalghosh.com/public_html/stagingrcube/site/resources/views/request_sample.blade.php ENDPATH**/ ?>
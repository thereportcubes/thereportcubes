<aside class="app-navbar">
   <!-- begin sidebar-nav -->
   <div class="sidebar-nav scrollbar scroll_light">
      <ul class="metismenu " id="sidebarNav">
         <li class="nav-static-title">Personal</li>
         <li class="active">
            <a class="has-arrow" href="javascript:void(0)" aria-expanded="false">
            <i class="nav-icon ti ti-rocket"></i>
            <span class="nav-title">Dashboards</span>
            <span class="nav-label label label-danger">9</span>
            </a>
            <ul aria-expanded="false">
               <li class="active"> <a href='#'>Tych</a> </li>
            </ul>
         </li>
         <li>
            <a class="has-arrow" href="javascript:void(0)" aria-expanded="false">
               <i class="nav-icon ti ti-key"></i><span class="nav-title">Members</span></a>
            <ul aria-expanded="false">
               <li> <a href="<?php echo e(url('admin/add-member')); ?>">Add Member</a> </li>
               <li> <a href="<?php echo e(url('admin/all-member')); ?>">All Member</a> </li>
            </ul>
         </li>
         <!-- <li>
            <a class="has-arrow" href="javascript:void(0)" aria-expanded="false">
               <i class="nav-icon ti ti-key"></i><span class="nav-title">Plan</span></a>
            <ul aria-expanded="false">
               <li> <a href="add-plan.php">Add Plan</a> </li>
               <li> <a href="List-plan.php">List Plan</a> </li>
            </ul>
         </li> -->
         <li>
            <a class="has-arrow" href="javascript:void(0)" aria-expanded="false">
               <i class="nav-icon ti ti-key"></i><span class="nav-title">Sub. Admin</span></a>
            <ul aria-expanded="false">
               <li> <a href="<?php echo e(url('admin/add-sub')); ?>">Add Sub-Admin</a> </li>
               <li> <a href="<?php echo e(url('admin/all-sub')); ?>">All Sub-Admin</a> </li>
            </ul>
         </li>
         <li>
            <a class="has-arrow" href="javascript:void(0)" aria-expanded="false">
               <i class="nav-icon ti ti-key"></i><span class="nav-title">User</span></a>
            <ul aria-expanded="false">
               <li> <a href="<?php echo e(url('admin/add-user')); ?>">Add User</a> </li>
               <li> <a href="<?php echo e(url('admin/all-user')); ?>">All Users</a> </li>
            </ul>
         </li>
      </ul>
   </div>
   <!-- end sidebar-nav -->
</aside><?php /**PATH C:\xampp\htdocs\tyche-app\resources\views/admin/sidebar.blade.php ENDPATH**/ ?>
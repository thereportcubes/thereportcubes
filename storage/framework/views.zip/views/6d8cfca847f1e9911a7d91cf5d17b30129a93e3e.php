<section class="footer py-5">
      <div class="container">
         <div class="row">
            <div class="col-md-3 mb-4 mb-md-4 mb-lg-0">               
               <div>
                  <div class="footer-logo">
                     <img src="<?php echo e(url('public/img/logo.png')); ?>" class="img-fluid" alt="">
                  </div>
               </div>
               <div class="mt-lg-5  mt-3">
                  <h4 class="footer_heading">Follow Us On</h4>
                  <ul class="social_icon">
                     <li><a href="#"><i class="fab fa-twitter"></i></a></li>
                     <li><a href="#"><i class="fab fa-facebook"></i></a></li>
                     <li><a href="#"><i class="fab fa-linkedin"></i></a></li>
                     <li><a href="#"><i class="fab fa-youtube"></i></a></li>
                     <li><a href="#"><i class="fab fa-pinterest"></i></a></li>
                  </ul>
               </div>               
            </div>
            <div class="col-md-3 mb-4 mb-md-4 mb-xl-0">
               <div>
                  <h4 class="footer_heading">Quick Links</h4>
                  <ul class="footer-menu">
                     <li><a href="<?php echo e(url('/about')); ?>">About Us</a></li>
                     <li><a href="#">Careers</a></li>
                     <li><a href="#">Contact Us</a></li>
                     <li><a href="#">Our Blogs</a></li>
                  </ul>
               </div>
            </div>
            <div class="col-md-3 mb-4 mb-md-0">
               <div>
                  <h4 class="footer_heading">Product & Services</h4>
                  <ul class="footer-menu">
                     <li><a href="<?php echo e(url('research-report')); ?>">Research Reports</a></li>
                     <li><a href="<?php echo e(url('upcoming-report')); ?>">Upcoming Reports</a></li>
                     <li><a href="<?php echo e(url('press-release')); ?>">Press Release</a></li>
                     <li><a href="<?php echo e(url('infographics')); ?>">Infographics</a></li>
                  </ul>
               </div>
            </div>
            <div class="col-md-3 mb-4 mb-md-0">
               <h4 class="footer_heading">Contact Us</h4>
               <div class="mb-3">
                  <ul>
                     <li><a href="tel:+1 628 895 8081,"><i class="fa fa-phone pe-1" aria-hidden="true"></i> +1 628
                           895 8081, +91 120 4278433</a>
                     </li>
                     <li><a href="mailto:sales@marknteladvisors.com"><i class="fa fa-envelope pe-1"
                              aria-hidden="true"></i>
                           sales@marknteladvisors.com</a>
                     </li>
                     <li><i class="fa fa-globe pe-1" aria-hidden="true"></i> <a href="">Corporate Office:
                           Office No.106, H-160, Sector 63, Noida, Uttar Pradesh - 201301, India</a>
                     </li>
                  </ul>
               </div>
               <div>
                  <a href="" class="white-btn">View Direction</a>
               </div>
            </div>
         </div>
      </div>
      </div>

   </section>

   <section class="copy_right_section py-3">
      <div class="container">
         <div class="row">
            <div class="col-md-12">
               <div class="copyright-bar d-flex justify-content-between">
                  <div>
                     <p class="mb-0 white">© Copyright 2023 MarkNtel Advisors LLP - All Rights Reserved</p>
                  </div>
                  <div>
                     <ul class="mb-0 p-0">
                        <li class="d-inline-block ps-2"><a href="<?php echo e(url('/privacy-policy')); ?>">Privacy Policy
                           </a>
                        </li>
                        <li class="d-inline-block ps-2">
                           <a href="<?php echo e(url('/terms-conditions')); ?>">Terms and Conditions</a>
                        </li>
                     </ul>
                  </div>
               </div>
            </div>
         </div>
      </div>
   </section>

   <!-- ============Footer end============ -->
   <script src="https://code.jquery.com/jquery-2.2.0.min.js" type="text/javascript"></script>
   <script src="<?php echo e(url('public/js/slick.js')); ?>"></script>
   <script src="<?php echo e(url('public/js/custom.js')); ?>"></script>
   <script src="<?php echo e(url('public/js/bootstrap.bundle.min.js')); ?>"></script>
</body>

</html><?php /**PATH C:\xampp\htdocs\markntel_advisor(13-10-23)\resources\views/layout/footer.blade.php ENDPATH**/ ?>
<!doctype html>
<html lang="en" class="no-js modern" style="scroll-behavior: smooth;">


<head>
<meta name="google-site-verification" content="QF_nCsVVGAVBQEVgALQucSJwPlVYWsjyhNwh66jpnY8" />
    <meta content="text/html; charset=utf-8" http-equiv="Content-Type" />
    <meta name="robots" content="noindex, nofollow" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Roboto">
    <script src="<?php echo e(url('public/assets/js/jquery_.js')); ?>"></script>
       <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <title>R Cube - Market Research Reports</title>
    <link rel="shortcut icon" href="<?php echo e(url('public/assets/images/image.png')); ?>" />
    <link rel="apple-touch-icon" href="<?php echo e(url('public/assets/images/image.png')); ?>" />
    <link rel="stylesheet" media="all" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.2.1/css/all.min.css"
      integrity="sha512-MV7K8+y+gLIBoVD59lQIYicR65iaqukzvf/nwasF0nqhPay5w/9lJmVM2hMDcnK1OnMGCdVK+iQrJ7lzPJQd1w=="
      crossorigin="anonymous" referrerpolicy="no-referrer" />
   <link rel="stylesheet" media="all" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css" />
   <link rel="stylesheet" media="all" href="<?php echo e(asset('css/bootstrap.min.css')); ?>">
   <link rel="stylesheet" media="all" href="<?php echo e(asset('css/style.css')); ?>">
   <link rel="stylesheet" media="all" href="<?php echo e(asset('css/slick-theme.css')); ?>">
   <link rel="stylesheet" media="all" href="<?php echo e(asset('css/slick.css')); ?>">
   <link rel="stylesheet" media="all" href="<?php echo e(asset('css/customstyle.css')); ?>">
   <link rel="icon" href="<?php echo e(asset('img/favicon_new.ico')); ?>"/>
   <link rel="stylesheet" href="https://cdn.tutorialjinni.com/intl-tel-input/17.0.8/css/intlTelInput.css"/>
   <link rel="stylesheet" media="all" href="<?php echo e(asset('css/main.css')); ?>">
    
  <link rel="stylesheet" media="all" href="<?php echo e(asset('css/custom.css')); ?>">
   <link rel="stylesheet" media="all" href="<?php echo e(asset('css/ab-style.css')); ?>">
   <link rel="stylesheet" media="all" href="<?php echo e(asset('css/ab-product.css')); ?>">

<body>
     <header id="main-header">
        <div id="overlay-responsive"></div>

        <div id="nav-responsive"> <a class="nav-res-icon"><strong class="content-anim"> <span></span> 
        <span></span>
                    <span></span> </strong></a> <a href="#" id="mobile-header-main-logo"><img width="181" height="21" src="<?php echo e(asset('img/rcube-logo.png')); ?>" alt="R Cube"></a>

            <a rel="nofollow" href="#" class="nav-res-basket"><i class="fa fa-shopping-cart"></i> <span class="basketItemCountMob">0</span></a>

            <a rel="nofollow" class="popup-trigger nav-res-basket"><i class="fa fa-search" aria-hidden="true"></i>
            </a>
        </div>
        
        <div id="top-nav-container"> <span class="top-nav-shape"></span>
            <div class="center clearfix">
                <ul class="text-right right">
                    <li class="hide-phonemin"><a href="maito:sales@thereportcube.com"> <i class="fa fa-envelope" aria-hidden="true"></i> sales@thereportcube.com</a></li>
                    
                    <li class="hide-phonemin"><a href="<?php echo e(url('login')); ?>">Login</a></li>
                    <li class="hide-phonemin"><a href="#">Sign Up</a></li>
                    <li class="hide-phonemin"><div class="gtranslate_wrapper"></div></li>

                </ul>
            </div>
        </div>

        <div id="info-bar-container" class="center">
            <div class="grid clearfix">
                <div class="col-desktop-2 col-phone-6 col-phonemin-8 header-main-logo-container"><a id="header-main-logo" href="<?php echo e(url('/')); ?>"> <span class="logo"><img loading="lazy" src="<?php echo e(url('public/assets/images/rcube-logo.png')); ?>" alt="R Cube"></span> </a></div>
                <div class="number-basket-container col-desktop-10 col-phone-6 col-phonemin-4 text-right">
                    <div class="clearfix">
                        <div id="main-nav-container">

                            <nav id="main-nav-content">
                                <div class="main-nav-lvl-0 dropdown">
                                    <a href="javascript:void()">What We Do</a>
                                    <div class="dropdown-content">
                                        <a href="<?php echo e(url('services/syndicated-research')); ?>">Syndicated Research</a>
                                        <a href="<?php echo e(url('services/customized-research')); ?>">Customized Research</a>
                                        <a href="<?php echo e(url('services/competitive-analysis')); ?>">Competitive Analysis</a>
                                        <a href="<?php echo e(url('services/company-profile')); ?>">Company Profile</a>
                                        <a href="<?php echo e(url('services/biographies')); ?>">Biographies</a>
                                    </div>
                                </div>
                                <div class="main-nav-lvl-0"><a href="<?php echo e(url('about-us')); ?>">About Us</a></div>
                                <div class="main-nav-lvl-0"><a href="<?php echo e(url('report-store')); ?>">Report Store</a></div>
                                <div class="main-nav-lvl-0"><a href="<?php echo e(url('on-going-report')); ?>">On-Going Reports</a></div>
                                <div class="main-nav-lvl-0"><a href="<?php echo e(url('press-release')); ?>">Press Release</a></div>
                                <div class="main-nav-lvl-0"><a href="<?php echo e(url('contact-us')); ?>">Contact Us</a></div>
                                <div class="main-nav-lvl-0">
                                    <a rel="nofollow" id="search-icon"  class="popup-trigger"><i class="fa fa-search" aria-hidden="true"></i>
                                    </a>
                                </div>
                                <div class="main-nav-lvl-0"><a rel="nofollow" href="#" class="icon-basket">
                                        <i class="fa"></i> <span id="basketItemCount">0</span> </a>
                                </div>
                            </nav>

                        </div>

                    </div>
                </div>
            </div>
        </div>

        <div id="main-nav-container">
            <nav id="mobile-nav-content">
                <div class="center clearfix">
                     <div class="main-nav-lvl-0"><a href="#">What We Do</a></div>
                    <div class="main-nav-lvl-0"><a href="<?php echo e(url('about')); ?>">About Us</a></div>
                    <div class="main-nav-lvl-0"><a href="<?php echo e(url('report')); ?>">Report Store</a></div>
                    <div class="main-nav-lvl-0"><a href="<?php echo e(url('on-going-report')); ?>">On-Going Reports</a></div>
                    <div class="main-nav-lvl-0"><a href="<?php echo e(url('press-release')); ?>">Press Release</a></div>
                    <div class="main-nav-lvl-0"><a href="<?php echo e(url('contact')); ?>">Contact Us</a></div>
                    <div class="main-nav-lvl-0"><a href="<?php echo e(url('about')); ?>">Register</a></div>
                    <div class="main-nav-lvl-0"><a href="<?php echo e(url('about')); ?>">Login</a></div>
                </div>
            </nav>

        </div>
    </header>

<?php echo $__env->yieldContent('content'); ?>


<?php echo $__env->make('layout.newfooter', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u171619165/domains/vishalghosh.com/public_html/stagingrcube/site/resources/views/layout/newheader.blade.php ENDPATH**/ ?>

<?php $__env->startSection('title','Upcoming Report'); ?>

<?php $__env->startSection('content'); ?>

<section class="mini-banner">
   <div class="container">
      <div class="row">
         <div class="col-md-12">
            <h1 class="mb-0 mini-banner-title">Upcomming Report</h1>
         </div>
      </div>
   </div>
</section>

<section class="main-content gray-bg-light pt-5 pb-5">
      <div class="container">
         <div class="row">
            <div class="col-md-12 sm-100">
            <?php if(count($datas) > 0): ?>
               <?php $__currentLoopData = $datas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
               <div class="box-shadow white-bg">      
                  <div class="row align-items-center mb-3 category-box">
                     <div class="col-md-2">
                        <img src="<?php echo e(asset('public/img/upc.png')); ?>" class="img-fluid" alt="tag">
                     </div>
                     <div class="col-md-10">
                        <a href="<?php echo e(url('research-library')); ?>/<?php echo e(($data->id)); ?>" class="fw-600 d-block blue"><?php echo e($data->title); ?></a>
                        <p class="fs-14 mb-2"><?php echo e($data->decription); ?><span
                              class="read-more">
                              <a href="<?php echo e(url('research-library')); ?>/<?php echo e(($data->id)); ?>" class="read-more-small-btn">Read
                                 more</a>
                           </span></p>
                     </div>
                  </div>

                  <div class="row">
                     <div class="col-md-12">
                        <ul class="catefory-list ps-0 mb-0">
                           <li>
                              <label><i class="fa fa-industry" aria-hidden="true"></i></label>
                              <span>
                                 <?php echo e($data->cat_name); ?></span>
                           </li>
                           <li>
                              <label> <i class="fa fa-calendar" aria-hidden="true"></i></label>
                              <span><?php echo e(Carbon\Carbon::parse($data->created_at)->format('M Y')); ?> </span>
                           </li>
                           <li>
                              <label>Pages</label>
                              <span><?php echo e($data->no_of_page); ?></span>
                           </li>
                           <li>
                              <label>USD</label>
                              <span><?php echo e($data->single_licence_price); ?></span>
                           </li>
                           <li class="last">
                              <div class="add-carts">
                                 <!-- <a href="#" data-toggle="modal" data-target="#placeorder"><i class="fa fa-cart-plus" aria-hidden="true"></i> Add Cart</a> -->
                                 <a class="cart-btn" href="#" onclick="priceModal('1539')"><i class="fa fa-cart-plus"
                                       aria-hidden="true"></i> Add Cart</a>
                              </div>
                           </li>
                        </ul>
                     </div>
                  </div>
               </div>
             <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
         <?php endif; ?>
         <div class="row">
         <div class="col-md-12">
            <nav aria-label="Page navigation example">
               <?php echo e($datas->links('custom_pagination')); ?>

            </nav>
         </div>
      </div>

      </div>
   </section>



<?php $__env->stopSection(); ?>


<?php echo $__env->make('layout/header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\markntel_advisor\resources\views/upcoming_report.blade.php ENDPATH**/ ?>

<?php $__env->startSection('title','Upcoming Report'); ?>

<?php $__env->startSection('content'); ?>

<section class="mini-banner">
   <div class="container">
      <div class="row">
         <div class="col-md-12">
            <h1 class="mb-0 mini-banner-title">Infographics</h1>
         </div>
      </div>
   </div>
</section>

<section class="main-content mb-5 mt-5">
      <div class="container">


         <div class="row infographics">

            <div class="col-md-3">
               <div class="info-box box-shadow">
                  <a href="" class="black">
                     <div class="info-img pb-2">
                        <img src="img/Aerospace.jpg" class="img-fluid" alt="">
                     </div>
                     <div class="info-content">
                        <p class="fs-15 mb-2">Saudi Arabia Cards & Payments Market Research Report: Forecast (2023-2028)
                        </p>

                        <p class="mb-0">
                           <label> <i class="fa fa-calendar orrange pe-2" aria-hidden="true"></i></label>
                           <span>Aug 2023</span>
                        </p>

                     </div>
                  </a>
               </div>
            </div>
            <div class="col-md-3">
               <div class="info-box box-shadow">
                  <a href="" class="black">
                     <div class="info-img pb-2">
                        <img src="img/Aerospace.jpg" class="img-fluid" alt="">
                     </div>
                     <div class="info-content">
                        <p class="fs-15 mb-2">Saudi Arabia Cards & Payments Market Research Report: Forecast (2023-2028)
                        </p>

                        <p class="mb-0">
                           <label> <i class="fa fa-calendar orrange pe-2" aria-hidden="true"></i></label>
                           <span>Aug 2023</span>
                        </p>

                     </div>
                  </a>
               </div>
            </div>
            <div class="col-md-3">
               <div class="info-box box-shadow">
                  <a href="" class="black">
                     <div class="info-img pb-2">
                        <img src="img/Aerospace.jpg" class="img-fluid" alt="">
                     </div>
                     <div class="info-content">
                        <p class="fs-15 mb-2">Saudi Arabia Cards & Payments Market Research Report: Forecast (2023-2028)
                        </p>

                        <p class="mb-0">
                           <label> <i class="fa fa-calendar orrange pe-2" aria-hidden="true"></i></label>
                           <span>Aug 2023</span>
                        </p>

                     </div>
                  </a>
               </div>
            </div>
            <div class="col-md-3">
               <div class="info-box box-shadow">
                  <a href="" class="black">
                     <div class="info-img pb-2">
                        <img src="img/Aerospace.jpg" class="img-fluid" alt="">
                     </div>
                     <div class="info-content">
                        <p class="fs-15 mb-2">Saudi Arabia Cards & Payments Market Research Report: Forecast (2023-2028)
                        </p>

                        <p class="mb-0">
                           <label> <i class="fa fa-calendar orrange pe-2" aria-hidden="true"></i></label>
                           <span>Aug 2023</span>
                        </p>

                     </div>
                  </a>
               </div>
            </div>
            <div class="col-md-3">
               <div class="info-box box-shadow">
                  <a href="" class="black">
                     <div class="info-img pb-2">
                        <img src="img/Aerospace.jpg" class="img-fluid" alt="">
                     </div>
                     <div class="info-content">
                        <p class="fs-15 mb-2">Saudi Arabia Cards & Payments Market Research Report: Forecast (2023-2028)
                        </p>

                        <p class="mb-0">
                           <label> <i class="fa fa-calendar orrange pe-2" aria-hidden="true"></i></label>
                           <span>Aug 2023</span>
                        </p>

                     </div>
                  </a>
               </div>
            </div>
         </div>
         <div class="row">
            <div class="col-md-12">
               <nav aria-label="Page navigation example">
                  <ul class="pagination mb-0">
                     <li class="page-item"><a class="page-link" href="#">Previous</a></li>
                     <li class="page-item"><a class="page-link" href="#">1</a></li>
                     <li class="page-item"><a class="page-link" href="#">2</a></li>
                     <li class="page-item"><a class="page-link" href="#">3</a></li>
                     <li class="page-item"><a class="page-link" href="#">Next</a></li>
                  </ul>
               </nav>
            </div>
         </div>


      </div>
   </section>


   

<?php $__env->stopSection(); ?>


<?php echo $__env->make('layout/header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\markntel_advisor\resources\views/infographics.blade.php ENDPATH**/ ?>

<?php $__env->startSection('title', 'Market Advisor'); ?>
<?php $__env->startSection('content'); ?>
<section class="mini-banner">
   <div class="container">
      <div class="row">
         <div class="col-md-12">
            <h1 class="mb-0 mini-banner-title">Sign-in/Register</h1>
         </div>
      </div>
   </div>
</section>
<section class="pay-option mb-5">
   <div class="container">
      <div class="row">
         <div class="col-md-12 sm-100 mb-25">
            <div class="wrap-cart">
               <!--   <div class="report-heading">
                            <p class="mb-0 white">User Login / Registeration</p>
                        </div> -->
               <div class="row cart-row">
                  <div class="col-md-12">
                     <div class="cart-borders">
                        <div class="col-md-12" style="padding:10px;border-radius: 5px;text-align: left;">
                           <?php if($errors->any()): ?>
                           <div class="alert alert-danger">
                              <ul>
                                 <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                 <li><?php echo e($error); ?></li>
                                 <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                              </ul>
                           </div><br />
                           <?php endif; ?>

                           <?php if(session()->has('error')): ?>
                           <div class="alert-danger" style="padding:10px;border-radius: 5px;text-align:left;">
                              <strong>Error!</strong> <?php echo e(session()->get('error')); ?>

                           </div>
                           <?php endif; ?>
                        </div>
                        <div class="col-md-12 text-center" style="border-bottom:1px solid #ccc;">
                                 <div class="mb-3">
                                    <label class="radio-inline pe-2">
                                       <input type="radio" name="users" value="1" onclick="$('.signin').show();$('.signup').hide();"  class="yesradio" checked/> Existing Member
                                    </label>
                                    <label class="radio-inline pe-2">
                                       <input type="radio" name="users" value="0" onclick="$('.signup').show(); $('.signin').hide();" class="noradio" /> New Member
                                    </label>
                                 </div>
                                </div>
                        <div class="signin" style="display: <?php if(Route::current()->getName() == 'signup'): ?> none <?php endif; ?>">

                              

                           <form method="post" action="<?php echo e(route('signin')); ?>" id="signForm">
                              <?php echo csrf_field(); ?>
                            
                              
                              <div class="row mt-2 loginform">
                                  <div class="col-md-12 mt-1" style="text-align: right;">
                                 <p>* Required Information</p>
                              </div>
                                 <div class="col-md-12">
                                    <div class="mb-3">
                                       <p class="mb-1">Please enter your email address*</p>
                                       <input type="email" class="form-control" name="email" />
                                    </div>
                                 </div>

                               
                                    <div class="col-md-12">
                                       <div class="mb-3">
                                          <p class="mb-1">Please enter your password</p>
                                          <input type="password" class="form-control" name="password" />
                                       </div>
                                    </div>
                                 
                                 <div class="col-md-12 mb-1">
                                    <a href="<?php echo e(route('forget-password')); ?>">Forgot your password?</a>
                                 </div>
                              </div>
                               <div class="row">
                              <div class="col-md-12 mt-2">
                                 <div class="g-recaptcha" data-sitekey="<?php echo e(config('services.recaptcha.key')); ?>"></div>
                              </div>

                             
                              <div class="col-12 mb-2">
                                 <?php if($errors->has('g-recaptcha-response')): ?>
                                 <span class="help-block">
                                    <strong><?php echo e($errors->first('g-recaptcha-response')); ?></strong>
                                 </span>
                                 <?php endif; ?>
                              </div>
                          </div>
                              <div class="col-md-12">
                                 <center>
                                    <button type="submit" class="ab-button ab-button-primary submitbtn" fdprocessedid="lfrn7i">Submit</button>
                                 </center>
                              </div>

                           </form>
                        </div>
                        <div class="signup" style="display: <?php if(Route::current()->getName() != 'signup'): ?> none <?php endif; ?>">
                           <form method="post" action="<?php echo e(route('signup')); ?>">
                              <?php echo csrf_field(); ?>


                                  <div class="col-md-12 mt-1" style="text-align: right;">
                                       <p>* Required Information</p>
                                    </div>
                                
                                 
                                 <div class="row" style="align-items: center;">
                                    <div class="col-md-3">
                                       <p style="font-size: 16px;">Full Name<span style="color:var(--primary-color)">*</span></p>
                                    </div>
                                    <div class="col-md-9">
                                       <input class="ab-input" type="text" name="first_name" value="<?php echo e(old('first_name')); ?>" placeholder="Enter your Full name" required>
                                    </div>
                                 </div>
                                 <div class="row" style="align-items: center;">
                                    <div class="col-md-3">
                                       <p style="font-size: 16px;">Company Name<span style="color:var(--primary-color)">*</span></p>
                                    </div>
                                    <div class="col-md-9">
                                       <input class="ab-input" type="text" name="company_name" value="<?php echo e(old('company_name')); ?>" placeholder="Enter your Company Name" required>
                                    </div>
                                 </div>
                                 <div class="row" style="align-items: center;">
                                    <div class="col-md-3">
                                       <p style="font-size: 16px;">Email Address<span style="color:var(--primary-color)">*</span></p>
                                    </div>
                                    <div class="col-md-9">
                                       <input type="email" class="ab-input" name="email"  value="<?php echo e(old('email')); ?>" placeholder="Email Address" />
                                    </div>
                                 </div>

                                 <div class="row" style="align-items: center;">
                                    <div class="col-md-3">
                                       <p style="font-size: 16px;">Country<span style="color:var(--primary-color)">*</span></p>
                                    </div>
                                    <div class="col-md-9">
                                       <input class="ab-input" type="text" name="country" value="<?php echo e(old('country')); ?>" placeholder="Enter Your Country" required>
                                    </div>
                                 </div>
                                 <div class="row" style="align-items: center;">
                                    <div class="col-md-3">
                                       <p style="font-size: 16px;">Phone<span style="color:var(--primary-color)">*</span></p>
                                    </div>
                                    <div class="col-md-9">
                                       <input class="ab-input" type="text" name="phone_number" value="<?php echo e(old('phone_number')); ?>" placeholder="Enter Your Contact Number" required>
                                    </div>
                                 </div>
                                
                                  <div class="row" style="align-items: center;">
                                    <div class="col-md-3">
                                       <p style="font-size: 16px;"> Create a password<span style="color:var(--primary-color)">*</span></p>
                                    </div>
                                    <div class="col-md-9">
                                     <input type="password" class="ab-input" name="password"  value="<?php echo e(old('email')); ?>" placeholder="Create Password"/>
                                    </div>
                                 </div>
                                  <div class="row" style="align-items: center;">
                                    <div class="col-md-3">
                                       <p style="font-size: 16px;">Confirm password<span style="color:var(--primary-color)">*</span></p>
                                    </div>
                                    <div class="col-md-9">
                                     <input type="password" class="ab-input" name="password_confirmation"  value="<?php echo e(old('email')); ?>"  placeholder="Confirm Password" />
                                    </div>
                                 </div>
                                    <div class="row" style="align-items: center;">
                                    <div class="col-md-3">
                                       
                                    </div>
                                    <div class="col-md-9">
                                      <div class="g-recaptcha" data-sitekey="<?php echo e(config('services.recaptcha.key')); ?>"></div>

                                      <div class="col-12 mb-2">
                                    <?php if($errors->has('g-recaptcha-response')): ?>
                                    <span class="help-block">
                                       <strong><?php echo e($errors->first('g-recaptcha-response')); ?></strong>
                                    </span>
                                    <?php endif; ?>
                                 </div>
                                    </div>
                                 </div>
                               
                         

                                 <div class="col-md-12">
                                    <center><button type="submit" class="ab-button ab-button-primary submitbtn" fdprocessedid="lfrn7i">Submit</button></center>
                                 </div>
                             </form>
                               
                              </div>
                          </div>
                        </div>
                     </div>
                  </div>
               </div>
            </div>
</section>
<script>
   var isSign = '<?php if(Route::current()->getName() == '
   signin '): ?> 1 <?php else: ?> 0 <?php endif; ?>';
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout/header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u171619165/domains/vishalghosh.com/public_html/stagingrcube/site/resources/views/signin.blade.php ENDPATH**/ ?>